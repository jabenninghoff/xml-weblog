<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("include/common.inc.php");
include("include/header.inc.php");

$VAR["Heading"] = "Create Account";
if ($CONF["UsersPostAs"] == 1) {
	$VAR["Content"] .= "<br />You will be identified by your Username in posts.";
} elseif ($CONF["UsersPostAs"] == 2) {
	$VAR["Content"] .= "<br />You will be identified by your Real Name in your posts.";
} elseif ($CONF["UsersPostAs"] == 3) {
	$VAR["Content"] .= "<br />You will be identified by you Username or your Real Name in your posts.";
}
$VAR["Content"] .= "
<form	action	= \"$G_URL/submit.php\"
	name	= User
	onsubmit = \"return validateUser()\"
	method	= post>
<table
	border	= 0
	cellspacing	= 1
	cellpadding	= 2
	width	= \"100%\">

<tr><td>Username</td><td><input type=text name=Username size=16 maxlength=16><small> (Case sensitive)</td></tr>
<tr><td>Password</td><td><input type=password name=Password size=16 maxlength=16> Verify <input type=password name=Password2 size=16 maxlength=16></td></tr>
<tr><td>Real Name</td><td><input type=text name=RealName size=24 maxlength=24></td></tr>
<tr><td>Email</td><td><input type=text name=EmailAddress size=24 maxlength=128></td></tr>
<tr><td>URL</td><td><input type=text name=URL size=24 maxlength=128></td></tr>";

$VAR["Content"] .= "
<tr><td>Comment</td><td><textarea name=Comment rows=5 cols=40 wrap=virtual></textarea></td></tr>
";

$VAR["Content"]	.= "
</td>
</tr>

<tr>
<td
	colspan	= 2
	align	= center>
<input	type	= hidden
	name	= what
	value	= \"user\">
<input	type	= submit
	value	= \"" . F_submit() . "\">
</table>
</form>";

F_drawMain($VAR);
include("include/footer.inc.php");

?>
