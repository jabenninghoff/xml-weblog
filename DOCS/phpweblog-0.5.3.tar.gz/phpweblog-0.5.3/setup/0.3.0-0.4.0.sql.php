<?
# 0.3.0 to 0.4.0

mysql_query("ALTER TABLE T_Blocks CHANGE COLUMN Rid Rid varchar(16) DEFAULT '' NOT NULL",$db); # was int(11) DEFAULT '0' NOT NULL auto_increment
mysql_query("ALTER TABLE T_Blocks ADD COLUMN URL varchar(96)",$db);
mysql_query("ALTER TABLE T_Blocks ADD COLUMN Birthstamp datetime",$db);

mysql_query("ALTER TABLE T_Comments DROP COLUMN CommentRid",$db); # was int(11)
mysql_query("ALTER TABLE T_Comments CHANGE COLUMN NewsRid TopRid varchar(16)",$db); # was int(11)
mysql_query("ALTER TABLE T_Comments CHANGE COLUMN Rid Rid varchar(16) DEFAULT '' NOT NULL",$db); # was int(11) DEFAULT '0' NOT NULL auto_increment
mysql_query("ALTER TABLE T_Comments ADD COLUMN ParentRid varchar(16)",$db);
mysql_query("UPDATE T_Comments SET ParentRid = TopRid",$db);
mysql_query("ALTER TABLE T_Comments ADD COLUMN Heading varchar(128)",$db);

mysql_query("ALTER TABLE T_Config DROP COLUMN SiteOwner",$db); # was char(24)
mysql_query("ALTER TABLE T_Config DROP COLUMN Links",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN Comments",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN TopicSort",$db); # was char(8)
mysql_query("ALTER TABLE T_Config DROP COLUMN Backend",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN Timezone",$db); # was char(6)
mysql_query("ALTER TABLE T_Config DROP COLUMN AllowAnon",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN Views",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN EmailAddress",$db); # was char(96)
mysql_query("ALTER TABLE T_Config DROP COLUMN EmailComments",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN Moderation",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN Topics",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN Passwd",$db); # was char(128)
mysql_query("ALTER TABLE T_Config DROP COLUMN Timestamp",$db); # was timestamp(14)
mysql_query("ALTER TABLE T_Config DROP COLUMN AllowHTML",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN SiteName",$db); # was char(64)
mysql_query("ALTER TABLE T_Config DROP COLUMN Older",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN SiteSlogan",$db); # was char(64)
mysql_query("ALTER TABLE T_Config DROP COLUMN ShowIP",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN CommentSort",$db); # was char(8)
mysql_query("ALTER TABLE T_Config DROP COLUMN SaveInfo",$db); # was char(1)
mysql_query("ALTER TABLE T_Config DROP COLUMN LimitNews",$db); # was char(2)
mysql_query("ALTER TABLE T_Config DROP COLUMN SiteKey",$db); # was char(10)
mysql_query("ALTER TABLE T_Config DROP COLUMN Layout",$db); # was char(24)
mysql_query("ALTER TABLE T_Config ADD COLUMN Name varchar(16)",$db);
mysql_query("ALTER TABLE T_Config ADD COLUMN Value varchar(128)",$db);

mysql_query("DELETE FROM T_Config",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (1,'Moderation','2')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (2,'SiteName','phpWebLog')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (3,'SiteSlogan','web news management with tits')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (4,'SiteOwner','Foo Mun Choo')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (5,'EmailAddress','jason@greenhell.com')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (6,'Backend','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (7,'BackendFile','weblog.rdf')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (8,'MailingList','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (9,'MailingAddress','')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (10,'SummaryLength','255')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (11,'Comments','2')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (12,'CommentSort','asc')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (13,'Topics','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (14,'TopicSort','id')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (15,'Links','2')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (16,'Older','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (17,'Hotest','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (18,'LimitNews','10')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (19,'LimitType','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (20,'Passwd','5f4dcc3b5aa765d61d8327deb882cf99')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (21,'SiteKey','phpWebLog')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (22,'SiteStats','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (23,'AllowAnon','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (24,'AllowHTML','3')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (25,'SaveInfo','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (26,'MoreLink','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (27,'EmailComments','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (28,'AllowContrib','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (29,'Layout','default')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (30,'Language','english')",$db);

mysql_query("ALTER TABLE T_Links CHANGE COLUMN Title Title varchar(96)",$db); # was char(96)
mysql_query("ALTER TABLE T_Links CHANGE COLUMN Description Description varchar(255)",$db); # was char(255)
mysql_query("ALTER TABLE T_Links CHANGE COLUMN URL URL varchar(96)",$db); # was char(96)
mysql_query("ALTER TABLE T_Links CHANGE COLUMN Cat Cat varchar(32)",$db); # was char(32)
mysql_query("ALTER TABLE T_Links CHANGE COLUMN Host Host varchar(96)",$db); # was char(96)
mysql_query("ALTER TABLE T_Links CHANGE COLUMN Rid Rid varchar(16) DEFAULT '' NOT NULL",$db); # was int(11) DEFAULT '0' NOT NULL auto_increment

mysql_query("ALTER TABLE T_Pages CHANGE COLUMN Rid Rid varchar(16) DEFAULT '' NOT NULL",$db); # was int(11) DEFAULT '0' NOT NULL auto_increment

mysql_query("ALTER TABLE T_PollAnswers CHANGE COLUMN Answer Answer varchar(255)",$db); # was char(255)
mysql_query("ALTER TABLE T_PollAnswers CHANGE COLUMN Rid Rid varchar(16) DEFAULT '' NOT NULL",$db); # was char(20) DEFAULT '' NOT NULL

mysql_query("ALTER TABLE T_PollQuestions CHANGE COLUMN Display Display char(1) DEFAULT '0' NOT NULL",$db); # was tinyint(4) DEFAULT '0' NOT NULL
mysql_query("ALTER TABLE T_PollQuestions CHANGE COLUMN Question Question varchar(255) DEFAULT '' NOT NULL",$db); # was char(255) DEFAULT '' NOT NULL
mysql_query("ALTER TABLE T_PollQuestions CHANGE COLUMN Rid Rid varchar(16) DEFAULT '' NOT NULL",$db); # was char(64) DEFAULT '' NOT NULL

mysql_query("ALTER TABLE T_Stories CHANGE COLUMN Topic Topic varchar(16)",$db); # was int(11)
mysql_query("ALTER TABLE T_Stories CHANGE COLUMN Rid Rid varchar(16) DEFAULT '' NOT NULL",$db); # was int(11) DEFAULT '0' NOT NULL auto_increment
mysql_query("ALTER TABLE T_Stories ADD COLUMN StoryURL varchar(128)",$db);

?>
