<?
# 0.5.2 to 0.5.3

mysql_query("ALTER TABLE T_Stories ADD COLUMN IndexDisplay char(1) default 'Y'",$db);
mysql_query("ALTER TABLE T_Stories ADD COLUMN ParseType varchar(20) default NULL",$db);
mysql_query("ALTER TABLE T_Comments ADD COLUMN ParseType varchar(20) default NULL",$db);
mysql_query("ALTER TABLE T_Topics ADD COLUMN IndexDefault char(1) default 'Y'",$db);
mysql_query("ALTER TABLE T_Topics CHANGE COLUMN Rid varchar(17) default ''",$db);

mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('ModPasswd','None')",$db);
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('HardKill','1')",$db); 
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('Last5','0')",$db);
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('LimitIndexed','0')",$db);
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('SplitPages','0')",$db);
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('FuturePost','0')",$db);
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('ShowIP','0')",$db);
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('ShowHits','0')",$db);
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('AuthPostOnly','0')",$db);
mysql_query("INSERT INTO T_Config (Name, Value) VALUES ('UsersPostAs','0')",$db);

mysql_query("DELETE FROM T_Config WHERE Name = 'Top5'",$db);
mysql_query("DELETE FROM T_Config WHERE Name = 'Hot5'",$db);
mysql_query("DELETE FROM T_Config WHERE Name = 'Last5'",$db);
mysql_query("DELETE FROM T_Config WHERE Name = 'Older'",$db);
mysql_query("DELETE FROM T_Config WHERE Name = 'Topics'",$db);
mysql_query("DELETE FROM T_Config WHERE Name = 'Passwd'",$db);
mysql_query("DELETE FROM T_Config WHERE Name = 'ModPasswd'",$db);

mysql_query("ALTER TABLE T_Blocks DROP COLUMN PageComments",$db);
mysql_query("ALTER TABLE T_Blocks DROP COLUMN Hits",$db);


mysql_query("DROP TABLE IF EXISTS T_Content",$db);
mysql_query("CREATE TABLE T_Content (
  Rid int(11) NOT NULL auto_increment,
  Name varchar(16) NOT NULL,
  Value TEXT NOT NULL,
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);

mysql_query("INSERT INTO T_Content (Name, Value) VALUES ('Welcome','')",$db);
mysql_query("INSERT INTO T_Content (Name, Value) VALUES ('Footer','phpWebLog: A PHP News and Content Management System\r\n<br>\r\nCopyright (C) 2000-2001, Jason Hines / Eye Integrated Communications')",$db);
mysql_query("INSERT INTO T_Content (Name, Value) VALUES ('Contrib','Something to add to this site?  Simply fill out this form, and your story will be added as soon as possible.')",$db);
mysql_query("INSERT INTO T_Content (Name, Value) VALUES ('Submitted','Thank you for supporting this site.  Your submitted story may be held for approval by our moderators.')",$db);
mysql_query("INSERT INTO T_Content (Name, Value) VALUES ('Contact','Use this form to send mail to this user.  The user\'s email address is not disclosed to protect his/her privacy.')",$db);
mysql_query("INSERT INTO T_Content (Name, Value) VALUES ('Friend','Use this form to send the story to a friend.')",$db);

mysql_query("INSERT INTO T_Users (Verified, Username, Password, RealName, EmailAddress, URL, Level, Comment, LastLogin, FirstLogin) VALUES ('Y','admin','5f4dcc3b5aa765d61d8327deb882cf99','Dead Bob','null@domain.com','','3','',NULL,'2001-07-17 15:32:54')",$db);

mysql_query("DROP TABLE IF EXISTS T_Pages",$db);
mysql_query("CREATE TABLE T_Pages (
  Rid varchar(16) NOT NULL default '',
  Display char(1) default NULL,
  PageComments char(1) default NULL,
  Title varchar(24) default NULL,
  Heading varchar(48) default NULL,
  Content text,
  Type tinyint(4) default NULL,
  URL varchar(96) default NULL,
  Hits int(11) default NULL,
  Timestamp timestamp(14) NOT NULL,
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);


$result = mysql_query("SELECT * FROM T_Blocks WHERE Display='p' OR Display='f'",$db);
for ($i=0;$i<mysql_num_rows($result);$i++) {
	$A	= mysql_fetch_object($result);
	$rid = F_getRid();
	mysql_query("INSERT INTO T_Pages (Rid,Display,PageComments,Title,Heading,Content,Type,URL,Hits) VALUES ('$rid','$A->Display','0','$A->Heading','$A->Heading','$A->Content',0,'',0)",$db);
}
mysql_query("DELETE FROM T_Blocks WHERE Display='p' OR Display='f'",$db);


mysql_query("ALTER TABLE T_Comments MODIFY TopRid VARCHAR(16) NOT NULL",$db);
mysql_query("ALTER TABLE T_Comments MODIFY ParentRid VARCHAR(16) NOT NULL",$db);
mysql_query("CREATE INDEX TopRid_IDX ON T_Comments (TopRid)",$db);
mysql_query("CREATE INDEX ParentRid_IDX ON T_Comments (ParentRid)",$db);


$rid = F_getRid();
$url = $G_PATH . "/backend/blocks/admin.inc.php";
mysql_query("INSERT INTO T_Blocks (Rid, Display, Heading, Type, OrderID, URL, Birthstamp, Cache) VALUES ('$rid','l','Administration','3',1,'$url',now(),'360')");

$rid = F_getRid();
$url = $G_PATH . "/backend/blocks/topics.inc.php";
mysql_query("INSERT INTO T_Blocks (Rid, Display, Heading, Type, OrderID, URL, Birthstamp, Cache) VALUES ('$rid','l','Topics','3',2,'$url',now(),'360')");

$rid = F_getRid();
$url = $G_PATH . "/backend/blocks/features.inc.php";
mysql_query("INSERT INTO T_Blocks (Rid, Display, Heading, Type, OrderID, URL, Birthstamp, Cache) VALUES ('$rid','l','Features','3',3,'$url',now(),'360')");


mysql_query("DROP TABLE IF EXISTS T_Users",$db);
mysql_query("CREATE TABLE T_Users (
  Verified char(1) default NULL,
  Username varchar(16) NOT NULL default '',
  Password varchar(64) NOT NULL default '',
  RealName varchar(24) NOT NULL default '',
  EmailAddress varchar(128) NOT NULL default '',
  URL varchar(128) NOT NULL default '',
  Level char(1) NOT NULL default '',
  Comment text NOT NULL default '',
	LastLogin datetime default NULL,
  FirstLogin datetime default NULL,
  PRIMARY KEY (Username)
) TYPE=MyISAM",$db);

?>
