<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/


include_once("../include/common.inc.php");
include_once("include/header.inc.php");


if (!F_matchOK() && !empty($what)) {
	print "Access denied.";
	F_logAccess("Access denied to installation setup directory");
	include_once("include/footer.inc.php");
	exit();
}



switch ($what) {


	case "reset password":
		print "<h3>Reset Administrator Password</h3>\n";
		print "This will reset the desired username to the default password of 'password'.";
		print "<p>Enter the username of whose password you wish to reset.";
		print "<form method=POST>\n";
		print "<input type=\"text\" name=\"username\" size=\"12\">\n";
		print "<input type=\"submit\" name=\"what\" value=\"confirm reset\">\n";
		print "<input type=\"submit\" value=\"cancel\">\n";
		print "</form>\n";
	break;


	case "confirm reset":
		if ($username) {
			$sql = "UPDATE T_Users SET Password = '5f4dcc3b5aa765d61d8327deb882cf99' ";
			$sql .= "WHERE Username = '$username'";
			@mysql_query($sql,$db);
			print "<h3>Reset Administrator Password</h3>\n";
			print "Password for username <b>{$username}</b> has been changed to '<b>password</b>'.";
			print "<p>\n";
			print "<form action=\"$G_URL/stories.php\" method=POST>\n";
			print "<input type=\"submit\" name=\"\" value=\"go to site\">\n";
		} else {
			print "<h3>Reset Administrator Password</h3>\n";
			print "We need a username. Please enter a username next time.";
			print "<form method=POST>\n";
			print "<input type=\"submit\" name=\"what\" value=\"reset password\">\n";
			print "</form>\n";
		}
	break;

	case "new install":
		print "<h3>Installing phpWebLog $G_VER</h3>\n";
		print "This will create all the necessary tables, overriding any existing tables.  Are you sure you want to continue?";
		print "<form method=POST>\n";
		print "<input type=\"submit\" name=\"what\" value=\"confirm install\">\n";
		print "<input type=\"submit\" value=\"cancel\">\n";
		print "</form>\n";
	break;

	case "confirm install":
		print "Creating Tables...";
		create_tables();
		print "<br>Importing Default Data...";
		import_data();
		check_perms();
		if (!mysql_error($db)) {
			print "<h3>Installation Complete</h3>\n";
			print "If you see no errors on this page, your installation was successful.";
			print "<p>\n";
			print "<form action=\"$G_URL/stories.php\" method=POST>\n";
			print "<input type=\"submit\" name=\"\" value=\"go to site\">\n";
		} else {
			print "<h3>Installation Failed!</h3>\n";
			print "Errors occured in this installation. This is not good.";
			print "<p>\n";
			print "<form method=POST>\n";
			print "<input type=\"submit\" name=\"\" value=\"cancel\">\n";
			print "</form>\n";		
		}
	break;

	case "continue upgrade":

		print "<h3>Upgrading version $current_version to $G_VER</h3>\n";

		$d = dir($G_PATH . "/setup");
		while ($entry=$d->read()) {
			if (eregi("^.+\.sql\.php$",$entry)) {
				$entry = eregi_replace("\.sql\.php$","",$entry);
				$tmp = explode("-",$entry);
				if ($tmp[0] >= $current_version && $tmp[1] <= $G_VER) {
					$fname = $G_PATH . "/setup/" . $entry . ".sql.php";
					if (file_exists($fname)) {
						print "Upgrading: <b>$tmp[0]</b> to <b>$tmp[1]</b> ... ";
						include_once($fname);
						print "OK<br>";
					}
				}
			}
		}

		check_perms();
		print "<h3>Upgrade Complete</h3>\n";
		print "If you see no errors on this page, your installation was successful.";
		print "<p>\n";
		print "<form action=\"$G_URL/stories.php\" method=POST>\n";
		print "<input type=\"submit\" name=\"\" value=\"go to site\">\n";


	break;


	case "upgrade":

		$d = dir($G_PATH . "/setup");
		while ($entry=$d->read()) {
			if (eregi("^.+\.sql\.php$",$entry)) {
				$entry = eregi_replace("\.sql\.php$","",$entry);
				$tmp = explode("-",$entry);
				$vers[] = $tmp[0];
				$new[] = $tmp[1];
			}
		}
		rsort($vers);

		if (in_array($G_VER,$new)) {
			print "<h3>Upgrading to phpWebLog $G_VER</h3>";

			print "Select which version you are upgrading from.";
			print "<form method=POST>\n";
			print "Currently installed version: ";
			print "<select name=\"current_version\">\n";
		   	foreach ($vers as $V) print "<option>$V</option>\n";
			print "</select><p>\n";
			print "It is highly recommended that you backup your existing database ";
			print "before continuing.<br>This can be done on the command line using ";
			print "<b>mysqldump</b> like such:<p>";
			print "$ mysqladmin -u USERNAME -p -e --add-drop-table $G_DB > phpweblog-old.sql<p>";
			print "<input type=submit name=what value=\"continue upgrade\">\n";
			print "<input type=\"submit\" name=\"\" value=\"cancel\">\n";
			print "</form>\n";            
		} else {
			print "<h3>Upgrade to version $G_VER not available.</h3>";
			print "The version that you are attempting to install is not ";
			print "available as an automatic upgrade.";
			print "<p>$G_VER may be an unstable version ";
			print " in which you will be required to either alter your ";
			print "tables manually, or not at all.";
			print "<p>\n";
			print "<form method=POST>\n";
			print "<input type=\"submit\" name=\"\" value=\"cancel\">\n";
			print "</form>\n";		

		}
	break;


	case "continue":
	default:
		if (verify_passwd($password)) {
			print "<h3>Welcome to phpWebLog $G_VER</h3>\n";
			print "Which procedure would you like to preform?";
			print "<p>\n";
			print "<form method=POST>\n";
			print "<input type=\"submit\" name=\"what\" value=\"upgrade\">\n";
			print "<input type=\"submit\" name=\"what\" value=\"new install\">\n";
			print "<input type=\"submit\" name=\"what\" value=\"reset password\">\n";
			print "</form>\n";
		} else {
			check_config();
			print "<form method=POST name=\"SETUP\">\n";
			print "<h1>Welcome to phpWebLog $G_VER</h1>\n";
			print "<h3>Automatic installation and upgrade</h3>\n";
			print "Setup password:\n";
			print "<input size=12 type=\"password\" name=\"password\" value=\"\">\n";
			if (!empty($password)) {
				print " <font color=\"#660000\">INVALID PASSWORD</font>\n";
			}
			print "<br>\n";
			print "<input type=\"submit\" name=\"what\" value=\"continue\">\n";
			print "<input type=\"reset\" name=\"what\" value=\"cancel\">\n";
			print "</form>\n";
			print "<p><hr size=1 noshade></p>\n";
			print "<h3>phpWebLog Support</h3>\n";
			print "<li><a target=_new href=\"http://phpweblog.org/\">phpWebLog Homepage</a></li>\n";
			print "<h3>Legal Information</h3>\n";
			print "<blockquote><pre>\n";
			print "phpWebLog: A PHP News and Content Management System\n";
			print "Copyright (C) 2000-2001, Jason Hines / Eye Integrated Communications\n\n";

			print "This program is free software; you can redistribute it and/or modify it\n";
			print "under the terms of the GNU General Public License as published by the Free\n";
			print "Software Foundation; either version 2 of the License, or (at your option)\n";
			print "any later version.\n\n";

			print "This program is distributed in the hope that it will be useful, but WITHOUT\n";
			print "ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or\n";
			print "FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for\n"; 
			print "more details.\n\n";

			print "You should have received a copy of the GNU General Public License along\n";
			print "with this program; if not, write to the Free Software Foundation, Inc., 59\n";
			print "Temple Place - Suite 330, Boston, MA  02111-1307, USA.\n";
			print "</pre></blockquote>\n";
			print "<script language=\"javascript\">\n";
			print "\tdocument.SETUP.password.focus();\n";
			print "</script>\n";
		}
	break;
}

include_once("include/footer.inc.php");


function check_config() {
	global $db,$G_PATH,$G_URL;
	print "<h4>Configuration Check</h4>\n";
	print "<pre>\n";
	print "Database connection ... " . (!empty($db) ? "OK" : "FAILED") . "\n";
	print "URL definition      ... " . (!empty($G_URL) ? "OK" : "FAILED") . "\n";
	print "Path definition     ... " . (!empty($G_PATH) && file_exists($G_PATH) ? "OK" : "FAILED") . "\n";
	print "</pre>\n";
}

function create_tables() {
	global $db;
	include_once("create.inc.php");
}

function import_data() {
	global $db, $G_PATH;
	include_once("data.inc.php");
}

function verify_passwd($pw) {
	global $SETUP_PW;
	if ($pw == $SETUP_PW && F_matchOK()) {
		return true;
	} else {
		return false;
	}
}

function check_perms() {
	global $G_PATH;

	if (!writeable("$G_PATH/logs/error.log")) {
		print "<p><h3>Warning: Permissions are Invalid</h3>\n";
		print "Permissions on certain files are not correct.  You can fix this ";
		print "automatically by running the following line from the command line:<p>\n";
		print "$ $G_PATH/etc/fix_permissions.sh $G_PATH";
	}
}


function writeable($filename) {
	clearstatcache();

	$perms = @Fileperms( $filename );
	$owner = @FileOwner( $filename );
	eregi( "^uid=([0-9]*)", exec( "id"), $regs );
	$apacheuid = $regs[1];

	/* Hint: integers starting with '0' are octal */
	$perms = 0777 & $perms;

	if ( $apacheuid != $owner ) {
		if ( 06 == ( 07 & $perms ) ) { return 1; } else { return 0; }
	} else {
		if ( 0600 == ( 0700 & $perms ) ) { return 1; } else { return 0; }
	}
} 



?>