<?


mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (1,'Moderation','2')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (2,'SiteName','phpWebLog')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (3,'SiteSlogan','web news management')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (4,'SiteOwner','Generic Bob')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (5,'EmailAddress','null@domain.com')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (6,'Backend','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (7,'BackendFile','weblog.rdf')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (8,'MailingList','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (9,'MailingAddress','')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (10,'SummaryLength','300')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (11,'Comments','2')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (12,'CommentSort','asc')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (13,'TopicSort','asc')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (14,'Links','2')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (15,'Older','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (16,'Top5','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (17,'Hot5','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (18,'LimitNews','10')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (19,'LimitType','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (20,'SiteKey','phpWebLog')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (21,'SiteStats','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (22,'AllowAnon','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (23,'SaveInfo','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (24,'EmailComments','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (25,'AllowContrib','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (26,'Layout','shanked')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (27,'Language','english')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (28,'Archive','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (29,'MailFriend','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (30,'PrintStory','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (31,'HardKill','1')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (32,'Last5','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (33,'LimitIndexed','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (34,'SplitPages','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (35,'FuturePost','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (36,'ShowHits','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (37,'ShowIP','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (38,'AuthPostOnly','0')",$db);
mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (39,'UsersPostAs','0')",$db);

mysql_query("INSERT INTO T_Content (Rid, Name, Value) VALUES (1,'Welcome','')",$db);
mysql_query("INSERT INTO T_Content (Rid, Name, Value) VALUES (2,'Footer','phpWebLog: A PHP News and Content Management System\r\n<br />\r\nCopyright (C) 2000-2001, Jason Hines / Eye Integrated Communications')",$db);
mysql_query("INSERT INTO T_Content (Rid, Name, Value) VALUES (3,'Contrib','Something to add to this site?  Simply fill out this form, and your story will be added as soon as possible.')",$db);
mysql_query("INSERT INTO T_Content (Rid, Name, Value) VALUES (4,'Submitted','Thank you for supporting this site.  Your submitted story may be held for approval by our moderators.')",$db);
mysql_query("INSERT INTO T_Content (Rid, Name, Value) VALUES (5,'Contact','Use this form to send mail to this user.  The user\'s email address is not disclosed to protect his/her privacy.')",$db);
mysql_query("INSERT INTO T_Content (Rid, Name, Value) VALUES (6,'Friend','Use this form to send the story to a friend.')",$db);

mysql_query("INSERT INTO T_Topics (Rid, Topic, ImgURL, AltTag, NoPosting, NoComments, IndexDefault, Timestamp) VALUES ('01/08/07/5469882','General','','','0','0','Y',20010807133109)",$db);
mysql_query("INSERT INTO T_Stories (Rid, Verified, IndexDisplay, Score, Host, Topic, Heading, Summary, Content, Author, AuthorEmail, AuthorURL, EmailComments, ParseType, Hits, Repostamp, Timestamp, Birthstamp) VALUES ('01/08/07/5498124','Y','Y',0,'dev2.eyeintegrated.com','01/08/07/5469882','Welcome to phpWebLog!','Welcome to phpWebLog.  It appears that you have had a successful installation.  The first thing you will want to do at this point is LOGIN as \"admin\" and start customizing your site.  To do this, simply point your browser <a href=\\\"admin/\\\">here</a>.\r\n\r\nThe default password is <b>password</b>. You will definately want to change this.  Be sure to change the <b>site key</b> to something specific and unique to your site as well.\r\n\r\nAny questions, comments, or if you would like to help us develop this project, please see us at <a href=\\\"http://phpweblog.org/\\\">phpweblog.org</a>.','Welcome to phpWebLog.  It appears that you have had a rnsuccessful installation.  The first thing you will want to do at this point is LOGIN as \"admin\" and start customizing your site.  To do this, simply point your browser <a href=\\\"admin/\\\">here</a>.\r\n\r\nThe default password is <b>password</b>. You will definately want to change this.  Be sure to change the <b>site key</b> to something specific and unique to your site as well.\r\n\r\nAny questions, comments, or if you would like to help us develop this project, please see us at <a href=\\\"http://phpweblog.org/\\\">phpweblog.org</a>.','jason','jason@greenhell.com','http://phpweblog.org',0,'auto',1,now(),20010807133138,now())",$db);

mysql_query("INSERT INTO T_Users (Verified, Username, Password, RealName, EmailAddress, URL, Level, Comment, LastLogin, FirstLogin) VALUES ('Y','admin','5f4dcc3b5aa765d61d8327deb882cf99','Dead Bob','null@domain.com','','3','',now(),now())",$db);


mysql_query("INSERT INTO T_Blocks (Rid, Display, ShowMain, Heading, Content, Type, OrderID, URL, Cache, Birthstamp, Timestamp) VALUES ('01/08/07/5707800','l','','More Links','',3,4,'" . $G_PATH . "/backend/blocks/storylinks.inc.php',360,now(),20010807133507)",$db);


$rid = F_getRid();
$url = $G_PATH . "/backend/blocks/admin.inc.php";
mysql_query("INSERT INTO T_Blocks (Rid, Display, Heading, Type, OrderID, URL, Birthstamp, Cache) VALUES ('$rid','l','Administration','3',1,'$url',now(),'360')");

$rid = F_getRid();
$url = $G_PATH . "/backend/blocks/topics.inc.php";
mysql_query("INSERT INTO T_Blocks (Rid, Display, Heading, Type, OrderID, URL, Birthstamp, Cache) VALUES ('$rid','l','Topics','3',2,'$url',now(),'360')");

$rid = F_getRid();
$url = $G_PATH . "/backend/blocks/features.inc.php";
mysql_query("INSERT INTO T_Blocks (Rid, Display, Heading, Type, OrderID, URL, Birthstamp, Cache) VALUES ('$rid','l','Features','3',3,'$url',now(),'360')");




?>
