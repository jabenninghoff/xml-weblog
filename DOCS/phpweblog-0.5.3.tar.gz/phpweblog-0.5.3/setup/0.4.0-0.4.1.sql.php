<?
# 0.4.0 to 0.4.1

mysql_query("UPDATE T_Config SET Name = 'ParseLevel' WHERE Name = 'AllowHTML'",$db);
mysql_query("ALTER TABLE T_Blocks ADD COLUMN Cache int",$db);

?>
