<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2//EN">
<html>
<head>
<title>phpWebLog Setup</title>
<style>
	td,body {font-family: verdana, helvetica, arial;}
</style>
</head>
<body bgcolor="white" link="#000000" vlink="#006699">

<img src="images/logo.gif" alt="phpWebLog">

<table border=0 cellspacing=0 cellpadding=5 width="95%">
<tr>
<td>

<hr size=1 noshade>
<table border=0 cellspacing=1 cellpadding=1 width="100%">
<tr bgcolor="#9fb6cd">
	<td>Database: <b><?=$G_DB?></b></td>
	<td>Host: <b><?=$G_HOST?></b></td>
	<td>User: <b><?=$G_USER?></b></td>
	<td>Password: <b><?=$G_PASS?></b></td>
	<td>Port: <b><?=$G_PORT?></b></td>
</tr>
</table>
<hr size=1 noshade>
