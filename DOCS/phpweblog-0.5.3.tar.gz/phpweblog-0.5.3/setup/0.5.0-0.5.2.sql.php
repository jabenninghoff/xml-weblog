<?
# 0.5.0 to 0.5.2

mysql_query("INSERT INTO T_Config (Rid, Name, Value) VALUES (0,'ParseLevelCmt','2')",$db);

?>