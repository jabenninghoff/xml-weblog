<?
# 0.2.3 to 0.2.4

mysql_query("ALTER TABLE T_Blocks CHANGE Content Content text",$db);

mysql_query("ALTER TABLE T_Comments CHANGE Content Content text",$db);
mysql_query("ALTER TABLE T_Comments ADD AuthorURL varchar(96)",$db);

mysql_query("ALTER TABLE T_Config DROP BaseAddress",$db);
mysql_query("ALTER TABLE T_Config DROP BasePath",$db);
mysql_query("ALTER TABLE T_Config DROP Score",$db);
mysql_query("ALTER TABLE T_Config DROP Newsletter char(1)",$db);
mysql_query("ALTER TABLE T_Config ADD Backend char(1)",$db);
mysql_query("ALTER TABLE T_Config ADD Views char(1)",$db);
mysql_query("ALTER TABLE T_Config ADD AllowHTML char(1)",$db);

mysql_query("UPDATE T_Config SET Backend = '0'",$db);
mysql_query("UPDATE T_Config SET Views = '0'",$db);
mysql_query("UPDATE T_Config SET AllowHTML = '0'",$db);

mysql_query("ALTER TABLE T_Layout ADD Curve char(1)",$db);
mysql_query("UPDATE T_Layout SET Curve = '0'",$db);

mysql_query("ALTER TABLE T_Links CHANGE Hits Hits int(4)",$db);

mysql_query("ALTER TABLE T_Stories ADD AuthorURL varchar(96)",$db);
mysql_query("ALTER TABLE T_Stories CHANGE Hits Hits int(4)",$db);

?>