<?

mysql_query("DROP TABLE IF EXISTS T_Blocks",$db);
mysql_query("CREATE TABLE T_Blocks (
  Rid char(16) NOT NULL default '',
  Display char(1) NOT NULL default '',
  ShowMain char(1) NOT NULL default '',
  Heading varchar(48) NOT NULL default '',
  Content text NOT NULL default '',
  Type tinyint(4) UNSIGNED NOT NULL,
  OrderID tinyint(2) UNSIGNED NOT NULL,
  URL varchar(96) NOT NULL default '',
  Cache int(11) NOT NULL default '',
  Birthstamp datetime NOT NULL default '',
  Timestamp timestamp(14) NOT NULL,
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);

mysql_query("CREATE INDEX Display_IDX ON T_Blocks (Display)",$db);
mysql_query("CREATE INDEX OrderID_IDX ON T_Blocks (OrderID)",$db);
mysql_query("CREATE INDEX Heading_IDX ON T_Blocks (Heading)",$db);

#
# Table structure for table 'T_Pages'
#

mysql_query("DROP TABLE IF EXISTS T_Pages",$db);
mysql_query("CREATE TABLE T_Pages (
  Rid char(16) NOT NULL default '',
  Display char(1) NOT NULL default '',
  PageComments char(1) NOT NULL default '',
	Title	varchar(24) NOT NULL default '',
  Heading varchar(48) NOT NULL default '',
  Content text NOT NULL default '',
  Type tinyint(4) NOT NULL default '',
  URL varchar(96) NOT NULL default '',
  Hits int(11) UNSIGNED NOT NULL,
  Timestamp timestamp(14) NOT NULL,
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);

mysql_query("CREATE INDEX Display_IDX ON T_Pages (Display)",$db);
mysql_query("CREATE INDEX Heading_IDX ON T_Pages (Heading)",$db);
mysql_query("CREATE INDEX Title_IDX ON T_Pages (Title)",$db);

#
# Table structure for table 'T_Comments'
#

mysql_query("DROP TABLE IF EXISTS T_Comments",$db);
mysql_query("CREATE TABLE T_Comments (
  Rid char(16) NOT NULL default '',
  TopRid char(16) NOT NULL default'',
  ParentRid char(16) NOT NULL default'',
  Author varchar(32) NOT NULL default '',
  AuthorEmail varchar(96) NOT NULL default '',
  AuthorURL varchar(96) NOT NULL default '',
  Content text NOT NULL default '',
  ParseType varchar(20) NOT NULL default '',
  Host varchar(96) NOT NULL default '',
  Birthstamp datetime NOT NULL default '',
  Timestamp timestamp(14) NOT NULL,
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);

mysql_query("CREATE INDEX TopRid_IDX ON T_Comments (TopRid)",$db);
mysql_query("CREATE INDEX ParentRid_IDX ON T_Comments (ParentRid)",$db);
mysql_query("CREATE INDEX Birthstamp_IDX ON T_Comments (Birthstamp)",$db);


#
# Table structure for table 'T_Config'
#

mysql_query("DROP TABLE IF EXISTS T_Config",$db);
mysql_query("CREATE TABLE T_Config (
  Rid int(11) NOT NULL auto_increment,
  Name varchar(16) NOT NULL default '',
  Value varchar(128) NOT NULL default '',
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);

#
# Table structure for table 'T_IndexLinks'
#

mysql_query("DROP TABLE IF EXISTS T_IndexLinks",$db);
mysql_query("CREATE TABLE T_IndexLinks (
  Rid int(11) NOT NULL auto_increment,
  ParentRid varchar(16) NOT NULL default '',
  Name varchar(48) NOT NULL default '',
  URL varchar(128) NOT NULL default '',
  Hits int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);

mysql_query("CREATE INDEX ParentRid_IDX ON T_IndexLinks (ParentRid)",$db);


#
# Table structure for table 'T_IndexNames'
#

mysql_query("DROP TABLE IF EXISTS T_IndexNames",$db);
mysql_query("CREATE TABLE T_IndexNames (
  Rid int(11) NOT NULL auto_increment,
  Name varchar(48) NOT NULL default '',
  PRIMARY KEY (Rid),
  UNIQUE KEY Name(Name)
) TYPE=MyISAM",$db);

#
# Table structure for table 'T_Stories'
#

mysql_query("DROP TABLE IF EXISTS T_Stories",$db);
mysql_query("CREATE TABLE T_Stories (
  Rid char(16) NOT NULL default '',
  Verified char(1) NOT NULL default '',
  IndexDisplay char(1) default 'Y',
  Score int(11) NOT NULL default '',
  Host varchar(96) NOT NULL default '',
  Topic char(16) NOT NULL default '',
  Heading varchar(96) NOT NULL default '',
  Summary text NOT NULL default '',
  Content text NOT NULL default '',
  Author varchar(32) NOT NULL default '',
  AuthorEmail varchar(96) NOT NULL default '',
  AuthorURL varchar(96) NOT NULL default '',
  EmailComments tinyint(4) NOT NULL default '',
	ParseType varchar(20) NOT NULL default '',
  Hits int(11) UNSIGNED NOT NULL,
  Repostamp datetime NOT NULL,
  Timestamp timestamp(14) NOT NULL,
  Birthstamp datetime NOT NULL,
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);

mysql_query("CREATE INDEX Hits_IDX ON T_Stories (Hits)",$db);
mysql_query("CREATE INDEX Repostamp_IDX ON T_Stories (Repostamp)",$db);


#
# Table structure for table 'T_Topics'
#

mysql_query("DROP TABLE IF EXISTS T_Topics",$db);
mysql_query("CREATE TABLE T_Topics (
  Rid char(16) NOT NULL default '',
  Topic varchar(48) NOT NULL default '',
  ImgURL varchar(96) NOT NULL default '',
  AltTag varchar(64) NOT NULL default '',
  NoPosting ENUM('0','1') NOT NULL,
  NoComments ENUM('0','1') NOT NULL,
  IndexDefault ENUM('Y','N') NOT NULL,
  Timestamp timestamp(14) NOT NULL,
  PRIMARY KEY (Rid),
  UNIQUE KEY Topic(Topic)
) TYPE=MyISAM",$db);

mysql_query("CREATE INDEX Topic_IDX ON T_Topics (Topic)",$db);


#
# Table structure for table 'T_Content'
#

mysql_query("DROP TABLE IF EXISTS T_Content",$db);
mysql_query("CREATE TABLE T_Content (
  Rid int(11) NOT NULL auto_increment,
  Name varchar(16) NOT NULL default '',
  Value TEXT NOT NULL default '',
  PRIMARY KEY (Rid)
) TYPE=MyISAM",$db);

#
# Table structure for table 'T_Users'
#

mysql_query("DROP TABLE IF EXISTS T_Users",$db);
mysql_query("CREATE TABLE T_Users (
  Verified char(1) NOT NULL default '',
  Username varchar(16) NOT NULL default '',
  Password varchar(64) NOT NULL default '',
  RealName varchar(24) NOT NULL default '',
  EmailAddress varchar(128) NOT NULL default '',
  URL varchar(128) NOT NULL default '',
  Level char(1) NOT NULL default '',
  Comment text NOT NULL default '',
	LastLogin datetime NOT NULL default '',
  FirstLogin datetime NOT NULL default '',
  PRIMARY KEY (Username)
) TYPE=MyISAM",$db);


?>
