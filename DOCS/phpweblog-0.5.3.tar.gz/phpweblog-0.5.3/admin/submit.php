<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
include("./auth.inc.php");

# ensure we are coming from ourself
if (empty($HTTP_POST_VARS) || !F_matchok()) {
	$msg	= urlencode("Access denied!");
	F_logAccess("Access denied trying to submit.");
	header("Location:$G_URL/?msg=$msg");
	exit();
}
# ensure we are accessed to do this
if (!F_isLevel(3)) {
	$msg	= urlencode("Access denied!");
	F_logAccess("Access denied trying to submit as non-admin.");
	header("Location:$G_URL/?msg=$msg");
	exit();
}

switch ($what) {

case "block":
#	if ($Type == 3) {
#		$URL = "$G_PATH/backend/blocks/$SysBlock.inc.php";
#		$Content = "";
#	}
	if ($Type>0 && !@fopen($URL,"r")) {
		if ($Type == 3) {
			F_logAccess("Block file not found: $URL");
			$msg	= urlencode("Error! Block file not found: <b>$URL</b>");
		} else {
			F_logAccess("URL/FILE not found: $URL");
			$msg	= urlencode("Error! URL/FILE not found: <b>$URL</b>");
		}
		header("Location:$G_URL/admin/blocks.php?msg=$msg");
		exit();
	}
	if ($Type == 3 && F_count("T_Blocks",URL,$URL)) {
		$msg  = urlencode("Only one system block of this type is allowed.");
		header("Location:$G_URL/admin/blocks.php?msg=$msg");
    exit();
	}
	$sql	= "INSERT INTO T_Blocks ";
	$sql	.= "(Rid,Heading,Content,URL,Display,Cache,Type,OrderID,Birthstamp,Timestamp) ";
	$sql	.= "VALUES (";
	$sql	.= "'" . F_getRid() . "',";
	$sql	.= "'" . F_in($Heading) . "',";
	$sql	.= "'" . F_in($Content) . "',";
	$sql	.= "'" . F_in($URL) . "',";
	$sql	.= "'" . $Display . "',";
	$sql	.= "'" . $Cache . "',";
	$sql	.= $Type . ",";
	$sql	.= $OrderID . ",";
	$sql	.= "now(),now())";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Added new block \"$Heading\"");
	if ($RET<1) {
		F_error("Unable to insert block.");
	}
	header("Location:$G_URL/admin/blocks.php");
break;

case "page":
	if ($Type==2 && !@fopen($URL,"r")) {
		F_logAccess("URL/FILE not found: $URL");
		$msg	= urlencode("Error! URL/FILE not found: <b>$URL</b>");
		header("Location:$G_URL/admin/pages.php?msg=$msg");
		exit();
	} elseif ($Type==1 && !file_exists($URL . "/index.php")) {
		F_logAccess("Addon not found: $URL");
		$msg	= urlencode("Error! Addon not found: <b>$URL</b>");
		header("Location:$G_URL/admin/pages.php?msg=$msg");
		exit();
	}
	$pc		= ($PageComments=="on" ? "1" : "0");
	$sql	= "INSERT INTO T_Pages ";
	$sql	.= "(Rid,Title,Heading,Content,URL,Display,PageComments,Type,Hits,Timestamp) ";
	$sql	.= "VALUES (";
	$sql	.= "'" . F_getRid() . "',";
	$sql	.= "'" . F_in($Title) . "',";
	$sql	.= "'" . F_in($Heading) . "',";
	$sql	.= "'" . F_in($Content) . "',";
	$sql	.= "'" . F_in($URL) . "',";
	$sql	.= "'" . $Display . "',";
	$sql	.= "'" . $pc . "',";
	$sql	.= $Type . ",";
	$sql	.= "0,";
	$sql	.= "now())";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Added new page \"$Title\"");
	if ($RET<1) {
		F_error("Unable to insert page.");
	}
	header("Location:$G_URL/admin/pages.php");
break;


case "topic":
	$NoPosting = !empty($NoPosting) ? 1 : 0;
	$NoComments = !empty($NoComments) ? 1 : 0;
	$IndexDefault = !empty($IndexDefault) ? "N" : "Y";

	$sql	= "INSERT INTO T_Topics ";
	$sql	.= "(Rid,Topic,ImgURL,AltTag,NoPosting,NoComments,IndexDefault,Timestamp) ";
	$sql	.= "VALUES (";
	$sql	.= "'" . F_getRid() . "',";
	$sql	.= "'" . F_in($Topic) . "',";
	$sql	.= "'" . F_in($URL) . "',";
	$sql	.= "'" . F_in($AltTag) . "',";
	$sql	.= "'" . $NoPosting . "',";
	$sql	.= "'" . $NoComments . "',";
	$sql	.= "'" . $IndexDefault . "',";
	$sql	.= "now()";
	$sql	.= ")";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Added new topic \"$Topic\"");
	if ($RET<1) {
		F_error("Unable to insert topic.");
	}
	header("Location:$G_URL/admin/topics.php");
break;


case "user":
	$sql	= "INSERT INTO T_Users ";
	$sql	.= "(Verified,Username,Password,RealName,EmailAddress,URL,Level,Comment,FirstLogin) ";
	$sql	.= "VALUES (";
	$sql	.= "'Y',";
	$sql	.= "'" . F_in($Username) . "',";
	$sql	.= "'" . F_in(md5($Password)) . "',";
	$sql	.= "'" . F_in($RealName) . "',";
	$sql	.= "'" . F_in($EmailAddress) . "',";
	$sql	.= "'" . F_in($URL) . "',";
	$sql	.= "'" . F_in($Level) . "',";
	$sql	.= "'" . F_in($Comment) . "',";
	$sql	.= "now()";
	$sql	.= ")";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Added new user \"$Username\"");
	if ($RET<1) {
		F_error("Unable to insert user.");
	}
	header("Location:$G_URL/admin/users.php");
break;


case "layout":
	switch ($layout_mode) {
	case "View/Load":
		$msg	= urlencode("Previewing layout $name");
		header("Location:$G_URL/admin/layout.php?preview_layout=$name&msg=$msg");
	break;

	case "Kill":
		if ($name==$CONF["Layout"]) {
			$msg	= urlencode("You cannot kill the active layout. Nothing changed.");
			header("Location:$G_URL/admin/layout.php?msg=$msg");
		} else {
			$foo	= $G_PATH . "/backend/layouts/" . $name . ".xlay";
			$RET	= unlink($foo);
			if ($RET<1) {
				F_error("Unable to delete layout.");
			} else {
				$msg	= urlencode("Layout deleted: <b>$foo</b>.");
				header("Location:$G_URL/admin/layout.php?msg=$msg");
			}
		}
		F_logAccess("Deleted layout \"$name\"");
	break;

	case "Add/Update":
		export_layout($HTTP_POST_VARS);
		$foo	= $G_PATH . "/backend/layouts/" . $Layout . ".xlay";
		$msg	= urlencode("Layout file added as <b>$foo</b>.");
		F_logAccess("Updated layout \"$Layout\"");
		header("Location:$G_URL/admin/layout.php?preview_layout=$Layout&msg=$msg");
	break;
	}
break;

case "site":
	$tmp	= urlencode("Changes Saved.");
	$array	= $HTTP_POST_VARS["site"];
	for (reset($array);$k=key($array);next($array)) {
		# update configuration
		$sql	= "UPDATE T_Config set ";
		$sql	.= "Value = '" . $array[$k] . "' ";
	 	$sql    .= "WHERE Name = '" . $k . "'";    
		@mysql_query($sql,$db);
	}
	if ($HTTP_COOKIE_VARS["phpWebLog"]!=rot13($SiteKey)) {
		$name   = $SiteKey . "_admin";
		setcookie(md5($name),md5(rot13($SiteKey)),0,"/","",0);
	}
	F_logAccess("Updated site configuration.");
	header("Location:$G_URL/admin/site.php?msg=$tmp");
break;

case "story":
	$tmp	= urlencode("Changes Saved.");
	$array	= $HTTP_POST_VARS["story"];
	for (reset($array);$k=key($array);next($array)) {
		# update configuration
		$sql	= "UPDATE T_Config set ";
		$sql	.= "Value = '" . $array[$k] . "' ";
	 	$sql    .= "WHERE Name = '" . $k . "'";    
		@mysql_query($sql,$db);
	}
	F_logAccess("Updated story configuration.");
	header("Location:$G_URL/admin/story.php?msg=$tmp");
break;

case "extended":
	$tmp	= urlencode("Changes Saved.");
	$array	= $HTTP_POST_VARS["extended"];
	for (reset($array);$k=key($array);next($array)) {
		# update configuration
		$sql	= "UPDATE T_Config set ";
		$sql	.= "Value = '" . $array[$k] . "' ";
	 	$sql    .= "WHERE Name = '" . $k . "'";    
		@mysql_query($sql,$db);
	}
	# add link index name
	if (!empty($IndexName)) {
		$sql	= "INSERT INTO T_IndexNames (Name) VALUES ('$IndexName')";
		F_logAccess("Added Index Link $IndexName");
		@mysql_query($sql,$db);
	}
	# kill link index name
	if (!empty($IndexKills) && $action=="kill") {
		$sql	= "DELETE FROM T_IndexNames WHERE Rid=0 ";
		for ($i=0;$i<count($IndexKills);$i++) {
			$sql	.= "OR Name='$IndexKills[$i]'";
			F_logAccess("Removed Index Link $IndexKills[$i]");
		}
		@mysql_query($sql,$db);
		# kill all associated story links as well
		$sql	= "DELETE FROM T_IndexLinks WHERE Rid=0 ";
		for ($i=0;$i<count($IndexKills);$i++) {
			$sql	.= "OR Name='$IndexKills[$i]'";
		}
		@mysql_query($sql,$db);
	}

	F_logAccess("Updated extended configuration.");
	header("Location:$G_URL/admin/extended.php?msg=$tmp");
break;


case "content":
	$tmp	= urlencode("Changes Saved.");
	$array  = $HTTP_POST_VARS["content"];
	for (reset($array);$k=key($array);next($array)) {
		# update configuration
		$sql	= "UPDATE T_Content set ";
		$sql	.= "Value = '" . trim($array[$k]) . "' ";
	 	$sql    .= "WHERE Name = '" . $k . "'";    
		@mysql_query($sql,$db);
	}
	F_logAccess("Updated site content.");
	header("Location:$G_URL/admin/content.php?msg=$tmp");
break;


}

?>
