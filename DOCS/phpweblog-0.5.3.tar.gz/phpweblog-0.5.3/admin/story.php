<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=3;
include("./auth.inc.php");

include("../include/header.inc.php");

$VAR["Heading"] = "Story Control";

$VAR["Content"] = "
<form	action	= \"$G_URL/admin/submit.php\"
	name	= \"config\"
	method	= \"POST\">
<table
	cellpadding	= 0
	cellspacing	= 3
	width	= 100%
	border	= 0>

<tr>
<td>Allow Story Contributions</td>
<td>
<input type=radio name=\"story[AllowContrib]\" value=\"0\" " . F_radio($CONF["AllowContrib"],0) . "> No
<input type=radio name=\"story[AllowContrib]\" value=\"1\" " . F_radio($CONF["AllowContrib"],1) . "> Yes
</td>
</tr>

<tr>
<td>Story Moderation</td>
<td>
<input type=radio name=\"story[Moderation]\" value=\"0\" " . F_radio($CONF["Moderation"],0) . "> None
<input type=radio name=\"story[Moderation]\" value=\"1\" " . F_radio($CONF["Moderation"],1) . "> Yes
<input type=radio name=\"story[Moderation]\" value=\"2\" " . F_radio($CONF["Moderation"],2) . "> Yes / Notify
</td>
</tr>

<tr>
<td>Summary Length</td>
<td>
<input type=text name=\"story[SummaryLength]\" size=4 maxlength=4 value=\"" . $CONF["SummaryLength"] . "\">
characters (0=disable)
</td>
</tr>

<tr>
<td>'Hard' Kills</td>
<td>
<input type=radio name=\"story[HardKill]\" value=\"0\" " . F_radio($CONF["HardKill"],0) . "> No
<input type=radio name=\"story[HardKill]\" value=\"1\" " . F_radio($CONF["HardKill"],1) . "> Yes
<small>(Completely removes killed items from the database)</small>
</td>
</tr>

<tr>
<td>Limit Stories</td>
<td>Display <input type=text name=\"story[LimitNews]\" size=2 maxlength=2 value=\"" . $CONF["LimitNews"] . "\">
stories per page
</td>
</tr>

<tr>
<td>Limit Index Display</td>
<td>
<input type=radio name=\"story[LimitIndexed]\" value=\"0\" " . F_radio($CONF["LimitIndexed"],0) . "> No
<input type=radio name=\"story[LimitIndexed]\" value=\"1\" " . F_radio($CONF["LimitIndexed"],1) . "> Yes <small>(Limit which stories are displayed on the site index)</small></td>
</tr>

<tr>
<td>Enable User Comments</td>
<td>
<input type=radio name=\"story[Comments]\" value=\"0\" " . F_radio($CONF["Comments"],0) . "> No
<input type=radio name=\"story[Comments]\" value=\"1\" " . F_radio($CONF["Comments"],1) . "> Yes
<input type=radio name=\"story[Comments]\" value=\"2\" " . F_radio($CONF["Comments"],2) . "> Threaded
&nbsp;&nbsp;Sort By
<select	name	= \"story[CommentSort]\">
<option value	= \"asc\"" . F_select($CONF["CommentSort"],"asc") . ">Ascending</option>
<option value	= \"desc\"" . F_select($CONF["CommentSort"],"desc") . ">Descending</option>
</select>
</td>
</tr>

<tr>
<td>Allow Anonymous Comments</td>
<td>
<input type=radio name=\"story[AllowAnon]\" value=\"0\" " . F_radio($CONF["AllowAnon"],0) . "> No
<input type=radio name=\"story[AllowAnon]\" value=\"1\" " . F_radio($CONF["AllowAnon"],1) . "> Yes</td>
</tr>

<tr>
<td>Who May Post</td>
<td>
<select	name	= \"story[AuthPostOnly]\">
<option	value	= \"0\" " . F_select($CONF["AuthPostOnly"],"0") . ">Anyone</option>
<option value	= \"1\" " . F_select($CONF["AuthPostOnly"],"1") . ">Registered Users</option>
<option value	= \"2\" " . F_select($CONF["AuthPostOnly"],"2") . ">Registered Users or Anonymous </option>
</select>
</td>
</tr>

<tr>
<td>Registered Users Post As</td>
<td>
<select	name	= \"story[UsersPostAs]\">
<option	value	= \"0\" " . F_select($CONF["UsersPostAs"],"0") . ">Anything</option>
<option value	= \"1\" " . F_select($CONF["UsersPostAs"],"1") . ">Username Only</option>
<option value	= \"2\" " . F_select($CONF["UsersPostAs"],"2") . ">Real Name Only</option>
<option value	= \"3\" " . F_select($CONF["UsersPostAs"],"3") . ">Username or Real Name</option>
</select>
</td>
</tr>

<tr>
<td>Story Page Splitting</td>
<td>
<input type=radio name=\"story[SplitPages]\" value=\"0\" " . F_radio($CONF["SplitPages"],0) . "> No
<input type=radio name=\"story[SplitPages]\" value=\"1\" " . F_radio($CONF["SplitPages"],1) . "> Yes</td>
</tr>

<tr>
<td>Allow Comment Mailing</td>
<td>
<input type=radio name=\"story[EmailComments]\" value=\"0\" " . F_radio($CONF["EmailComments"],0) . "> No
<input type=radio name=\"story[EmailComments]\" value=\"1\" " . F_radio($CONF["EmailComments"],1) . "> Yes
<small>(Mails comments to poster)</small></td>
</tr>

<tr>
<td>Topic Sorting</td>
<td>
<select	name	= \"story[TopicSort]\">
<option	value	= \"id\" " . F_select($CONF["TopicSort"],"id") . ">No Sorting</option>
<option value	= \"asc\" " . F_select($CONF["TopicSort"],"asc") . ">Ascending</option>
<option value	= \"desc\" " . F_select($CONF["TopicSort"],"desc") . ">Descending</option>
<option value	= \"brief\" " . F_select($CONF["TopicSort"],"brief") . ">Brief</option>
</select>
</td>
</tr>

<tr>
<td>Allow User Save</td>
<td>
<input type=radio name=\"story[SaveInfo]\" value=\"0\" " . F_radio($CONF["SaveInfo"],0) . "> No
<input type=radio name=\"story[SaveInfo]\" value=\"1\" " . F_radio($CONF["SaveInfo"],1) . "> Yes
<small>(Sends cookies)</small></td>
</tr>

<tr>
<td>Export RDF/RSS Stories</td>
<td>
<input type=radio name=\"story[Backend]\" value=\"0\" " . F_radio($CONF["Backend"],0) . "> No
<input type=radio name=\"story[Backend]\" value=\"1\" " . F_radio($CONF["Backend"],1) . "> Yes
<br />RDF filename:<input 	type=text name=\"story[BackendFile]\" size=12 maxlength=128 value=\"" . $CONF["BackendFile"] . "\"></td>
</tr>

<tr>
<td>Story Mailing List</td>
<td>
<input type=radio name=\"story[MailingList]\" value=\"0\" " . F_radio($CONF["MailingList"],0) . "> No
<input type=radio name=\"story[MailingList]\" value=\"1\" " . F_radio($CONF["MailingList"],1) . "> Yes
<br />Email:<input 	type=text name=\"story[MailingAddress]\" size=30 maxlength=128 value=\"" . $CONF["MailingAddress"] . "\"></td>
</tr>


<tr>
<td 	colspan	= 2>
<input	type	= hidden
	name	= what
	value	= story>
<input	type	= submit
	value	= \"Save Changes\">
</td>
</tr>

</table>
</form>
";

	F_drawMain($VAR);
	include("../include/footer.inc.php");
?>
