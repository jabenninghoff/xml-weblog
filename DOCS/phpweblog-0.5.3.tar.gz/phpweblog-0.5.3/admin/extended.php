<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=3;
include("./auth.inc.php");

include("../include/header.inc.php");

$VAR["Heading"] = "Extended Configuration";

$VAR["Content"] = "
<form action= \"$G_URL/admin/submit.php\" name=\"config\" method=\"POST\">

<table cellpadding=2 cellspacing=1 width=\"100%\" border=0>

<tr>
<td>Enable Mail-Story-To-Friend</td>
<td>
<input type=radio name=\"extended[MailFriend]\" value=\"0\" " . F_radio($CONF["MailFriend"],0) . "> No
<input type=radio name=\"extended[MailFriend]\" value=\"1\" " . F_radio($CONF["MailFriend"],1) . "> Yes
</td>
</tr>

<tr>
<td>Enable Print-Friendly Page</td>
<td>
<input type=radio name=\"extended[PrintStory]\" value=\"0\" " . F_radio($CONF["PrintStory"],0) . "> No
<input type=radio name=\"extended[PrintStory]\" value=\"1\" " . F_radio($CONF["PrintStory"],1) . "> Yes
</td>
</tr>

<tr>
<td>Show Author IP</td>
<td>
<input type=radio name=\"extended[ShowIP]\" value=\"0\" " . F_radio($CONF["ShowIP"],0) . "> No
<input type=radio name=\"extended[ShowIP]\" value=\"1\" " . F_radio($CONF["ShowIP"],1) . "> Yes
</td>
</tr>

<tr>
<td>Show Hit Tracking</td>
<td>
<input type=radio name=\"extended[ShowHits]\" value=\"0\" " . F_radio($CONF["ShowHits"],0) . "> No
<input type=radio name=\"extended[ShowHits]\" value=\"1\" " . F_radio($CONF["ShowHits"],1) . "> Yes
</td>
</tr>

<tr>
<td>Enable Story Archive</td>
<td>
<input type=radio name=\"extended[Archive]\" value=\"0\" " . F_radio($CONF["Archive"],0) . "> No
<input type=radio name=\"extended[Archive]\" value=\"1\" " . F_radio($CONF["Archive"],1) . "> Yes
</td>
</tr>

<tr>
<td>Enable Future Posting</td>
<td>
<input type=radio name=\"extended[FuturePost]\" value=\"0\" " . F_radio($CONF["FuturePost"],0) . "> No
<input type=radio name=\"extended[FuturePost]\" value=\"1\" " . F_radio($CONF["FuturePost"],1) . "> Yes
</td>
</tr>

<tr>
<td colspan	= 2>
<input type=hidden name=what value=extended>
<input type=submit value=\"Save Changes\"></td>
</tr>

</table>
<p>
";

F_drawMain($VAR);


$VAR["Heading"] = "Extended Story Configuration";


$VAR["Content"] = "
<table cellpadding=2 cellspacing=1 width=\"100%\" border=0>
";

# index links
$VAR["Content"]	.= "<tr><td>Index Names<br />(story links)</td><td>";

$VAR["Content"]	.= "<table border=0 cellpadding=0 cellspacing=0 width=\"100%\"><tr>";
$VAR["Content"]	.= "<td><select name=\"IndexKills[]\" size=5 multiple width=100 style=\"width: 100px\">";

# list index names
$sql	= "SELECT * FROM T_IndexNames";
$result	= mysql_query($sql,$db);
$nrows	= mysql_num_rows($result);
for ($i=0;$i<$nrows;$i++) {
	$A	= mysql_fetch_array($result);
	$VAR["Content"] .= sprintf("<option>%s</option>\n",$A["Name"]);
}

$VAR["Content"]	.= "</select></td>";
$VAR["Content"]	.= "<td><input type=submit name=\"action\" value=\"kill\" onclick= \"return getconfirm();\">";
$VAR["Content"]	.= "<br /><small>(Killing index names will kill all associated";
$VAR["Content"] .= " story links as well)</small>";
$VAR["Content"]	.= "</td></tr></table>\n";

$VAR["Content"] .= "</td></tr>";
$VAR["Content"] .= "
<tr>
<td>Add new Link</td>
<td><input type=text name=IndexName size=40 maxlength=48></td>
</tr>
";


$VAR["Content"] .= "
<tr>
<td 	colspan	= 2>
<input type=hidden name=what value=extended>
<input type=submit value	= \"Add\">
</td>
</tr>

<tr>
<td colspan=2>
<em>Tip: An story link name is the name of a link associated to all stories.
For example, a story may have a <b>Related Link</b>, <b>Homepage</b>, or
<b>More Information</b> link.</em>
</td>
</tr>

</table>
</form>
";

F_drawMain($VAR);
include("../include/footer.inc.php");
?>
