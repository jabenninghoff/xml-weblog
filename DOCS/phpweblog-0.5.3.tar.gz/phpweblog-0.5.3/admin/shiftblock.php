<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=3;
include("./auth.inc.php");

/*== determine course of action ==*/
if (!empty($dir) && F_matchok()) {
	switch ($dir) {
		case "up":
			$shiftsql	.= "SET OrderID = OrderID-1";
		break;
		case "down":
			$shiftsql	.= "SET OrderID = OrderID+1";
		break;
		case "left":
			$shiftsql	.= "SET Display = 'l'";
		break;
		case "right":
			$shiftsql	.= "SET Display = 'r'";
		break;
	}


	/*== shift the block to the new position ==*/
	$sql	= "UPDATE T_Blocks ";
	$sql	.= $shiftsql;
	$sql	.= " WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	#echo $sql;
	F_logAccess("Shifted block $item $dir");
	if ($RET<1) {
		F_error("Unable to shift block $item.");
	}

	$msg	= urlencode("Shifted block $dir.");
	header("Location:$where?msg=$msg");

}
?>
