<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=2;
include("./auth.inc.php");


if ($what=="T_Comments") {

	F_killChildren("T_Comments",$item);
	header("location:$G_URL/$where");
	exit();

} elseif ($what=="T_Stories" && $CONF["HardKill"] == 1) {

	/*== destroy record ==*/
	$sql	= "DELETE FROM T_Stories ";
	$sql	.= "WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted story $item");
	if ($RET<1) {
		F_error("Unable to delete item $item from stories");
	}
	$sql	= "DELETE FROM T_Comments ";
	$sql	.= "WHERE TopRid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted comments for story $item");
	if ($RET<1) {
		F_error("Unable to delete item $item from comments.");
	}
	$sql	= "DELETE FROM T_IndexLinks ";
	$sql	.= "WHERE ParentRid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted index links for story $item");
	if ($RET<1) {
		F_error("Unable to delete item $item from index links.");
	}
	export_rdf();
	header("Location:$where");
	exit();

} elseif ($what=="T_Stories" && $CONF["HardKill"] == 0) {
	$sql 	= "UPDATE T_Stories ";
	$sql 	.= "SET Verified = 'D' ";
	$sql 	.= "WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Soft killed story $item");
	if ($RET<1) {
		F_error("Unable to delete story $rid.");
	}
	export_rdf();
	header("Location:$where");
	exit();

} elseif ($what=="T_Topics") {

	/* get array of stories */
	$sql	= "SELECT Rid FROM T_Stories ";
	$sql	.= "WHERE Topic = '$item'";
	$result	= @mysql_query($sql,$db);
	if ($result<1) {
		F_error("Unable to select $item from stories.");
	}
	$cid	= array();
	for ($i=0;$i<mysql_num_rows($result);$i++) {
		$cid[$i]	= mysql_result($result, $i);
	}

	/* delete comments associated with deleted stories */
	$sql	= "DELETE FROM T_Comments WHERE ";
	for ($i=0;$i<sizeof($cid);$i++) {
		$sql	.= sprintf("TopRid = '%s' OR ",$cid[$i]);
	}
	$sql	.= "Rid = 'NULL'";
	$RET	= @mysql_query($sql,$db);
	if ($RET<1) {
		F_error("Unable to delete comments.");
	}

	/* delete index links associated with deleted stories */
	$sql	= "DELETE FROM T_IndexLinks WHERE ";
	for ($i=0;$i<sizeof($cid);$i++) {
		$sql	.= sprintf("ParentRid = '%s' OR ",$cid[$i]);
	}
	$sql	.= "ParentRid = 'NULL'";
	$RET	= @mysql_query($sql,$db);
	if ($RET<1) {
		F_error("Unable to delete index links.");
	}

	/* delete stories associated with deleted topic */
	$sql	= "DELETE FROM T_Stories ";
	$sql	.= "WHERE Topic = '$item'";
	$RET	= @mysql_query($sql,$db);
	if ($RET<1) {
		F_error("Unable to delete topic from stories.");
	}

	/* destroy the topic itself */
	$sql	= "DELETE FROM T_Topics ";
	$sql	.= "WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted topic $item");
	if ($RET<1) {
		F_error("Unable to delete item $item from topics");
	}

	export_rdf();
	header("Location:$G_URL/admin/topics.php");
	exit();

} elseif ($what=="T_Blocks") {

	$sql	= "DELETE FROM $what ";
	$sql	.= "WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted block $item");
	if ($RET<1) {
		F_error("Unable to delete block $item");
	}

} elseif ($what=="T_Pages") {

	$sql	= "DELETE FROM $what ";
	$sql	.= "WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted item $item from $what");
	if ($RET<1) {
		F_error("Unable to delete page $item");
	}
	$sql	= "DELETE FROM T_Comments ";
	$sql	.= "WHERE TopRid = '$item'";
	$RET	= @mysql_query($sql,$db);
	if ($RET<1) {
		F_error("Unable to delete comments for page $item");
	}

} elseif ($what=="T_Users") {

	$sql	= "DELETE FROM $what ";
	$sql	.= "WHERE Username = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted user $item");
	if ($RET<1) {
		F_error("Unable to delete user $item");
	}

} else {

	/*== destroy anything else ==*/
	$sql	= "DELETE FROM $what ";
	$sql	.= "WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted item $item from $what");
	if ($RET<1) {
		F_error("Unable to delete item $item from $what");
	}

}

header("Location:$G_URL/$where");

?>
