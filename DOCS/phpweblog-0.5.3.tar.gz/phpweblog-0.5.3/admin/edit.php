<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=2;
include("./auth.inc.php");

if ($confirm=="yes" && F_matchOK()) {
	switch ($what) {
		case "T_Stories";
			$sql	= "UPDATE T_Stories SET ";
			$sql	.= "Heading = '" . $Heading . "',";
			$sql	.= "Topic = '" . $Topic . "',";
			if ($CONF["FuturePost"]>0 && checkdate($BSMonth, $BSDay, $BSYear) && $BSHour >= 0 && BSHour <= 24 && BSMinute >= 0 && BSMinute <= 60) {
				$birthstamp = $BSYear . $BSMonth . $BSDay . $BSHour . $BSMinute . "00";
				$sql	.= "Birthstamp = '" . $birthstamp . "',";
			}
			$sql	.= "Verified = '" . $Verified . "',";
			$sql 	.= "IndexDisplay = '". $IndexDisplay ."',";
			$sql	.= "Author = '" . $Author . "',";
			$sql	.= "AuthorEmail = '" . $AuthorEmail . "',";
			$sql	.= "AuthorURL = '" . $AuthorURL . "',";
			$tmp	= $EmailComments == "on" ? 1 : 0;
			$sql	.= "EmailComments = " . $tmp . ",";
			$sql	.= "Summary = '" . F_in($Summary) . "',";
			$sql	.= "Content = '" . F_in($Content) . "',";
			$sql	.= "ParseType = '" . $ParseType . "'";
			$sql	.= " WHERE Rid = '$item' ";
			$RET	= @mysql_query($sql,$db);
			F_logAccess("Updated story $item");
			if ($RET<1) {
				F_error("Unable to update story.");
			}
			export_rdf();
			if (!empty($Links)) F_updateIndexLinks($Links,$item);
			header("Location:" . urldecode($where));
			exit();
		break;
		case "T_Blocks":
			if ($Type>0 && !@fopen($URL,"r")) {
				if ($Type == 3) {
					# system block not found
					$msg	= urlencode("Error! Block file not found: <b>$URL</b>");
				} else {
					# url not found
					$msg	= urlencode("Error! URL/PATH not found: <b>$URL</b>");
				}
				header("Location:$G_URL/admin/blocks.php?msg=$msg");
				exit();
			}
			$sm		= ($ShowMain=="on" ? "1" : "0");
			$sql	= "UPDATE T_Blocks SET ";
			$sql	.= "Heading = '" . F_in($Heading) . "',";
			$sql	.= "Type 	= '" . $Type . "',";
			$sql	.= "Display = '" . $Display . "',";
			$sql	.= "ShowMain = '" . $sm . "',";
			$sql	.= "OrderID = '" . $OrderID . "',";
			$sql	.= "Cache = '" . $Cache . "',";
			$sql	.= "Content = '" . F_in($Content) . "',";
			if ($nocache=="on") {
				$sql	.= "Birthstamp	= now(),";
				$sql	.= "Timestamp	= now(),";
			}
			$sql	.= "URL 	= '" . $URL . "'";
			$sql	.= " WHERE Rid = '$item' ";
			$RET	= @mysql_query($sql,$db);
			F_logAccess("Updated block $item");
			if ($RET<1) {
				F_error("Unable to update block.");
			}
			header("Location:$G_URL/$where");
			exit();
		break;
		case "T_Pages":
			if ($Type>0 && !@fopen($URL,"r")) {
				# url not found
				$msg	= urlencode("Error! URL/PATH not found: <b>$URL</b>");
				header("Location:$G_URL/admin/blocks.php?msg=$msg");
				exit();
			}
			$pc		= ($PageComments=="on" ? "1" : "0");
			$sql	= "UPDATE T_Pages SET ";
			$sql	.= "Title = '" . F_in($Title) . "',";
			$sql	.= "Heading = '" . F_in($Heading) . "',";
			$sql	.= "Type 	= '" . $Type . "',";
			$sql	.= "Display = '" . $Display . "',";
			$sql	.= "PageComments = '" . $pc . "',";
			$sql	.= "Content = '" . F_in($Content) . "',";
			$sql	.= "URL 	= '" . $URL . "',";
			$sql	.= "Hits	= '" . $Hits . "'";
			$sql	.= " WHERE Rid = '$item' ";
			$RET	= @mysql_query($sql,$db);
			F_logAccess("Updated page $item");
			if ($RET<1) {
				F_error("Unable to update page.");
			}
			header("Location:$G_URL/$where");
			exit();
		break;
		case "T_Comments":
			$sql	= "UPDATE T_Comments set ";
			$sql	.= "Author = '" . F_in($Author) . "',";
			$sql	.= "AuthorEmail = '" . F_in($AuthorEmail) . "',";
			$sql	.= "AuthorURL = '" . F_in($AuthorURL) . "',";
			$sql	.= "Content = '" . F_in($Content) . "',";
			$sql	.= "ParseType = '" . $ParseType . "'";
			$sql	.= " WHERE Rid = '$item' ";
			$RET	= @mysql_query($sql,$db);
			F_logAccess("Updated comment $item");
			if ($RET<1) {
				F_error("Unable to update comment.");
			}
			header("Location:$G_URL/" . urldecode($where));
			exit();
		break;
		case "T_Topics":
			$sql	= "UPDATE T_Topics set ";
			$sql	.= "Topic = '" . F_in($Topic) . "',";
			$sql	.= "AltTag = '" . F_in($AltTag) . "',";
			$sql	.= "ImgURL = '" . F_in($ImgURL) . "',";
			$sql	.= "NoPosting = '" . $NoPosting . "',";
			$sql	.= "NoComments = '" . $NoComments . "',";
			$sql	.= "IndexDefault = '" . $IndexDefault . "'";
			$sql	.= " WHERE Rid = '$item' ";
			$RET	= @mysql_query($sql,$db);
			F_logAccess("Updated topic $item");
			if ($RET<1) {
				F_error("Unable to update topic.");
			}
			header("Location:$G_URL/admin/topics.php");
			exit();
		break;
		case "T_Users":
			$sql	= "UPDATE T_Users set ";
			$sql	.= "Verified = '" . $Verified . "',";
			if (!empty($Password)) {
				$sql	.= "Password = '" . F_in(md5($Password)) . "',";
			}
			$sql	.= "RealName = '" . F_in($RealName) . "',";
			$sql	.= "EmailAddress = '" . F_in($EmailAddress) . "',";
			$sql	.= "URL = '" . F_in($URL) . "',";
			$sql	.= "Level = '" . $Level . "',";
			$sql	.= "Comment = '" . F_in($Comment) . "'";
			$sql	.= " WHERE Username = '$item' ";
			$RET	= @mysql_query($sql,$db);
			F_logAccess("Updated user $item");
			if ($RET<1) {
				F_error("Unable to edit user $item");
			}
			header("Location:$G_URL/admin/users.php");
			exit();
		break;
	}
} else {
	switch ($what) {
		case "T_Stories":
			include("../include/header.inc.php");

			$sql	= "SELECT * FROM T_Stories ";
			$sql	.= "WHERE Rid = '$item'";
			$result	= @mysql_query($sql,$db);
			if ($result<1) {
				F_error("Unable to select story.");
			}
			$A	= mysql_fetch_array($result);

			$VAR["Heading"] = "Edit : Story : " . $A["Rid"];
			$VAR["Content"] = "<form\taction\t= \"$PHP_SELF\"\n";
			$VAR["Content"] .= "\tmethod\t= post>\n";

			$VAR["Content"] .= "<table\n";
			$VAR["Content"] .= "\tborder\t= \"0\"\n";
			$VAR["Content"] .= "\tcellspacing\t= \"1\"\n";
			$VAR["Content"] .= "\tcellpadding\t= \"2\"\n";
			$VAR["Content"] .= "\twidth\t= \"100%\">\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Verified:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<select\tname\t=\"Verified\">\n";
			$VAR["Content"]	.= "<option value=\"Y\" " . ($A["Verified"]=="Y" ? "selected" : "") . ">Yes</option>\n";
			$VAR["Content"]	.= "<option value=\"N\" " . ($A["Verified"]=="N" ? "selected" : "") . ">No</option>\n";
			$VAR["Content"] .= "</select>\n</td></tr>\n";
			
			if ($CONF["LimitIndexed"]>0) {
				$VAR["Content"] .= "<tr>\n";
				$VAR["Content"] .= "<td>\n";
				$VAR["Content"] .= "Index Display:</td>\n";
				$VAR["Content"] .= "<td>\n";
				$VAR["Content"] .= "<select\tname\t=\"IndexDisplay\">\n";
				$VAR["Content"]	.= "<option value=\"Y\" " . ($A["IndexDisplay"]=="Y" ? "selected" : "") . ">Yes</option>\n";
				$VAR["Content"]	.= "<option value=\"N\" " . ($A["IndexDisplay"]=="N" ? "selected" : "") . ">No</option>\n";
				$VAR["Content"] .= "</select>\n</td></tr>\n";
			}

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Name:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"Author\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A[Author]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 32></td></tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Email:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"AuthorEmail\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A[AuthorEmail]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 96></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "URL:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"AuthorURL\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A[AuthorURL]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 96></td>\n";
			$VAR["Content"] .= "</tr>\n";
			if ($CONF["FuturePost"]>0) {
				$bsvals = split("[^[:digit:]]",$A["Birthstamp"]);
				$dateD["BSYear"]["Max"] = date("Y") + 2;
				$dateD["BSYear"]["Min"] = 1998;
				$dateD["BSYear"]["Val"] = $bsvals[0];
				$dateD["BSMonth"]["Max"] = 12;
				$dateD["BSMonth"]["Min"] = 1;
				$dateD["BSMonth"]["Val"] = $bsvals[1];
				$dateD["BSDay"]["Max"] = 31;
				$dateD["BSDay"]["Min"] = 1;
				$dateD["BSDay"]["Val"] = $bsvals[2];
				$dateD["BSHour"]["Max"] = 23;
				$dateD["BSHour"]["Min"] = 0;
				$dateD["BSHour"]["Val"] = $bsvals[3];
				$dateD["BSMinute"]["Max"] = 60;
				$dateD["BSMinute"]["Min"] = 0;
				$dateD["BSMinute"]["Val"] = $bsvals[4];

				$VAR["Content"] .= "<tr>\n";
				$VAR["Content"] .= "<td>\n";
				$VAR["Content"] .= "Birthstamp:</td>\n";
				$VAR["Content"] .= "<td>\n";
				
				reset($dateD);
				while(list($bswhat,$dateA) = each($dateD)) {
					$VAR["Content"] .= "<select name\t= \"" . $bswhat . "\">\n";
					for($i=$dateA["Min"];$i<=$dateA["Max"];$i++) {
						if ($i == $dateA["Val"]) {
							$selected = "selected";
						} else {
							$selected = "";
						}
						$VAR["Content"] .= "<option value=\"";
						if (strlen($i)<2) {
							$i = "0" . $i;
						}
						$VAR["Content"] .= $i;
						$VAR["Content"] .= "\" $selected>$i</option>\n";
					}
					$VAR["Content"] .= "</select> ";
				}
				$VAR["Content"] .= "\n<br /><small>(A date in the future will cause the story to be invisible until then.)</small>";
				$VAR["Content"] .= "\n</td></tr>\n";
				
			}
			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Title:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"Heading\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A[Heading]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 96></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Topic:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<select\tname\t= \"Topic\">\n";
			$VAR["Content"] .= F_topicsel($A["Topic"]);
			$VAR["Content"] .= "</select>\n</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Summary:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<textarea\n";
			$VAR["Content"] .= "\tname\t= \"Summary\"\n";
			$VAR["Content"] .= "\twrap\t= \"virtual\"\n";
			$VAR["Content"] .= "\trows\t= 10\n";
			$VAR["Content"] .= "\tcols\t= 50>";
			$VAR["Content"] .= F_out($A["Summary"]);
			$VAR["Content"] .= "</textarea></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Content:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<textarea\n";
			$VAR["Content"] .= "\tname\t= \"Content\"\n";
			$VAR["Content"] .= "\twrap\t= \"virtual\"\n";
			$VAR["Content"] .= "\trows\t= 10\n";
			$VAR["Content"] .= "\tcols\t= 50>";
			$VAR["Content"] .= F_out($A["Content"]);
			$VAR["Content"] .= "</textarea></td>\n";
			$VAR["Content"] .= "</tr>\n";

			if ($CONF["EmailComments"]>0) {
				$VAR["Content"] .= "<tr>\n";
				$VAR["Content"] .= "<td>\n";
				$VAR["Content"] .= "&nbsp;</td>\n";
				$VAR["Content"] .= "<td>\n";
				$tmp	= $A["EmailComments"]==1 ? $tmp = "checked" : "";
				$VAR["Content"] .= "<input\ttype\t= checkbox\n";
				$VAR["Content"] .= "\tname\t= \"EmailComments\" " . $tmp . ">\n";
				$VAR["Content"] .= "Send any comments to the poster.\n";
				$VAR["Content"] .= "</td></tr>\n";
			}

			$VAR["Content"]	.= "<tr><td>" . _SAVEAS . "</td>\n";
			$VAR["Content"] .= "<td><select name=\"ParseType\">\n";
			$VAR["Content"] .= "<option value=\"auto\" " . F_select($A["ParseType"],"auto") . ">" . _AUTOMATIC . "</option>\n";
			$VAR["Content"] .= "<option value=\"html\" " . F_select($A["ParseType"],"html") . ">" . _HTML . "</option>\n";
			$VAR["Content"] .= "<option value=\"extrans\" " . F_select($A["ParseType"],"extrans") . ">" . _EXTRANS . "</option>\n";
			$VAR["Content"] .= "<option value=\"text\" " . F_select($A["ParseType"],"text") . ">" . _TEXT . "</option>\n";
			$VAR["Content"] .= "</select>\n</td></tr>";

			$VAR["Content"]	.= F_editIndexes2($A["Rid"]);

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td\tcolspan\t= 2\n";
			$VAR["Content"] .= "\talign\t= center>\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"confirm\"\n";
			$VAR["Content"] .= "\tvalue\t= \"yes\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"mode\"\n";
			$VAR["Content"] .= "\tvalue\t= \"edit\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"where\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . urlencode($where) . "\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"what\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$what\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"item\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[Rid]\">\n";
			$VAR["Content"] .= "<input\ttype\t= \"submit\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
			$VAR["Content"] .= "</tr></table></form>\n";
			F_drawMain($VAR);
			include("../include/footer.inc.php");
		break;
		case "T_Blocks":
			include("../include/header.inc.php");

			$sql	= "SELECT * FROM T_Blocks ";
			$sql	.= "WHERE Rid = '$item'";
			$result	= @mysql_query($sql,$db);
			if ($result<1) {
				F_error("Unable to select block.");
			}
			
			$A	= mysql_fetch_array($result);

			$sysblocks = "\t<option value=\"none\"> </option>\n";
			$d = dir("$G_PATH/backend/blocks");
			while($entry=$d->read()) {
				if (eregi("^.+\.inc\.php$",$entry)) {
					if ("$G_PATH/backend/blocks/$entry" == $A["URL"]) {
						$selected = "selected";
					} else {
						$selected = "";
					}
					$entry = eregi_replace("\.inc\.php$","",$entry);
					$dentry= "$G_PATH/backend/blocks/$entry";
					$entry = "System - " . $entry;
					$sysblocks .= "\t<option value=\"$dentry\" $selected>$entry</option>\n";
				}
			}
		
			foreach(F_getAddonBlocks("") as $B) {
				if ($B["URL"] . "/" . $B["Name"] == $A["URL"]) {
					$selected = "selected";
				} else {
					$selected = "";
				}
				$entry = str_replace(".inc.php","",$B["Name"]);
				$dentry= $B["URL"] ."/" . $entry;
				$entry = strtolower($B["Heading"]) . " - " . $entry;
				$sysblocks .= "\t<option value=\"$dentry\" $selected>$entry</option>\n";
			}

			$VAR["Heading"] = "Edit : Block : " . $A["Rid"];
			$VAR["Content"] = "<form\taction\t= \"$PHP_SELF\"\n";
			$VAR["Content"] .= "\tname\t= Blocks\n";
			$VAR["Content"] .= "\tonsubmit\t= \"return validateBlocks()\"\n";
			$VAR["Content"] .= "\tmethod\t= post>\n";
	
			$VAR["Content"] .= "<table\n";
			$VAR["Content"] .= "\tborder\t= \"0\"\n";
			$VAR["Content"] .= "\tcellspacing\t= \"1\"\n";
			$VAR["Content"] .= "\tcellpadding\t= \"2\"\n";
			$VAR["Content"] .= "\twidth\t= \"100%\">\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Display:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<select name\t= \"Display\">\n";
			$VAR["Content"] .= sprintf("<option value=\"0\" %s>Off</option>\n",($A["Display"]=="0" ? "selected" : ""));
			$VAR["Content"] .= sprintf("<option value=\"l\" %s>Left Block</option>\n",($A["Display"]=="l" ? "selected" : ""));
			$VAR["Content"] .= sprintf("<option value=\"r\" %s>Right Block</option>\n",($A["Display"]=="r" ? "selected" : ""));
			$VAR["Content"] .= "</select>\n";
			$VAR["Content"] .= "</td>\n";
			$VAR["Content"] .= "</tr>\n";


			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Sort Order:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"OrderID\"\n";
			$VAR["Content"] .= "\tsize\t= 3\n";
			$VAR["Content"] .= "\tmaxlength\t= 3\n";
			$VAR["Content"] .= "\tvalue\t= \"" . $A["OrderID"] . "\">\n";
			$VAR["Content"] .= "<input\ttype\t= checkbox\n";
			$VAR["Content"] .= "\tname\t= \"ShowMain\"";
			if ($A["ShowMain"]=="1") {
				$VAR["Content"]	.= "checked";
			}
			$VAR["Content"] .= "> Display block on main page only";
			$VAR["Content"] .= "</td></tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Heading:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"Heading\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A["Heading"]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 48></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td	colspan	= 2><hr size=1 noshade>\n";
			$VAR["Content"] .= "<input\ttype\t= radio\n";
			$VAR["Content"] .= "\tname\t= Type\n";
			$VAR["Content"] .= sprintf("\tvalue\t= \"0\" %s> HTML Block\n",($A["Type"]==0?"checked":""));
			$VAR["Content"] .= "</td>\n";
			$VAR["Content"] .= "</tr><tr>\n";
			$VAR["Content"] .= "<td	colspan	= 2>\n";
			$VAR["Content"] .= "<textarea\n";
			$VAR["Content"] .= "\tname\t= \"Content\"\n";
			$VAR["Content"] .= "\twrap\t= \"virtual\"\n";
			$VAR["Content"] .= "\trows\t= 10\n";
			$VAR["Content"] .= "\tcols\t= 50>";
			if ($A["Type"]==0) {
				$VAR["Content"] .= F_out($A["Content"]);
			}
			$VAR["Content"] .= "</textarea></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr><td	colspan = 2>\n";
			$VAR["Content"] .= "<input\ttype\t= radio\n";
			$VAR["Content"] .= "\tname\t= Type\n";
			$VAR["Content"] .= sprintf("\tvalue\t= \"3\" %s> System Block ",($A["Type"]==3?"checked":""));
 			$VAR["Content"] .= "<select\tname\t= SysBlock ";
			#$VAR["Content"] .= "onChange=\"document.Blocks.Heading.value = document.Blocks.SysBlock.options[document.Blocks.SysBlock.selectedIndex].value;document.Blocks.Type[1].checked = true;\">\n";
			$VAR["Content"] .= "onChange=\"document.Blocks.URL.value = document.Blocks.SysBlock.options[document.Blocks.SysBlock.selectedIndex].value+'.inc.php';var var1=document.Blocks.SysBlock.options[document.Blocks.SysBlock.selectedIndex].value;document.Blocks.Heading.value = var1.substring(var1.lastIndexOf('/',var1.length-1)+1,(var1.length));document.Blocks.Type[1].checked = true;\">\n";

			$VAR["Content"] .= $sysblocks;
			$VAR["Content"] .= "</select>\n";
			$VAR["Content"] .= "</td></tr>\n";


			$VAR["Content"] .= "<tr><td	colspan = 2>\n";
			$VAR["Content"] .= "<input\ttype\t= radio\n";
			$VAR["Content"] .= "\tname\t= Type\n";
			$VAR["Content"] .= sprintf("\tvalue\t= \"1\" %s> HEADLINE <small>(Only supports RSS/RDF format)</small>\n",($A["Type"]==1?"checked":""));
			$VAR["Content"] .= "</td></tr>\n";

			$VAR["Content"] .= "<tr><td	colspan = 2>\n";
			$VAR["Content"] .= "<input\ttype\t= radio\n";
			$VAR["Content"] .= "\tname\t= Type\n";
			$VAR["Content"] .= sprintf("\tvalue\t= \"2\" %s> INCLUDE <small>(full URL or PATH only)</small>\n",($A["Type"]==2?"checked":""));
			$VAR["Content"] .= "</td></tr>\n";

			$VAR["Content"]	.= "<tr>\n";
			$VAR["Content"] .= "<td>URL:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"]	.= "\tname\t= URL\n";
			$VAR["Content"]	.= "\tsize\t= 40\n";
			$VAR["Content"]	.= "\tvalue\t= \"" . $A["URL"] . "\">\n";
			$VAR["Content"] .= "</td>\n";
			$VAR["Content"] .= "</tr>\n";
			

			$VAR["Content"]	.= "<tr>\n";
			$VAR["Content"] .= "<td>Cache Time:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"]	.= "\tname\t= Cache\n";
			$VAR["Content"]	.= "\tsize\t= 4\n";
			$VAR["Content"]	.= "\tvalue\t= \"" . $A["Cache"] . "\">\n";
			$VAR["Content"] .= "(minutes / 0=no cache) \n";
			$VAR["Content"]	.= "<input\ttype\t= checkbox\n";
			$VAR["Content"]	.= "\tname\t= \"nocache\" checked> Update cache";
			$VAR["Content"]	.= "</td></tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td\tcolspan\t= 2>\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"confirm\"\n";
			$VAR["Content"] .= "\tvalue\t= \"yes\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"mode\"\n";
			$VAR["Content"] .= "\tvalue\t= \"edit\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"where\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . $where . "\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"what\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$what\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"item\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[Rid]\">\n";
			$VAR["Content"] .= "<input\ttype\t= \"submit\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
			$VAR["Content"] .= "</tr></table></form>\n";
			F_drawMain($VAR);
			include("../include/footer.inc.php");
		break;
		case "T_Pages":
			include("../include/header.inc.php");

			$sql	= "SELECT * FROM T_Pages ";
			$sql	.= "WHERE Rid = '$item'";
			$result	= @mysql_query($sql,$db);
			if ($result<1) {
				F_error("Unable to select page.");
			}
			
			$A	= mysql_fetch_array($result);

			$path		= "$G_PATH/backend/addons";
			$addons = "\t<option value=\"\"> </option>\n";
			$d = dir($path);
			while($entry=$d->read()) {
				if (is_dir($path ."/" . $entry) && $entry!="." && $entry!="..") {
					$addons .= "\t<option value=\"$entry\">$entry</option>\n";
				}
			}

			$VAR["Heading"] = "Edit : Page Node : " . $A["Rid"];
			$VAR["Content"] = "<form\taction\t= \"$PHP_SELF\"\n";
			$VAR["Content"] .= "\tname\t= Pages\n";
			$VAR["Content"] .= "\tonsubmit\t= \"return validatePages()\"\n";
			$VAR["Content"] .= "\tmethod\t= post>\n";
	
			$VAR["Content"] .= "<table\n";
			$VAR["Content"] .= "\tborder\t= \"0\"\n";
			$VAR["Content"] .= "\tcellspacing\t= \"1\"\n";
			$VAR["Content"] .= "\tcellpadding\t= \"2\"\n";
			$VAR["Content"] .= "\twidth\t= \"100%\">\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Display:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<select name\t= \"Display\">\n";
			$VAR["Content"] .= sprintf("<option value=\"0\" %s>Off</option>\n",($A["Display"]=="0" ? "selected" : ""));
			$VAR["Content"] .= sprintf("<option value=\"p\" %s>Page</option>\n",($A["Display"]=="p" ? "selected" : ""));
			$VAR["Content"] .= sprintf("<option value=\"f\" %s>Feature</option>\n",($A["Display"]=="f" ? "selected" : ""));
			$VAR["Content"] .= "</select>\n";
			$VAR["Content"] .= "</td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Options:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= checkbox\n";
			$VAR["Content"] .= "\tname\t= \"PageComments\"";
			if ($A["PageComments"]=="1") {
				$VAR["Content"]	.= "checked";
			}
			$VAR["Content"] .= "> Allow user comments";
			$VAR["Content"] .= "</td></tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Title:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"Title\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A["Title"]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 48></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Heading:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"Heading\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A["Heading"]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 48></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td	colspan	= 2><hr size=1 noshade>\n";
			$VAR["Content"] .= "<input\ttype\t= radio\n";
			$VAR["Content"] .= "\tname\t= Type\n";
			$VAR["Content"] .= sprintf("\tvalue\t= \"0\" %s> HTML",($A["Type"]==0?"checked":""));
			$VAR["Content"] .= "</td>\n";
			$VAR["Content"] .= "</tr><tr>\n";
			$VAR["Content"] .= "<td	colspan	= 2>\n";
			$VAR["Content"] .= "<textarea\n";
			$VAR["Content"] .= "\tname\t= \"Content\"\n";
			$VAR["Content"] .= "\twrap\t= \"virtual\"\n";
			$VAR["Content"] .= "\trows\t= 10\n";
			$VAR["Content"] .= "\tcols\t= 50>";
			if ($A["Type"]==0) {
				$VAR["Content"] .= F_out($A["Content"]);
			}
			$VAR["Content"] .= "</textarea></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr><td>\n";
			$VAR["Content"] .= "<input\ttype\t= radio\n";
			$VAR["Content"] .= "\tname\t= Type\n";
			$VAR["Content"] .= sprintf("\tvalue\t= \"1\" %s> ADDON</td><td>\n",($A["Type"]==1?"checked":""));
			$VAR["Content"] .= "\n<select\tname\t=\"Addon\" ";
			$VAR["Content"] .= "onChange=\"document.Pages.URL.value = '$G_PATH/backend/addons/'+document.Pages.Addon.options[document.Pages.Addon.selectedIndex].value+'/';document.Pages.Type[1].checked = true;\">\n";
			$VAR["Content"] .= $addons;
			$VAR["Content"] .= "</select>\n";
			$VAR["Content"] .= "</td></tr>\n";

			$VAR["Content"] .= "<tr><td>\n";
			$VAR["Content"] .= "<input\ttype\t= radio\n";
			$VAR["Content"] .= "\tname\t= Type\n";
			$VAR["Content"] .= sprintf("\tvalue\t= \"2\" %s> INCLUDE</td><td><small>(full URL or PATH only)</small>\n",($A["Type"]==2?"checked":""));
			$VAR["Content"] .= "</td></tr>\n";

			$VAR["Content"]	.= "<tr>\n";
			$VAR["Content"] .= "<td>URI:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"]	.= "\tname\t= URL\n";
			$VAR["Content"]	.= "\tsize\t= 40\n";
			$VAR["Content"]	.= "\tvalue\t= \"" . $A["URL"] . "\">\n";
			$VAR["Content"] .= "</td>\n";
			$VAR["Content"] .= "</tr>\n";
			$VAR["Content"] .= "<tr><td	colspan = 2>\n";
			
			$VAR["Content"]	.= "<tr>\n";
			$VAR["Content"] .= "<td>Hits:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"]	.= "\tname\t= Hits\n";
			$VAR["Content"]	.= "\tsize\t= 4\n";
			$VAR["Content"]	.= "\tvalue\t= \"" . $A["Hits"] . "\"></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td\tcolspan\t= 2\n";
			$VAR["Content"] .= "\talign\t= center>\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"confirm\"\n";
			$VAR["Content"] .= "\tvalue\t= \"yes\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"mode\"\n";
			$VAR["Content"] .= "\tvalue\t= \"edit\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"where\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . $where . "\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"what\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$what\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"item\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[Rid]\">\n";
			$VAR["Content"] .= "<input\ttype\t= \"submit\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
			$VAR["Content"] .= "</tr></table></form>\n";
			F_drawMain($VAR);
			include("../include/footer.inc.php");
		break;
		case "T_Topics":
			include("../include/header.inc.php");

			$sql	= "SELECT * FROM T_Topics ";
			$sql	.= "WHERE Rid = '$item'";
			$result	= @mysql_query($sql,$db);
			if ($result<1) {
				F_error("Unable to select topic.");
			}
			$A	= mysql_fetch_array($result);

			$VAR["Heading"] = "Edit : Topic : " . $A["Rid"];
			$VAR["Content"] = "<form\taction\t= \"$PHP_SELF\"\n";
			$VAR["Content"] .= "\tmethod\t= post>\n";

			$VAR["Content"] .= "<table\n";
			$VAR["Content"] .= "\tborder\t= \"0\"\n";
			$VAR["Content"] .= "\tcellspacing\t= \"1\"\n";
			$VAR["Content"] .= "\tcellpadding\t= \"2\"\n";
			$VAR["Content"] .= "\twidth\t= \"100%\">\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Topic:</td>\n";
			$VAR["Content"] .= "<td colspan=2>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"Topic\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[Topic]\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 48></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Image URL:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"ImgURL\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[ImgURL]\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 96></td>\n";
			if (!empty($A["ImgURL"])) {
				$tmp	= sprintf("<img src=\"%s\">\n",$A["ImgURL"]);
			} else {
				$tmp	= "&nbsp;";
			}
			$VAR["Content"] .= "<td>$tmp</td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Alt Tag:</td>\n";
			$VAR["Content"] .= "<td colspan=2>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"AltTag\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[AltTag]\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 64></td>\n";
			$VAR["Content"] .= "</tr>\n";
			$VAR["Content"]	.= "<tr>\n<td>";

			if ($CONF["AllowContrib"]>0) {
				$VAR["Content"]	.= "Posting:</td>\n";
				$VAR["Content"]	.= "<td colspan=2>\n";
				$VAR["Content"] .= "<input type=radio name=NoPosting value=\"0\" ";
				$VAR["Content"] .= ( $A["NoPosting"]==0 ? "checked" : "" ) . "> On \n";
				$VAR["Content"] .= "<input type=radio name=NoPosting value=\"1\" ";
				$VAR["Content"] .= ( $A["NoPosting"]==1 ? "checked" : "" ) . "> Off <br />\n";
			} else {
				$VAR["Content"] .= "<input type=hidden name=NoPosting value=\"" . $A["NoPosting"] . "\">";
			}
			$VAR["Content"]	.= "</td>\n";
			$VAR["Content"]	.= "</tr>\n";
			$VAR["Content"]	.= "<tr>\n<td>";
			if ($CONF["Comments"]>0) {
				$VAR["Content"]	.= "Comments:</td>\n";
				$VAR["Content"]	.= "<td colspan=2>\n";
				$VAR["Content"] .= "<input type=radio name=NoComments value=\"0\" ";
				$VAR["Content"] .= ( $A["NoComments"]==0 ? "checked" : "" ) . "> On \n";
				$VAR["Content"] .= "<input type=radio name=NoComments value=\"1\" ";
				$VAR["Content"] .= ( $A["NoComments"]==1 ? "checked" : "" ) . "> Off \n";
				$VAR["Content"] .= "<input type=radio name=NoComments value=\"2\" ";
				$VAR["Content"] .= ( $A["NoComments"]==2 ? "checked" : "" ) . "> Display Only\n";
			} else {
				$VAR["Content"] .= "<input type=hidden name=NoComments value=\"" . $A["NoComments"] . "\">";
			}
			$VAR["Content"]	.= "</td>\n</tr>\n";
			$VAR["Content"]	.= "<tr>\n<td>\n";
			if ($CONF["LimitIndexed"]>0) {
				$VAR["Content"]	.= "Index Default:</td>\n";
				$VAR["Content"]	.= "<td colspan=2>\n";
				$VAR["Content"] .= "<input type=radio name=IndexDefault value=\"Y\" ";
				$VAR["Content"] .= ( $A["IndexDefault"]=="Y" ? "checked" : "" ) . "> Include \n";
				$VAR["Content"] .= "<input type=radio name=IndexDefault value=\"N\" ";
				$VAR["Content"] .= ( $A["IndexDefault"]=="N" ? "checked" : "" ) . "> Don't Include <br />\n";
			} else {
				$VAR["Content"] .= "<input type=hidden name=IndexDefault value=\"" . $A["IndexDefault"] . "\">";
			}

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td\tcolspan\t= 3\n";
			$VAR["Content"] .= "\talign\t= center>\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"confirm\"\n";
			$VAR["Content"] .= "\tvalue\t= \"yes\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"mode\"\n";
			$VAR["Content"] .= "\tvalue\t= \"edit\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"what\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$what\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"item\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[Rid]\">\n";
			$VAR["Content"] .= "<input\ttype\t= \"submit\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
			$VAR["Content"] .= "</tr></table></form>\n";
			F_drawMain($VAR);
			include("../include/footer.inc.php");
		break;
		case "T_Users":
			include("../include/header.inc.php");

			$sql	= "SELECT * FROM T_Users ";
			$sql	.= "WHERE Username = '$item'";
			$result	= @mysql_query($sql,$db);
			if ($result<1) {
				F_error("Unable to select user $item.");
			}
			$A	= mysql_fetch_array($result);

			$VAR["Heading"] = "Edit : User : " . $A["Username"];
			$VAR["Content"] = "<form\taction\t= \"$PHP_SELF\"\n";
			$VAR["Content"] .= "\tmethod\t= post>\n";

			$VAR["Content"] .= "<table\n";
			$VAR["Content"] .= "\tborder\t= \"0\"\n";
			$VAR["Content"] .= "\tcellspacing\t= \"1\"\n";
			$VAR["Content"] .= "\tcellpadding\t= \"2\"\n";
			$VAR["Content"] .= "\twidth\t= \"100%\">\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Verified:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<select\tname\t=\"Verified\">\n";
			$VAR["Content"]	.= "<option value=\"Y\" " . ($A["Verified"]=="Y" ? "selected" : "") . ">Yes</option>\n";
			$VAR["Content"]	.= "<option value=\"N\" " . ($A["Verified"]=="N" ? "selected" : "") . ">No</option>\n";
			$VAR["Content"] .= "</select>\n</td></tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Username:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"hidden\"\n";
			$VAR["Content"] .= "\tname\t= \"Username\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[Username]\">\n";
			$VAR["Content"] .= $A["Username"] . "</td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Password:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"Password\"\n";
			$VAR["Content"] .= "\tvalue\t= \"\"\n";
			$VAR["Content"] .= "\tsize\t= 16\n";
			$VAR["Content"] .= "\tmaxlength\t= 16></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Real Name:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"RealName\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[RealName]\"\n";
			$VAR["Content"] .= "\tsize\t= 24\n";
			$VAR["Content"] .= "\tmaxlength\t= 24></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Email:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"EmailAddress\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[EmailAddress]\"\n";
			$VAR["Content"] .= "\tsize\t= 24\n";
			$VAR["Content"] .= "\tmaxlength\t= 128></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "URL:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"URL\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[URL]\"\n";
			$VAR["Content"] .= "\tsize\t= 24\n";
			$VAR["Content"] .= "\tmaxlength\t= 128></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Access Level:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<select name=\"Level\">\n";
			for ($i=1;$i<sizeof($LEVELS);$i++) {
				$VAR["Content"] .= "<option value=\"$i\" ". F_select($i,$A["Level"]) .">" . $LEVELS[$i] . "</option>\n";
			}
			$VAR["Content"] .= "</select></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Comment:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<textarea name=\"Comment\" rows=5 cols=45 wrap=virtual>";
			$VAR["Content"] .= F_out($A["Comment"]) . "</textarea></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td\tcolspan\t= 3\n";
			$VAR["Content"] .= "\talign\t= center>\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"confirm\"\n";
			$VAR["Content"] .= "\tvalue\t= \"yes\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"mode\"\n";
			$VAR["Content"] .= "\tvalue\t= \"edit\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"what\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$what\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"item\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[Username]\">\n";
			$VAR["Content"] .= "<input\ttype\t= \"submit\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
			$VAR["Content"] .= "</tr></table></form>\n";
			F_drawMain($VAR);
			include("../include/footer.inc.php");
		break;
		case "T_Comments":
			include("../include/header.inc.php");

			$sql	= "SELECT * FROM T_Comments ";
			$sql	.= "WHERE Rid = '$item'";
			$result	= @mysql_query($sql,$db);
			if ($result<1) {
				F_error("Unable to select comment.");
			}
			$A	= mysql_fetch_array($result);

			$VAR["Heading"] = "Edit : Comment : " . $A["Rid"];
			$VAR["Content"] = "<form\taction\t= \"$PHP_SELF\"\n";
			$VAR["Content"] .= "\tmethod\t= post>\n";

			$VAR["Content"] .= "<table\n";
			$VAR["Content"] .= "\tborder\t= \"0\"\n";
			$VAR["Content"] .= "\tcellspacing\t= \"1\"\n";
			$VAR["Content"] .= "\tcellpadding\t= \"2\"\n";
			$VAR["Content"] .= "\twidth\t= \"100%\">\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Name:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"Author\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A[Author]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 32></td></tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Email:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"AuthorEmail\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A[AuthorEmail]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 96></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "URL:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<input\ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname\t= \"AuthorURL\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($A[AuthorURL]) . "\"\n";
			$VAR["Content"] .= "\tsize\t= 40\n";
			$VAR["Content"] .= "\tmaxlength\t= 96></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "Comment:</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<textarea\n";
			$VAR["Content"] .= "\tname\t= \"Content\"\n";
			$VAR["Content"] .= "\twrap\t= \"virtual\"\n";
			$VAR["Content"] .= "\trows\t= 10\n";
			$VAR["Content"] .= "\tcols\t= 50>";
			$VAR["Content"] .= F_out($A["Content"]);
			$VAR["Content"] .= "</textarea></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"]	.= "<tr><td>" . _SAVEAS . "</td>\n";
			$VAR["Content"] .= "<td><select name=\"ParseType\">\n";
			$VAR["Content"] .= "<option value=\"auto\" " . F_select($A["ParseType"],"auto") . ">" . _AUTOMATIC . "</option>\n";
			$VAR["Content"] .= "<option value=\"html\" " . F_select($A["ParseType"],"html") . ">" . _HTML . "</option>\n";
			$VAR["Content"] .= "<option value=\"extrans\" " . F_select($A["ParseType"],"extrans") . ">" . _EXTRANS . "</option>\n";
			$VAR["Content"] .= "<option value=\"text\" " . F_select($A["ParseType"],"text") . ">" . _TEXT . "</option>\n";
			$VAR["Content"] .= "</select>\n</td></tr>";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td\tcolspan\t= 2\n";
			$VAR["Content"] .= "\talign\t= center>\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"confirm\"\n";
			$VAR["Content"] .= "\tvalue\t= \"yes\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"mode\"\n";
			$VAR["Content"] .= "\tvalue\t= \"edit\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"where\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . urlencode($where) . "\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"what\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$what\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"item\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[Rid]\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"ParentRid\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$A[ParentRid]\">\n";
			$VAR["Content"] .= "<input\ttype\t= \"submit\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
			$VAR["Content"] .= "</tr></table></form>\n";
			F_drawMain($VAR);
			include("../include/footer.inc.php");
		break;
	}
}

?>
