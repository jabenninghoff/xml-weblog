<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=3;
include("./auth.inc.php");

include("../include/header.inc.php");

$dir	= $G_PATH . "/backend/template/";
$ldir	= $G_PATH . "/backend/layouts/";

function F_getTmpl($what,$value) {
	global	$dir,$LAYOUT,$G_URL;
	$handle=opendir($dir);
	$s		= "";
	while ($file = readdir($handle)) {
		$tmpl	= $dir . $file . "/" . $what . ".tmpl";
		if ($file != "." && $file != ".." && file_exists($tmpl)) {
			$foo	= $LAYOUT[$value]==$file ? "selected" : "";
			$s .= sprintf("<option value=\"%s\" %s>%s</option>\n",$file,$foo,$file);
		}
	}
	closedir($handle);
	return	$s;
}


	$VAR["Heading"] = "Page Layout: Viewing layout \"$THEME\"";

	$VAR["Content"] = "
<table
	cellpadding	= 2
	cellspacing	= 1
	border	= 0
	width	= 100%>

<tr>
<td	colspan	= 4
	align	= center>
<form	action	= \"$G_URL/admin/submit.php\"
	method	= POST
	name	= \"Layout\">
Layout Name:
<select	name	= name
	onchange= \"JS_swapLayout(document.Layout);\">";

	$handle=opendir($G_PATH . "/backend/layouts");
	while ($file = readdir($handle)) {
		$tmp    = substr($file,-5,5);
		$name   = eregi_replace(".xlay", "", $file);
		$crap	= !empty($preview_layout) ? $preview_layout : $CONF["Layout"];
		if ($file != "." && $file != ".." && strtolower($tmp) == ".xlay") {
			$foo    = ($name==$crap) ? "selected" : "";
			$VAR["Content"] .= sprintf("<option value=\"%s\" %s>%s</option>\n",$name,$foo,$name);
		}
	}
	closedir($handle);

$VAR["Content"] .= "
</select>
<input	type	= text
	name	= Layout
	value	= \"$THEME\"
	size	= 12
	maxlength=12>
<input	type	= hidden
	name	= \"what\"
	value	= \"layout\">
<input	type	= submit
	name	= \"layout_mode\"
	value	= \"View/Load\">
&nbsp;&nbsp;&nbsp;
<input	type	= submit
	onclick	= \"return getconfirm();\"
	name	= \"layout_mode\"
	value	= \"Kill\">
<input	type	= submit
	name	= \"layout_mode\"
	value	= \"Add/Update\">
</td>
</tr>

<tr>
<td colspan=4><hr size=1 noshade><b>Layout Configurator (XLAY)</b>
<small>(found in $ldir)</small></td>
</tr>

<tr>
<td>Author Name</td>
<td 	colspan = 3><input type=text name=Author maxlength=24 value=\"" . $LAYOUT["Author"] . "\"></td>
</tr>

<tr>
<td>Layout Description</td>
<td 	colspan = 3><input type=text name=Description maxlength=96 value=\"" . $LAYOUT["Description"] . "\"></td>
</tr>

<tr>
<td>BG Image (URL)</td>
<td 	colspan = 3><input type=text name=XLAY_BgURL size=35 maxlength=96 value=\"" . $LAYOUT["BgURL"] . "\"></td>
</tr>

<tr>
<td>Logo (URL)</td>
<td	colspan=3><input type=text name=XLAY_LogoURL size=35 maxlength=96 value=\"" . $LAYOUT["LogoURL"] . "\"></td>
</tr>

<tr>
<td>Page Width (pixel / %)</td>
<td><input 	type=text  name=XLAY_PageWidth size=7 maxlength=10 value=\"" . $LAYOUT["PageWidth"] . "\"></td>
<td>Area Padding</td>
<td><input 	type=text  name=XLAY_AreaPadding size=7 maxlength=10 value=\"" . $LAYOUT["AreaPadding"] . "\"></td>
</tr>

<tr>
<td>Background Color</td>
<td><input 	type=text  name=XLAY_BgColor size=7 maxlength=10 value=\"" . $LAYOUT["BgColor"] . "\"></td>
<td>Hover Color</td>
<td><input 	type=text  name=XLAY_HoverColor size=7 maxlength=10 value=\"" . $LAYOUT["HoverColor"] . "\"></td>
</tr>


<tr>
<td>Blocks Width (Left)</td>
<td><input 	type=text  name=XLAY_LeftBlocksWidth size=7 maxlength=10 value=\"" . $LAYOUT["LeftBlocksWidth"] . "\"></td>
<td>Blocks Width (right)</td>
<td><input 	type=text  name=XLAY_RightBlocksWidth size=7 maxlength=10 value=\"" . $LAYOUT["RightBlocksWidth"] . "\"></td>
</tr>


<tr>
<td colspan=4><hr size=1 noshade><b>Stylesheet Configuration</b>
<small>(Must be valid CSS)</small></td>
</tr>

<tr>
<td>Global Style</td>
<td 	colspan=3><input type=text name=XLAY_GlobalStyle size=35 maxlength=96 value=\"" . $LAYOUT["GlobalStyle"] . "\"></td>
</tr>

<tr>
<td>Text Style</td>
<td 	colspan=3><input type=text name=XLAY_TextStyle size=35 maxlength=96 value=\"" . $LAYOUT["TextStyle"] . "\"></td>
</tr>

<tr>
<td>Link Style</td>
<td colspan=3><input 	type=text name=XLAY_LinkStyle size=35 maxlength=96 value=\"" . $LAYOUT["LinkStyle"] . "\"></td>
</tr>

<tr>
<td>Heading Style</td>
<td 	colspan=3><input type=text name=XLAY_HeadStyle size=35 maxlength=96 value=\"" . $LAYOUT["HeadStyle"] . "\"></td>
</tr>

<tr>
<td>Block Style</td>
<td 	colspan=3><input type=text name=XLAY_BlockStyle size=35 maxlength=96 value=\"" . $LAYOUT["BlockStyle"] . "\"></td>
</tr>

<tr>
<td>Block Heading Style</td>
<td 	colspan=3><input type=text name=XLAY_BlockHeadStyle size=35 maxlength=96 value=\"" . $LAYOUT["BlockHeadStyle"] . "\"></td>
</tr>

<tr>
<td>Navigation Style</td>
<td colspan=3><input 	type=text name=XLAY_NavStyle size=35 maxlength=96 value=\"" . $LAYOUT["NavStyle"] . "\"></td>
</tr>

<tr>
<td>Story Title Style</td>
<td colspan=3><input 	type=text  name=XLAY_TitleStyle size=35 maxlength=96 value=\"" . $LAYOUT["TitleStyle"] . "\"></td>
</tr>

<tr>
<td colspan=4><hr size=1 noshade><b>Themes / Templates</b>
<small>(found in $dir)</small></td>
</tr>

<tr>
<td>Header</td>
<td>
<select	name	= XLAY_TMPL_Header>";
	$VAR["Content"] .= F_getTmpl("header","TMPL_Header");

$VAR["Content"] .= "
</select>
</td>
<td>Footer</td>
<td>
<select	name	= XLAY_TMPL_Footer>";
	$VAR["Content"] .= F_getTmpl("footer","TMPL_Footer");

$VAR["Content"] .= "
</select>
</td>
</tr>

<tr>
<td>Left Block</td>
<td>
<select	name	= XLAY_TMPL_LeftBlock>";
	$VAR["Content"] .= F_getTmpl("block","TMPL_LeftBlock");

$VAR["Content"] .= "
</select>
</td>
<td>Right Block</td>
<td>
<select	name	= XLAY_TMPL_RightBlock>";
	$VAR["Content"] .= F_getTmpl("block","TMPL_RightBlock");

$VAR["Content"] .= "
</select>
</td>
</tr>


<tr>
<td>Summary</td>
<td>
<select	name	= XLAY_TMPL_Summary>";
	$VAR["Content"] .= F_getTmpl("summary","TMPL_Summary");

$VAR["Content"] .= "
</select>
</td>
<td>Story</td>
<td>
<select	name	= XLAY_TMPL_Story>";
	$VAR["Content"] .= F_getTmpl("story","TMPL_Story");

$VAR["Content"] .= "
</select>
</td>
</tr>


<tr>
<td>Comment</td>
<td>
<select	name	= XLAY_TMPL_Comment>";
	$VAR["Content"] .= F_getTmpl("comment","TMPL_Comment");

$VAR["Content"] .= "
</select>
</td>
<td>Main</td>
<td>
<select	name	= XLAY_TMPL_Main>";
	$VAR["Content"] .= F_getTmpl("main","TMPL_Main");

$VAR["Content"] .= "
</select>
</td>
</tr>

</table>
</form>";

F_drawMain($VAR);
include("../include/footer.inc.php");



?>
