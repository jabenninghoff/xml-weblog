<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=3;
include("./auth.inc.php");

include("../include/header.inc.php");

$VAR["Heading"] = "Site Configuration";

$VAR["Content"] = "
<form	action	= \"$G_URL/admin/submit.php\"
	name	= \"config\"
	method	= \"POST\">
<table
	cellpadding	= 0
	cellspacing	= 3
	width	= 100%
	border	= 0>

<tr>
<td>Site Name</td>
<td><input 	type=text  name=\"site[SiteName]\"  size=40  maxlength=64 value=\"" . F_out($CONF["SiteName"]) . "\"></td>
</tr>

<tr>
<td>Site Slogan</td>
<td><input 	type=text  name=\"site[SiteSlogan]\"  size=40  maxlength=64 value=\"" . F_out($CONF["SiteSlogan"]) . "\"></td>
</tr>

<tr>
<td>Site Owner</td>
<td><input 	type=text  name=\"site[SiteOwner]\"  size=24  maxlength=24 value=\"" . F_out($CONF["SiteOwner"]) . "\"></td>
</tr>

<tr>
<td>Site Email</td>
<td><input 	type=text  name=\"site[EmailAddress]\"  size=24  maxlength=96 value=\"" . $CONF["EmailAddress"] . "\"></td>
</tr>

<tr>
<td>Unique Key</td>
<td><input 	type=text  name=\"site[SiteKey]\"  size=10  maxlength=10 value=\"" . $CONF["SiteKey"] . "\">
<small>(Used for cookie values)</small></td>
</tr>

<tr>
<td>Site Layout</td>
<td>
<select	name	= \"site[Layout]\">";

	$handle=opendir($G_PATH . "/backend/layouts");
	while ($file = readdir($handle)) {
		$tmp	= substr($file,-5,5);
		$name	= eregi_replace(".xlay", "", $file);
		if ($file != "." && $file != ".." && strtolower($tmp) == ".xlay") {
			$foo	= strtolower($CONF["Layout"])==strtolower($name) ? "selected" : "";
			$VAR["Content"] .= sprintf("<option value=\"%s\" %s>%s</option>\n",$name,$foo,$name);
		}
	}
	closedir($handle);

$VAR["Content"] .= "
</select>
<small>(Found in $G_PATH/backend/layouts/)</small></td>
</tr>

<tr>
<td>Site Language</td>
<td>
<select	name	= \"site[Language]\">";

	$handle=opendir($G_PATH . "/backend/language");
	while ($file = readdir($handle)) {
		$tmp	= substr($file,-4,4);
		$name	= eregi_replace(".lng", "", $file);
		if ($file != "." && $file != ".." && strtolower($tmp) == ".lng") {
			$foo	= strtolower($CONF["Language"])==strtolower($name) ? "selected" : "";
			$VAR["Content"] .= sprintf("<option value=\"%s\" %s>%s</option>\n",$name,$foo,$name);
		}
	}
	closedir($handle);

$VAR["Content"] .= "
</select>
<small>(Found in $G_PATH/backend/language/)</small></td>
</tr>

<tr>
<td 	colspan	= 4>
<input	type	= hidden
	name	= what
	value	= site>
<input	type	= submit
	value	= \"Save Changes\">
</td>
</tr>

</table>
</form>
";


	F_drawMain($VAR);
	include("../include/footer.inc.php");
?>
