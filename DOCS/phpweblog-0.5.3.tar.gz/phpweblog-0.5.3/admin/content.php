<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=3;
include("./auth.inc.php");

include("../include/header.inc.php");

$VAR["Heading"] = "Content Manager";

$content_array = array("Welcome","Footer","Contrib","Submitted","Contact","Friend");

$VAR["Content"] = "<table cellspacing=3 cellpadding=0 width=\"100%\">\n";
$VAR["Content"] .= "<form action=\"$G_URL/admin/submit.php\" method=POST>\n";
foreach ($content_array as $C) {
	$VAR["Content"] .= "
		<tr>
			<td>" . $C . "<br />
			<textarea name=\"content[$C]\" cols=50 rows=5 wrap=virtual>" . 
				F_out(htmlentities($CONTENT["$C"])) . "</textarea>
			</td>
		</tr>";
}
$VAR["Content"] .= "<input type=hidden name=what value=content>\n";
$VAR["Content"] .= "<tr><td><input type=submit value=\"Save\"></td></tr>\n";
$VAR["Content"] .= "</table>\n";
$VAR["Content"] .= "</form>\n";
F_drawMain($VAR);

include("../include/footer.inc.php");
?>