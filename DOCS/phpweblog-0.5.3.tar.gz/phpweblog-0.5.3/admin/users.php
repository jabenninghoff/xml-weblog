<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("../include/common.inc.php");
$auth_level=3;
include("./auth.inc.php");

include("../include/header.inc.php");

$VAR["Heading"] = "User Manager";
$VAR["Content"] = "
<table	border	= 0
	cellspacing=1
	cellpadding=2
	width	= 100%>
	";

	$sql	= "SELECT * FROM T_Users ORDER BY Username";
	$result	= mysql_query($sql,$db);
	$nrows	= mysql_num_rows($result);
	$VAR["Content"] .= "<tr><th>Username</th><th>Real Name</th>";
	$VAR["Content"] .= "<th>Level</th><th>Last On</th><th>Active</th>";
	$VAR["Content"] .= "<th>&nbsp;</th></tr>";
	for ($i=0;$i<$nrows;$i++) {
		$A	= mysql_fetch_array($result);
		$VAR["Content"] .= "<tr>\n";
		$foo	= "";
		$VAR["Content"] .= sprintf("<td>%s</td>\n",$A["Username"]);
		$VAR["Content"] .= sprintf("<td>%s</td>\n",$A["RealName"]);
		$VAR["Content"] .= sprintf("<td>%s</td>\n",$LEVELS[$A["Level"]]);
		$VAR["Content"] .= sprintf("<td>%s</td>\n",empty($A["LastLogin"])?"never":F_dateFormat($A["LastLogin"]));
		$VAR["Content"] .= sprintf("<td>%s</td>\n",$A["Verified"]=="Y"?"Yes":"No");
		$VAR["Content"] .= "<td align=center>";
		$VAR["Content"] .= F_admin("T_Users",$A["Username"],"admin/users.php");
		$VAR["Content"] .= "</td></tr>\n";
	}
$VAR["Content"] .= "</table>\n";
F_drawMain($VAR);

print "<p>\n";

$VAR["Heading"] = "Add New User";
$VAR["Content"] = "
<form	action	= \"$G_URL/admin/submit.php\"
	name	= User
	onsubmit = \"return validateUser()\"
	method	= post>
<table
	border	= 0
	cellspacing	= 1
	cellpadding	= 2
	width	= \"100%\">

<tr><td>Username</td><td><input type=text name=Username size=16 maxlength=16></td></tr>
<tr><td>Password</td><td><input type=password name=Password size=16 maxlength=16> Verify <input type=password name=Password2 size=16 maxlength=16></td></tr>
<tr><td>Real Name</td><td><input type=text name=RealName size=24 maxlength=24></td></tr>
<tr><td>Email</td><td><input type=text name=EmailAddress size=24 maxlength=128></td></tr>
<tr><td>URL</td><td><input type=text name=URL size=24 maxlength=128></td></tr>
<tr><td>Access Level</td><td>
<select name=Level>";
for ($i=1;$i<sizeof($LEVELS);$i++) {
	$VAR["Content"] .= "<option value=\"$i\">$LEVELS[$i]</option>\n";

}
$VAR["Content"] .= "
</select>
</td></tr>
<tr><td>Comment</td><td><textarea name=Comment rows=5 cols=40 wrap=virtual></textarea></td></tr>
";

$VAR["Content"]	.= "
</td>
</tr>

<tr>
<td
	colspan	= 2
	align	= center>
<input	type	= hidden
	name	= what
	value	= \"user\">
<input	type	= submit
	value	= \"" . F_submit() . "\">
</table>
</form>";

F_drawMain($VAR);
include("../include/footer.inc.php");

?>
