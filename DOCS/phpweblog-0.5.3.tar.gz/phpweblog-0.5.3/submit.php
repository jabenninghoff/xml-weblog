<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("./include/common.inc.php");

/* debug */
if (0) {
	F_debug($HTTP_POST_VARS);
}
if (empty($HTTP_POST_VARS) || !F_matchok()) {
	$msg	= urlencode("Access denied!");
	F_logAccess("Access denied trying to submit.");
	header("Location:$G_URL/?msg=$msg");
	exit();
}

switch	($what) {
case "comment":
	if ($save=="on") {
		F_saveUser($Author,$AuthorEmail,$AuthorURL);
	}
	$sql	= "INSERT INTO T_Comments ";
	$sql	.= "(Rid,ParentRid,TopRid,Author,AuthorEmail,AuthorURL,Content,ParseType,Host,Birthstamp) ";
	$sql	.= "VALUES (";
	$sql	.= "'" . F_getRid() . "',";
	$sql	.= "'" . $ParentRid . "',";
	$sql	.= "'" . $TopRid . "',";
	if ($anon=="on") {
		$Author	= "Anonymous";
		$sql	.= "'Anonymous',";
		$sql	.= "'',";
		$sql	.= "'',";
	} else {
		$sql	.= "'" . F_in($Author) . "',";
		$sql	.= "'" . F_in($AuthorEmail) . "',";
		$sql	.= "'" . F_in($AuthorURL) . "',";
	}
	$sql	.= "'" . F_in($Content) . "',";
	$sql	.= "'" . F_in($ParseType) . "',";
	$sql	.= "'" . F_getIP() . "',";
	$sql	.= "now()";
	$sql	.= ")";
	$RET	= @mysql_query($sql,$db);
	if ($RET<1) {
		F_error("Unable to insert comment.");
	} else {
		if ($CONF["EmailComments"]>0) {
			F_mailThread($TopRid,$Author,$Content,$AuthorEmail);
		}
		header("Location:$G_URL/$where");
	}
break;

case "user":
	$sql	= "INSERT INTO T_Users ";
	$sql	.= "(Verified,Username,Password,RealName,EmailAddress,URL,Level,Comment,FirstLogin) ";
	$sql	.= "VALUES (";
	$sql	.= "'Y',";
	$sql	.= "'" . F_in($Username) . "',";
	$sql	.= "'" . F_in(md5($Password)) . "',";
	$sql	.= "'" . F_in($RealName) . "',";
	$sql	.= "'" . F_in($EmailAddress) . "',";
	$sql	.= "'" . F_in($URL) . "',";
	$sql	.= "'1',";
	$sql	.= "'" . F_in($Comment) . "',";
	$sql	.= "now()";
	$sql	.= ")";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Added new user \"$Username\"");
	if ($RET<1) {
		F_error("Unable to insert user.");
	} else {
		F_loginUser($Username,$Password);
	}
	header("Location:$G_URL/stories.php");
	
break;


case "contact":
	$tmp	= urlencode(_MAILERROR);
	if (	!empty($Author) && 
		!empty($AuthorEmail) && 
		!empty($Subject) && 
		!empty($Message) && 
		!empty($MailTo) && 
		!empty($MailToEmail)) {
		$RET	= @mail($MailTo . " <" . rot13($MailToEmail) . ">",
			F_out($Subject),
			F_out($Message),
			"From: $Author <$AuthorEmail>\nReturn-Path: <$AuthorEmail>\nX-Mailer: phpWebLog $G_VER\nX-Originating-IP: " . F_getIP() . "\n");
		if ($RET>0) {
			$tmp	= urlencode(_MAILSENT);
		} else {
			F_error(_MAILERROR);
		}
	}
	header("Location:$G_URL/stories.php?msg=$tmp");
break;
case "mailfriend":
	$tmp	= urlencode(_MAILERROR);
	if (!empty($Author) && 
		!empty($AuthorEmail) && 
		!empty($Story) && 
		!empty($MailTo) && 
		!empty($MailToEmail)) {
		$tmp	= urlencode(_MAILSENT);
		F_mailFriend($Story,$MailTo,$MailToEmail,$Author,$AuthorEmail,$Message);
	}
	header("Location:$G_URL/stories.php?story=$Story&msg=$tmp");
break;
}

?>
