<?
if (!empty($story)) {
	$VAR["Content"]	= F_extractLinks($story);
	if ($CONF["PrintStory"]>0) {
		$VAR["Content"]	.= "<li><a target=\"_blank\" href=\"$G_URL/print.php?story=$story\">" . _PRINTFRIEND . "</a></li>";
	}
	if ($CONF["MailFriend"]>0) {
		$VAR["Content"]	.= "<li><a href=\"$G_URL/friend.php?story=$story\">" . _MAILTOFRIEND . "</a></li>";
	}
	if (!empty($VAR["Content"])) {
		$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);
		F_drawBlock($VAR);
	}
}
?>
