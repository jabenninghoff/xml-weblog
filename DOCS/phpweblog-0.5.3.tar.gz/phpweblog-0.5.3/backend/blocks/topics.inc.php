<?

$VAR["Content"]	= "";
$sql	= "SELECT * FROM T_Topics";
if ($CONF["TopicSort"]=="asc") {
	$sql	.= " ORDER BY Topic ASC";
} elseif ($CONF["TopicSort"]=="desc") {
	$sql	.= " ORDER BY Topic DESC";
}
$topics_result	= @mysql_query($sql,$db);
$topics_nrows	= @mysql_num_rows($topics_result);
if ($CONF["TopicSort"]=="brief") { 
	$numtops = $topics_nrows; 
	if ($topics_nrows > 4) { 
		$topics_nrows = 5; 
	} 
}
for ($i=0;$i<$topics_nrows;$i++) {
	$B	= mysql_fetch_array($topics_result);
	$foo	= $B["Topic"];
	$cmt	= F_count("T_Stories","Topic",$B["Rid"],"Verified","Y");
	if ($B["Rid"]==$topic) {
		$VAR["Content"]	.= sprintf("<em>%s</em> (%s)<br />\n",
			F_out($foo),$cmt);
	} else {
		$VAR["Content"]	.= sprintf("<a href=\"$G_URL/stories.php?topic=%s\">%s</a> (%s)<br />\n",
			$B["Rid"],F_out($foo),$cmt);
	}
}
if ($numtops > $topics_nrows) {
	# if topic display is brief, show more link
	$VAR["Content"]	.= "<br /><div align=right><a href=\"$G_URL/topics.php\">" . _MORE . " &gt;&gt;</a></div>";
}
$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);

#if ($topics_nrows>1) {
	F_drawBlock($VAR);
#}
?>
