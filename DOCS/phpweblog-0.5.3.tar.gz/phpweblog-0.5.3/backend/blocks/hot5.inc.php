<?php

$sql = "SELECT T_Stories.Heading,T_Stories.Rid,count(*) AS Cmts ";
$sql .= "FROM T_Stories,T_Comments ";
$sql .= "WHERE T_Comments.TopRid = T_Stories.Rid ";
$sql .= "AND T_Stories.Verified = 'Y' ";
$sql .= "GROUP BY T_Comments.TopRid ";
$sql .= "ORDER BY Cmts desc ";
$sql .= "LIMIT 5";
$hot5_result = @mysql_query($sql,$db);
$hot5_nrows = mysql_num_rows($hot5_result);

$VAR["Content"] = "";
for ($i=0;$i<$hot5_nrows;$i++) { 
	$B = mysql_fetch_array($hot5_result); 
	$VAR["Content"]	.= "<li><a href=\"" . F_Story($B["Rid"]) . "\">" . F_out($B["Heading"]) . "</a>";
	if($CONF["Comments"] > 0) {
		$VAR["Content"] .= " (" . $B["Cmts"] . ")";
	}
	$VAR["Content"] .= "</li>\n";
}
$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);
F_drawBlock($VAR);

?>
