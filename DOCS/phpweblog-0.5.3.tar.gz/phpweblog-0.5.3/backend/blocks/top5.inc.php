<?php

$sql = "SELECT T_Stories.Heading,T_Stories.Rid,count(*) AS Cmts ";
$sql .= "FROM T_Stories,T_Comments ";
$sql .= "WHERE T_Comments.TopRid = T_Stories.Rid AND ";
$sql .= "T_Stories.Verified = 'Y' ";
$sql .= "GROUP BY T_Comments.TopRid ORDER BY ";
$sql .= "T_Stories.Hits desc LIMIT 5";
$top5_result = @mysql_query($sql,$db);
$top5_nrows = mysql_num_rows($top5_result);

$VAR["Content"] = "";
for ($i=0;$i<$top5_nrows;$i++) { 
	$B = mysql_fetch_array($top5_result); 
	$VAR["Content"]	.= "<li><a href=\"" . F_Story($B["Rid"]) . "\">" . F_out($B["Heading"]) . "</a>\n";
	if($CONF["Comments"] > 0) {
		$VAR["Content"] .= " (" . $B["Cmts"] . ")";
	}
	$VAR["Content"] .= "</li>\n";
}
$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);
F_drawBlock($VAR);

?>
