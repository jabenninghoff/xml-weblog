<?php

$sql = "SELECT Rid,Heading ";
$sql .= "FROM T_Stories ";
$sql .= "WHERE Verified = 'Y' ";
$sql .= "ORDER BY Repostamp desc ";
$sql .= sprintf("LIMIT %s,%s",$CONF["LimitNews"],$CONF["LimitNews"]); 
$older_result = @mysql_query($sql,$db);
$older_nrows = mysql_num_rows($older_result);

$D = "noday";
$VAR["Content"] = "";
while ($B = mysql_fetch_array($older_result)) {
	if ($D != F_dateFormat($B["Repostamp"],"%A")) {
		$D	= F_dateFormat($B["Repostamp"],"%A");
		$VAR["Content"]	.= "<b>" . $D . "</b>\n"; 
	}
	$VAR["Content"]	.= "<li><a href=\"" . F_Story($B["Rid"]) . "\">" . F_out($B["Heading"]) . "</a>";
	if($CONF["Comments"] > 0) {
		$VAR["Content"] .= " (" . F_count("T_Comments","TopRid",$B["Rid"]) . ")";
	}
	$VAR["Content"] .= "</li>\n";
}
$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);
if ($older_nrows>0) {	
	F_drawBlock($VAR);
}

?>
