<?

/* admin menu */
if (F_isLevel(2)) {

	$VAR["Content"] = "";
	$num	= F_Count("T_Stories","Verified","N");
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/moderate.php\">Moderation</a> ($num new)</li>";
	if ($CONF["AllowContrib"]==0) {
		$VAR["Content"]	.= "<li><a href=\"$G_URL/contrib.php\">Add Story</a></li>";
	}
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/site.php\">Site Configuration</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/story.php\">Story Control</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/extended.php\">Extended Config</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/layout.php\">Layout Manager</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/blocks.php\">Blocks Manager</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/pages.php\">Page Manager</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/content.php\">Content Manager</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/topics.php\">Topic Manager</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/users.php\">User Manager</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/logs.php\">View Logs</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/cache_gc.php\">Clear Cache</a></li>";
	$VAR["Content"]	.= "<li><a href=\"$G_URL/admin/logout.php\">Log Out Admin</a></li>";

	foreach (F_getAddonPages("admin.php") as $no=>$arr) {
		$VAR["Content"] .= "<li type=square><a href=\"$G_URL/pages.php?node=" . $arr["Rid"] . "&file=admin.php\">" . $arr["Heading"] . "</a></li>\n";
	}

	$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$VAR["Rid"],"stories.php") . F_shiftBlocks($VAR["Rid"],$VAR["OrderID"],$align);
	F_drawBlock($VAR);

}

?>
