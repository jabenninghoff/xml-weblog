<?php

$sql = "SELECT S.Heading, S.Rid AS SRid, C.Rid AS CRid, C.Author ";
$sql .= "FROM T_Stories S, T_Comments C ";
$sql .= "WHERE S.Verified = 'Y' ";
$sql .= "AND S.Rid = C.TopRid ";
$sql .= "ORDER BY C.Timestamp desc ";
$sql .=" LIMIT 5";
$last5_result = @mysql_query($sql,$db);
$last5_nrows = mysql_num_rows($last5_result);

$VAR["Content"] = "";
for ($i=0;$i<$last5_nrows;$i++) { 
	$B = mysql_fetch_array($last5_result); 
	$VAR["Content"]	.= "<li><small><a href=\"" . F_Story($B["SRid"] . "#" . $B["CRid"]) . "\">" . F_out($B["Heading"]) . "</a> (" . F_out($B["Author"]) . ")";
	$VAR["Content"] .= "</small></li>\n";
}
$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);
F_drawBlock($VAR);

?>
