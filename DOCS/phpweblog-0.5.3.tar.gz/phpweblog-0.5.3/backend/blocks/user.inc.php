<?

/* user login */
if (F_isLevel(1)) {
	global $SESSION;
  $VAR["Content"] = "You are currently logged in as <b>";
  $VAR["Content"] .= $SESSION["USER"]["Username"];
  $VAR["Content"] .= "</b>";
	$VAR["Content"] .= "<li><a href=\"$G_URL/admin/logout.php\">Logout</a></li>\n";
#  if (F_getLevel() == 2) {
#		$VAR["Content"] .= "<br /><small><b>-Moderator-</b></small>";
#	} elseif (F_getLevel() == 3) {
#		$VAR["Content"] .= "<br /><small><b>-Administrator-</b></small>";
#	}
} else {
	$VAR["Content"] = "<small><form method=\"post\" name=\"AUTH\" action=\"$G_URL/login.php\"><b>Login: </b><br /><input type=\"text\" name=\"Username\" size=\"8\" maxlength=\"16\" /><br />";
	$VAR["Content"] .= "<b>Password: <br /></b><input type=\"password\" name=\"Password\" size=\"8\" maxlength=\"16\"><br /></small>\n";
	$VAR["Content"] .= "<input type=\"submit\" name=\"mode\" value=\"login\" /><br /></form>\n";
	$VAR["Content"] .= "[<a href=\"$G_URL/signup.php\">Create An Account</a>]";
}

if (!empty($VAR["Content"])) {
	$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);
	F_drawBlock($VAR);
}

?>
