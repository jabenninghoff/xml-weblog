<?php

$sql	= "SELECT * FROM T_Pages";
$sql	.= " WHERE Display = 'f'";
$sql	.= " ORDER BY Heading ASC";
$features_result	= @mysql_query($sql,$db);
$features_nrows	= mysql_num_rows($features_result);

$VAR["Content"]	= "";
for ($i=0;$i<$features_nrows;$i++) {
	$B	= mysql_fetch_array($features_result);
	$VAR["Content"]	.= sprintf("<a href=\"%s/pages.php?node=%s\">%s</a><br />\n", $G_URL,$B["Rid"],F_out($B["Title"]));
}
if (!empty($VAR["Content"])) {
	$VAR["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);
	F_drawBlock($VAR);
}

?>
