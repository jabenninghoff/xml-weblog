<?php 
//phpWebLog Wap Version 0.0.2 Lirone Chimoni lirone@lirone.com
header("content-type:text/vnd.wap.wml");
header("Pragma: no-cache"); 
header("Cache-Control: no-cache, must revalidate"); 
echo "<?xml version=\"1.0\" ?>\n";
echo '<!DOCTYPE wml PUBLIC "-http://WAPFORUM//DTD WML 1.1//EN" ';
echo '"http://www.wapforum.org/DTD/wml_1.1.xml">';
?>
<wml>
<template>
<do type="prev" label="Back">
<prev/>
</do>
</template>
<?php
include("../include/common.inc.php");
function literal2numeral(&$value, $key) { 
	$value="?".ord($key).";"; 
} 

$trans=get_html_translation_table (HTML_ENTITIES); 
array_walk ($trans, 'literal2numeral'); 
reset($trans); 

function wmlencode($string) { 
	GLOBAL $trans; 
	return strtr($string,$trans); 
} 

$sitename= stripslashes($CONF["SiteName"]);
echo "<card title=\"$sitename Wap Version\">";
echo ("<p>&nbsp;</p>\n");
$db = mysql_connect($G_HOST,$G_USER, $G_PASS);  
mysql_select_db($G_DB,$db);
if (isset($Rid)) {
	$result = mysql_query("SELECT Heading, Content FROM T_Stories Where Rid='$Rid'");
	list($Heading, $Content)=mysql_fetch_row($result);
	echo ("<p><b>$Heading</b></p>\n");
	echo "<p>".stripslashes($Content)."</p>\n";
	$result = mysql_query("SELECT Author, Content FROM T_Comments where TopRid='$Rid' ORDER BY Birthstamp DESC");
	$num = mysql_num_rows($result);
	if ($num) {
		echo ("<p><b>"._COMMENTS."</b></p>\n");
		for($i=1;$i<=$num;$i++) {
			list($Author, $Content)=mysql_fetch_row($result);
			echo "<p>"._POSTEDBY . " " . stripslashes($Author)."</p>\n";
			echo "<p>".stripslashes($Content)."</p>\n";
		}
	} else {
		echo ("<p><b>"._NOCOMMENTS."</b></p>\n");
	}
} else {
	$limit = $CONF["LimitNews"];
	$result = mysql_query("SELECT Rid, Heading FROM T_Stories where Verified='Y' ORDER BY Birthstamp DESC LIMIT $limit");
	for($i=1;$i<=$limit;$i++) {
		list($Rid, $Heading)=mysql_fetch_row($result);
		echo ("<p>$i.) <a href=\"wap.php?Rid=$Rid\">$Heading</a></p>\n");
	}
}
echo ("</card>\n");
?>
</wml>
