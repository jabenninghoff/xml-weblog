#
# Table structure for table 'T_PollAnswers'
#

DROP TABLE IF EXISTS T_PollAnswers;
CREATE TABLE T_PollAnswers (
  Rid char(16) NOT NULL default '',
  Aid int(11) UNSIGNED NOT NULL default '0',
  Answer varchar(255) NOT NULL,
  Votes int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (Rid,Aid)
) TYPE=MyISAM;

#
# Table structure for table 'T_PollQuestions'
#

DROP TABLE IF EXISTS T_PollQuestions;
CREATE TABLE T_PollQuestions (
  Rid char(16) NOT NULL default '',
  Question varchar(255) NOT NULL default '',
  Voters smallint(6) UNSIGNED NOT NULL,
  ExpireDays smallint(6) UNSIGNED NOT NULL,
  BirthStamp datetime NOT NULL,
  Display ENUM('0','l') NOT NULL default '0',
  PRIMARY KEY (Rid)
) TYPE=MyISAM;
