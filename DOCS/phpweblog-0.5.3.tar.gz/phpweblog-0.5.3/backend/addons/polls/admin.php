<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/


function do_admin() {
	global $db,$SELF;
	/*== list polls ==*/
	$VAR["Heading"] = "Polls Manager";

	$sql	= "SELECT * FROM T_PollQuestions ";
	$sql	.= "ORDER BY Rid";
	$result	= mysql_query($sql,$db);
	$nrows	= mysql_num_rows($result);

	$VAR["Content"] = "<table \tborder\t= 0\n";
	$VAR["Content"] .= "\twidth\t= 100%\n";
	$VAR["Content"] .= "\tcellspacing\t=1\n";
	$VAR["Content"] .= "\tcellpadding\t=2>\n";

	if ($nrows==0) {
		$VAR["Content"] .= "<tr><td>You have no defined polls.</td></tr>\n";
	} else {
		$VAR["Content"] .= "<tr>\n";
		$VAR["Content"] .= "<th>Display</th>\n";
		$VAR["Content"] .= "<th>Question</th>\n";
		$VAR["Content"] .= "<th>Votes</th>\n";
		$VAR["Content"] .= "<th>&nbsp;</th>\n";
		$VAR["Content"] .= "</tr>\n";

		for ($i=0;$i<$nrows;$i++) {
			$A	= mysql_fetch_array($result);
			$bg	= $BG[$i%2];
			switch ($A["Display"]) {
				case "0": $tmp = "Off"; break;
				case "1": $tmp = "On"; break;
			}
			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>" . $tmp . "</td>\n";
			$VAR["Content"] .= "<td>" . F_out($A["Question"]) . "</td>\n";
			$VAR["Content"] .= "<td>" . $A["Voters"] . "</td>";
			$VAR["Content"] .= "<td align=center>";
			$VAR["Content"] .= "<small>[ <a href=\"$SELF&file=admin.php&op=edit&item=$A[Rid]\">edit</a> | <a href=\"$SELF&file=admin.php&op=delete&item=$A[Rid]\">delete</a> ]</small>\n";
			$VAR["Content"] .= "</td>\n";
			$VAR["Content"] .= "</tr>\n";
		}
	}

	$VAR["Content"] .= "</table>\n";
	F_drawMain($VAR);

	print "<p>\n";

	/*== add poll ==*/
	$VAR["Heading"] = "Add a New Poll";
	$VAR["Content"] = "<form \taction\t= \"$SELF&file=admin.php\"\n";
	$VAR["Content"] .= "\tmethod\t= post>\n";
	$VAR["Content"] .= "<table cellspacing=1 cellpadding=2 width=\"100%\" border=0>\n\n";

	$VAR["Content"] .= "<tr>\n";
	$VAR["Content"] .= "<td>Question:</td>\n";
	$VAR["Content"] .= "<td><input \ttype\t= text\n";
	$VAR["Content"] .= "\tname \t= \"poll[Question]\"\n";
	$VAR["Content"] .= "\tsize\t=32\n";
	$VAR["Content"] .= "maxlength\t=255></td>\n";
	$VAR["Content"] .= "</tr>\n";

	$VAR["Content"] .= "<tr>\n";
	$VAR["Content"] .= "<td>\n";
	$VAR["Content"] .= " Display\n";
	$VAR["Content"]	.= "</td><td>\n";
	$VAR["Content"] .= "<select	name\t= \"poll[Display]\">\n";
	$VAR["Content"]	.= "<option value\t=\"0\">Off</option>\n";
	$VAR["Content"]	.= "<option value\t=\"1\" selected>On</option>\n";
	$VAR["Content"]	.= "</select>\n";
	$VAR["Content"]	.= "</td>\n";
	$VAR["Content"] .= "</tr>\n";

	$VAR["Content"] .= "<tr>\n";
	$VAR["Content"] .= "<td>Days to Expire:</td>\n";
	$VAR["Content"] .= "<td><input \ttype\t= text\n";
	$VAR["Content"] .= "\tname \t= \"poll[Days]\"\n";
	$VAR["Content"] .= "\tsize\t=3\n";
	$VAR["Content"] .= "\tvalue\t=7\n";
	$VAR["Content"] .= "maxlength\t=3> <small>(cookie expiration)</small></td>\n";
	$VAR["Content"] .= "</tr>\n";

	for ($i=1; $i<=10; $i++) {
		$VAR["Content"] .= "<tr>\n";
		$VAR["Content"] .= "<td>Answer #" . $i . "</td>";
		$VAR["Content"] .= "<td><input type\t=text\n";
		$VAR["Content"] .= "name\t= \"poll[Aid" . $i . "]\"\n";
		$VAR["Content"] .= "\tsize\t= 24\n";
		$VAR["Content"] .= "\tmaxlength\t= 255>\n";
		$VAR["Content"] .= "Votes:<input \ttype\t=text\n";
		$VAR["Content"] .= "\tname \t= poll[Votes" . $i . "]\"\n";
		$VAR["Content"] .= "\tvalue \t= \"0\"\n";
		$VAR["Content"] .= "\tsize\t= 5>\n</td>\n";
		$VAR["Content"] .= "</tr>\n";
	}

	$VAR["Content"] .= "<tr>\n";
	$VAR["Content"] .= "<td colspan=2>";
	$VAR["Content"] .= "<input \ttype\t= hidden";
	$VAR["Content"] .= "\n\tname\t= op\n";
	$VAR["Content"] .= "\tvalue\t= \"add\">\n";
	$VAR["Content"] .= "<input \ttype\t= hidden";
	$VAR["Content"] .= "\n\tname\t= Rid\n";
	$VAR["Content"] .= "\tvalue\t= \"" . F_getRid() . "\">\n";
	$VAR["Content"] .= "<input \ttype\t= submit";
	$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
	$VAR["Content"] .= "</tr>\n";

	$VAR["Content"] .= "</table>\n";
	$VAR["Content"] .= "</form>\n";
	F_drawMain($VAR);
}


function delete_poll($item) {
	global $db;
	/*== destroy record ==*/
	$sql	= "DELETE FROM T_PollQuestions ";
	$sql	.= "WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	F_logAccess("Deleted poll $item");
	if ($RET<1) {
		F_error("Unable to delete item $item from poll questions");
	}
	$sql	= "DELETE FROM T_PollAnswers ";
	$sql	.= "WHERE Rid = '$item'";
	$RET	= @mysql_query($sql,$db);
	if ($RET<1) {
		F_error("Unable to delete item $item from polls.");
	}
	$sql	= "DELETE FROM T_Comments ";
	$sql	.= "WHERE TopRid = '$item'";
	$RET	= @mysql_query($sql,$db);
	if ($RET<1) {
		F_error("Unable to delete item $item from comments.");
	}
}


function edit_poll($item) {
	global $db,$SELF;
	$sql	= "SELECT * FROM T_PollQuestions ";
	$sql	.= "WHERE Rid='$item'";
	$question	= mysql_query($sql,$db);
	$nquestions 	= mysql_num_rows($question);
	if ($nquestions > 0) {
		$sql	= "SELECT Answer,Aid,Votes FROM T_PollAnswers ";
		$sql	.= "WHERE Rid='$item' ORDER BY Aid";
		$answers	= mysql_query($sql,$db);
		$nanswers	= mysql_num_rows($answers);
		if ($nanswers > 0) {
			$Q = mysql_fetch_array($question);
			$VAR["Heading"] = "Edit : Poll : " . $Q["Rid"];
			$VAR["Content"] = "<form \taction\t= \"$SELF&file=admin.php\"\n";
			$VAR["Content"] .= "\tmethod\t= post>\n";

			$VAR["Content"] .= "<table\n";
			$VAR["Content"] .= "\tborder\t= \"0\"\n";
			$VAR["Content"] .= "\tcellspacing\t= \"1\"\n";
			$VAR["Content"] .= "\tcellpadding\t= \"2\"\n";
			$VAR["Content"] .= "\twidth\t= \"100%\">\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>Question:</td>\n";
			$VAR["Content"] .= "<td><input \ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname \t= \"poll[Question]\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_out($Q["Question"]) . "\"\n";
			$VAR["Content"] .= "\tsize\t=32\n";
			$VAR["Content"] .= "maxlength\t=255></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>Display</td>\n";
			$VAR["Content"] .= "<td>\n";
			$VAR["Content"] .= "<select name\t=\"poll[Display]\">\n";
			$VAR["Content"] .= "<option value=\"0\" " . ($Q["Display"] == "0" ? "selected" : "") . ">Off</option>\n";
			$VAR["Content"] .= "<option value=\"1\" " . ($Q["Display"] == "1" ? "selected" : "") . ">On</option>\n";
			$VAR["Content"] .= "</select></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>Expiration:</td>\n";
			$VAR["Content"] .= "<td><input \ttype\t= \"text\"\n";
			$VAR["Content"] .= "\tname \t= \"poll[Days]\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . $Q["ExpireDays"] . "\"\n";
			$VAR["Content"] .= "\tsize\t=3\n";
			$VAR["Content"] .= "maxlength\t=3> days</td>\n";
			$VAR["Content"] .= "</tr>\n";

			for ($i=1; $i<=10; $i++) {
				$A	= mysql_fetch_array($answers);
				$VAR["Content"] .= "<tr>\n";
				$VAR["Content"] .= "<td>Answer #" . $i . "</td>";
				$VAR["Content"] .= "<td>\n<input \ttype\t= \"text\"\n";
				$VAR["Content"] .= "\tname\t= \"poll[Aid" . $i . "]\"\n";
				$VAR["Content"] .= "\tvalue\t= \"" . F_out($A["Answer"]) . "\"\n";
				$VAR["Content"] .= "\tsize\t= 24\n";
				$VAR["Content"] .= "\tmaxlength\t= 255>\n";
				$VAR["Content"] .= "Votes:\n<input \ttype\t= \"text\"\n";
				$VAR["Content"] .= "\tname \t= \"poll[Votes" . $i . "]\"\n";
				$VAR["Content"] .= "\tvalue\t= \"" . $A["Votes"] . "\"\n";
				$VAR["Content"] .= "\tsize\t= 5>\n</td>\n";
				$VAR["Content"] .= "</tr>\n";
			}

			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td colspan=2>";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"op\"\n";
			$VAR["Content"] .= "\tvalue\t= \"add\">\n";
			$VAR["Content"] .= "<input\ttype\t= hidden\n";
			$VAR["Content"] .= "\tname\t= \"Rid\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . $Q["Rid"] . "\">\n";
			$VAR["Content"] .= "<input \ttype\t= submit";
			$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
			$VAR["Content"] .= "</tr>\n";
			$VAR["Content"] .= "</table>\n";
			$VAR["Content"] .= "</form>\n";
			F_drawMain($VAR);
		} else {
			F_error("Unable to select poll answer.");
		}
	} else {
		F_error("Unable to select poll question.");
	}
}

function add_poll($Rid) {
	global $db,$poll;
	F_logAccess("Updated poll $Rid");
	$A[1] = $poll[Aid1];
	$A[2] = $poll[Aid2];
	$A[3] = $poll[Aid3];
	$A[4] = $poll[Aid4];
	$A[5] = $poll[Aid5];
	$A[6] = $poll[Aid6];
	$A[7] = $poll[Aid7];
	$A[8] = $poll[Aid8];
	$A[9] = $poll[Aid9];
	$A[10] = $poll[Aid10];
	$V[1] = $poll[Votes1];
	$V[2] = $poll[Votes2];
	$V[3] = $poll[Votes3];
	$V[4] = $poll[Votes4];
	$V[5] = $poll[Votes5];
	$V[6] = $poll[Votes6];
	$V[7] = $poll[Votes7];
	$V[8] = $poll[Votes8];
	$V[9] = $poll[Votes9];
	$V[10] = $poll[Votes10];
	$Voters = 0;
	for ($i=1; $i<=10; $i++) {
		$Voters = $Voters + $V[$i];
	}

	if (empty($Voters)) { $Voters = "0"; }
	$sql	= "DELETE FROM T_PollQuestions WHERE Rid = '$Rid'";
	$result = mysql_query($sql,$db);
	$sql	= "DELETE FROM T_PollAnswers WHERE Rid = '$Rid'";
	$result = mysql_query($sql,$db);

	$sql	= "INSERT INTO T_PollQuestions ";
	$sql	.= "(Rid, Question, Voters, ExpireDays, Birthstamp, Display) ";
	$sql	.= "VALUES (";
	$sql	.= "'" . $Rid . "',";
	$sql	.= "'" . F_in($poll[Question]) . "',";
	$sql	.= $Voters . ",";
	$sql	.= $poll[Days] . ",";
	$sql	.= "now(),";
	$sql	.= "'" . $poll[Display] . "')";
	$result = mysql_query($sql,$db);
	for ($i = 1; $i <= 10; $i++) {
		if (!empty($A[$i])) {
			if (empty($V[$i])) { $V[$i] = "0"; }
			$sql 	= "INSERT INTO T_PollAnswers ";
			$sql	.= "(Rid, Aid, Answer, Votes) ";
			$sql	.= "VALUES (";
			$sql	.= "'" . $Rid . "',";
			$sql	.= $i . ",";
			$sql	.= "'" . F_in($A[$i]) . "',";
			$sql	.= $V[$i] . ")";
			$result = mysql_query($sql,$db);
		}
	}
}









if (F_isLevel(3)) {
	switch ($op) {

	case "edit":
		edit_poll($item);
	break;
	case "delete":
		delete_poll($item);
		do_admin();
	break;
	case "add";
		add_poll($Rid);
		do_admin();
	break;
	default:
		do_admin();
	break;

	}
} else {
	$VAR["Heading"] = "No Access";
	$VAR["Content"] = "Access denied";
	F_drawMain($VAR);
	F_logAccess("Access denied trying to edit polls as non-admin.");
}

?>