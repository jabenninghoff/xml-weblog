<?
        include_once($PATH . "/polls.inc.php");

        # fetch all poll questions
        $sql        = "SELECT Rid FROM T_PollQuestions ";
        $sql        .= "WHERE Display = '1'";
        $polls_result = @mysql_query($sql,$db);
        /* $polls_result will be false if query fails */
        if (!$polls_result) {
                $polls_nrows = 0;
        } else {
                $polls_nrows = mysql_num_rows($polls_result);
        }

        # polls block
        for ($i=1; $i<=$polls_nrows; $i++) {
                $A = mysql_fetch_array($polls_result);
                $rid = $A["Rid"];
                if (empty($HTTP_COOKIE_VARS["$rid"])) {
                        F_pollVote($rid,"block",$SELF);
                } else {
                        F_pollResultsBlock($rid,$SELF);
                }
        }

?>
