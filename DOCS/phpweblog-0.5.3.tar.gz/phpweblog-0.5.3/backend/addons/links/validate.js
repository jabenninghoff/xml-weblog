function validateLink() {
	   field = document.Link.linkname; 
	   if (JS_isBlank(field, "Site Name")) return false;
	   
	   field = document.Link.url; 
	   if (JS_isBlank(field, "URL")) return false;
	   if (JS_isBadURL(field, "URL")) return false;

	   field = document.Link.subname; 
	   if (JS_isBlank(field, "Name")) return false;
	   
	   field = document.Link.subemail; 
	   if (JS_isBlank(field, "Email Address")) return false;
	   if (!JS_isEmail(field, "Email Address")) return false;

	return true;
}
