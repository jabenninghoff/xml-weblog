<?

function do_main($id="",$start=0) {
	$A["Heading"] = ucwords(_LINKS);
	$A["Content"] = F_idwalk($id,0);
	$A["Content"] .= F_showids($id);
	$A["Content"] .= "<br>\n";
	$A["Content"] .= F_showitems($id,$start);
	$A["Content"] .= F_suggest($id);
	F_drawMain($A);

	if(F_isLevel(3)) { 
		do_admin();
	}


}


function F_idwalk($startid="",$linklast=0) { 
	global $SELF,$db;
	$currid = $startid;
	while(!empty($currid)) {
		$sql	= "SELECT Rid,Name from T_LinkCats ";
		$sql	.= "WHERE Rid='$currid' ";
		$sql	.= "AND Verified='1'";
		$result=mysql_query($sql,$db);
		list($id,$name,$currid) = mysql_fetch_row($result);
		if (!empty($name)) {
			if($id != $startid) {
				$temp = " &gt; <a href=\"$SELF&id=$id\">$name</a>" . $output;
				$output = $temp;
			} else {
				if($linklast == 1) {
					$temp = " &gt; <a href=\"$SELF&id=$id\">$name</a>" . $output;
					$output = $temp;
				} else {
					$temp = " &gt; $name " . $output;
					$output = $temp;
				}
			}
		}
	}
	$temp = "<a href=\"$SELF\">Top</a>" . $output;
	return $temp;
}

function F_showids($id="") { 
	global $db,$SELF;
	if ((empty($id)) || ($id=="null")) { 
		$search = "ParentRid='NULL'"; 
	} else {
		$search = "ParentRid='$id'"; 
	}
	$output = "<table cellpadding=2 cellspacing=0 border=0 width=\"100%\">";
	$sql	= "SELECT Rid,Name FROM T_LinkCats ";
	$sql	.= "WHERE $search and Verified='1' ";
	$sql	.= "AND length(Name) > 1 ORDER BY Name";
	$result = mysql_query($sql,$db);
	$numrows = mysql_num_rows($result);
	$half = $numrows / 2;
	$count = 0;
	$output .="<tr><td valign=top>\n";
	while($count < $half) { 
		list($id,$name) = mysql_fetch_row($result);
		$cnt	= F_count("T_Links","CatRid",$id,"Verified","1");
		$output .="<li><a href=\"$SELF&id=$id\">$name</a> ($cnt)";
		if(F_isLevel(3)) { 
			$output .= " <small>[ <a href=\"$SELF&editlinkcat=$id\">"._EDIT."</a> | <a href=\"$SELF&dellinkcat=$id\">"._KILL."</a> ]</small>\n"; 
		}
		$output .= "</li>\n";
		$count++;
	}
	$output .="</td><td valign=top>\n";
	while(list($id,$name) = mysql_fetch_row($result)) { 
		$cnt    = F_count("T_Links","CatRid",$id,"Verified","1");
		$output .= "<li><a href=\"$SELF&id=$id\">$name</a> ($cnt)";
		if(F_isLevel(3)) { 
			$output .= " <small>[ <a href=\"$SELF&editlinkcat=$id\">"._EDIT."</a> | <a href=\"$SELF&dellinkcat=$id\">"._KILL."</a> ]</small>\n"; 
		}
		$output	.= "</li>\n";
	}
	$output .="</td></tr></table>";
	return $output;
}

function F_showitems($id="",$start="") {
	global $db,$SELF,$G_URL;
	if ((empty($id)) || ($id=="null"))  { 
		$search = "CatRid = 'NULL'"; 
	} else { 
		$search = "CatRid = '$id'"; 
	}
	$output = "<table width=\"100%\" cellspacing=\"2\">";
	$sql	= "SELECT Rid from T_Links ";
	$sql	.= "WHERE $search and Verified='1'";
	$temp = mysql_query($sql,$db);
	$total = mysql_num_rows($temp);
	if ($total > 0) { 
		if ($start > 0) { 
			$pr = $start - 26;
			if ($pr < 0) { $pr = 0; }
			$prevlink = "<a href=\"$SELF&id=$id&start=$pr\">[&lt;&lt; " . _PREV . "]</a>";
		}
		if (empty($start)) { $start = 0; }
		$end = $start + 25;
		if ($end > $total) { $end = $total; }
		if ($end < $total) { 
			$nx = $end + 1;
			$nextlink = "<a href=\"$SELF&id=$id&start=$nx\">[" . _NEXT . " &gt;&gt;]</a>";
		}
		$tmp	= $start+1;
		$display = _SHOWING . " <b>$tmp</b> - <b>$end</b> of <b>$total</b>";
		$sql	= "SELECT Rid,Url,Name,Description,Hits ";
		$sql	.= "FROM T_Links ";
		$sql	.= "WHERE $search and Verified='1' ";
		$sql	.= "ORDER BY Name limit $start,25";
		$result = mysql_query($sql,$db);
		$ck = 0;
		while (list($id,$url,$name,$desc,$hits) = mysql_fetch_row($result)) { 
			$ck++;
			if(($ck % 2) < 1) { 
				$output .= "<tr><td>"; 
			} else { 
				$output .="<tr><td>"; 
			}
			$tmp	= urlencode($url);
			$output	.= "<a href=\"$G_URL/portal.php?url=$tmp&what=T_Links&rid=$id\" target=\"_blank\" onMouseOver=\"window.status='" . urldecode($tmp) . "'; return true;\">$name</a> ($hits) - <small>$url</small>\n";
			if (!empty($desc)) {
				$output	.= "<br>&nbsp;&nbsp;&nbsp;<small>$desc</small>";
			}
			$output	.= "</td></tr>";
			if(F_isLevel(3)) { 
				$output .= "<tr><td><small>[ <a href=\"$SELF&unapprove=$id\">"._UNOK."</a> | <a href=\"$SELF&editlink=$id\">"._EDIT."</a> ]</small></td></tr>"; 
			}
			$output .="</td></tr>\n";
		}
		$output .= "</table><center>$prevlink $display $nextlink</center>";
	} else { 
		$output = _NOLINKS;
	}
	return $output;
}

function F_suggest($id="") {
	global $SELF;
	if ($id == "") { $id = "null"; }
	$output	= "<table width=\"100%\">\n";
	$output	.= "<tr><form action=\"$SELF\" method=POST>\n<td align=\"center\">" . _FIND . " <input type=\"text\" name=\"search\" size=15></td></form></tr>\n";
	$output	.= "<tr><td align=\"center\"><a href=\"$SELF&sugid=$id\">" . _SUGCAT . "</a> | <a href=\"$SELF&suglink=$id\">" . _SUGLINK . "</a></td></tr>\n";
	$output	.= "</table>";
	return $output;
}

function F_suggestid($id="") { 
	global $db,$SELF;
	$output = F_idwalk($id,1);
	$output .= "<table width=\"100%\">
	<form action=\"$SELF\" name=\"SUGNODE\" method=POST onsubmit=\"return validateSugNode();\">
	<tr><td width=\"15%\">" . _CATEGORY . ":</td><td><input type=\"text\" name=\"newid\" size=\"40\"><input type=\"hidden\" name=\"parent\" value=\"$id\"></td></tr>
	<tr><td></td><td><input type=\"submit\" name=\"addid\" value=\"" . F_submit() . "\"></td></tr>
	</form>
	</table>";
	return $output;
}

function editlink($id="") {
	global $db,$SELF;
	$sql	= "SELECT Rid,CatRid,Url,Name,Description,Verified,SubmitName,";
	$sql	.= "SubmitEmail,SubmitDate from T_Links ";
	$sql	.= "WHERE Rid='$id'";
	$result = mysql_query($sql,$db);
	if (mysql_num_rows($result) < 1) { 
		$output = "No such ID"; 
	} else {
		list($linkid,$catid,$url,$linkname,$desc,$approved,$sname,$semail,$sdate) = mysql_fetch_row($result);
		$output = F_idwalk($catid,1);
		$output .= "<table width=\"100%\" border=0>\n";
		$output	.= "<form action=\"$SELF\" method=POST>\n";
		$output	.= "<tr><td width=\"15%\">" . _SITENAME . ":</td><td><input type=\"text\" name=\"linkname\" size=\"40\" value=\"$linkname\">\n";
		$output	.= "<input type=\"hidden\" name=\"linkid\" value=\"$linkid\"></td></tr>\n";
		$output	.= "<tr><td width=\"15%\">" . _DESCRIPTION . ":</td><td><input type=\"text\" name=\"description\" size=\"60\" value=\"$desc\"></td></tr>\n";
		$output	.= "<tr><td width=\"15%\">" . _URL . ":</td><td><input type=\"text\" name=\"url\" size=\"60\" value=\"$url\"></td></tr>\n";
		$output	.= "<tr><td width=\"15%\">" . _CATEGORY . ":</td><td><select name=\"category\">\n";
		$output	.= F_listCats($catid);
		$output	.= "</select></td></tr>\n";
		$output	.= "<tr><td width=\"15%\">" . _NAME . ":</td><td><input type=\"text\" name=\"subname\" size=\"60\" value=\"$sname\"></td></tr>\n";
		$output	.= "<tr><td width=\"15%\">" . _EMAIL . ":</td><td><input type=\"text\" name=\"subemail\" size=\"60\" value=\"$semail\"></td></tr>\n";
		$output	.= "<tr><td>&nbsp;</td><td><input type=\"submit\" name=\"updatelink\" value=\"" . F_submit() . "\"></td></tr>\n";
		$output	.= "</form>\n</table>";
	}
	return $output;
}

function F_suggestlink($id="") {
	global $db,$SELF,$USER;
	$output = F_idwalk($id,1);
	$output .= "<table width=\"100%\">
	<form action=\"$SELF\" method=POST name=\"Link\" onsubmit=\"return validateLink();\">
	<tr><td width=\"15%\">" . _SITENAME . ":</td><td><input type=\"text\" name=\"linkname\" size=\"40\" maxlength=64>
	<input type=\"hidden\" name=\"parent\" value=\"$id\"></td></tr>
	<tr><td width=\"15%\">" . _DESCRIPTION . ":</td><td><input type=\"text\" name=\"description\" size=\"40\" maxlength=255></td></tr>
	<tr><td width=\"15%\">" . _URL . ":</td><td><input type=\"text\" name=\"url\" size=\"40\" maxlength=255></td></tr>
	<tr><td width=\"15%\">" . _NAME . ":</td><td><input type=\"text\" name=\"subname\" value=\"" . $USER[Author] . "\" size=\"40\"></td></tr>
	<tr><td width=\"15%\">" . _EMAIL . ":</td><td><input type=\"text\" name=\"subemail\" value=\"" . $USER[AuthorEmail] . "\" size=\"40\"></td></tr>
	<tr><td></td><td><input type=\"submit\" name=\"addlink\" value=\"" . F_submit() . "\"></td></tr>
	</form>
	</table>";
	return $output;
}

function do_search($keywords="",$start) {
	global $db,$SELF,$G_URL;
	$kw = urlencode($keywords);
	$sql	= "SELECT distinct Rid from T_Links ";
	$sql	.= "WHERE (Name like '%$keywords%' ";
	$sql	.= "or Description like '%$keywords%') ";
	$sql	.= "AND Verified='1'";
	$temp  = mysql_query($sql,$db);
	$total = mysql_num_rows($temp);
	if ($total > 0) {
		if($total > 1) { $rs = "s"; }
		$header = "$total result$rs found";
		$output = "<table width=\"100%\" cellspacing=\"2\">";
		if ($start > 0) { 
			$pr = $start - 26;
			if ($pr < 0) { $pr = 0; }
			$prevlink = "<a href=\"$SELF&search=$kw&start=$pr\">[&lt;&lt; " . _PREV . "]</a>";
		}
		if (empty($start)) { $start = 0; }
		$end = $start + 25;
		if ($end > $total) { $end = $total; }
		if ($end < $total) { 
			$nx = $end + 1;
			$nextlink = "<a href=\"$SELF&search=$kw&start=$nx\">[" . _NEXT . " &gt;&gt;]</a>";
		}
		$display = _SHOWING . " $start - $end";
		$sql	= "SELECT distinct CatRid,Rid,Url,Name,Description ";
		$sql	.= "FROM T_Links ";
		$sql	.= "WHERE (Name like \"%$keywords%\" or ";
		$sql	.= "Description like \"%$keywords%\") ";
		$sql	.= "AND Verified='1' ";
		$sql	.= "ORDER BY Name limit $start,25";
		$result = mysql_query($sql,$db);
		$ck = 0;
		while (list($cat,$id,$url,$name,$desc) = mysql_fetch_row($result)) { 
			$ck++;
			$id = F_idwalk($cat,1);
			if(($ck % 2) < 1) { 
				$output .= "<tr><td bgcolor=\"#DDDDDD\">"; 
			} else { 
				$output .="<tr><td>"; 
			}
			$tmp	= urlencode($url);
			$output	.= "<a href=\"$G_URL/portal.php?url=$tmp&what=T_Links&rid=$id\" target=\"_blank\">$name</a> ($hits) - <small>$url</small>\n";
			if (!empty($desc)) {
				$output	.= "<br>&nbsp;&nbsp;&nbsp;<small>$desc</small>";
			}
			$output	.= "<br>&nbsp;&nbsp;&nbsp;<small>[" . $id . "]</small>";
			if(F_isLevel(3)) { $output .= "<tr><td><small>[ <a href=\"$SELF&unapprove=$id\">"._UNOK."</a> | <a href=\"$SELF&editlink=$id\">"._EDIT."</a> ]</small></td></tr>"; }
		}
		$output .= "</table><center>$prevlink $display $nextlink</center>";
	} else { 
		$header = _SEARCHRESULTS;
		$output = _NOMATCHES;
	}
	$A["Heading"]=$header;
	$A["Content"]=$output;
	F_drawMain($A);
	$suggest = F_suggest("");
	$A["Heading"]="Search";
	$A["Content"]=$suggest;
	F_DrawMain($A);
}

function do_admin() {
	global $db,$SELF,$G_URL;
	$sql	= "SELECT Rid,Name,ParentRid from T_LinkCats ";
	$sql	.= "WHERE Verified='0' ";
	$sql	.= "ORDER BY Name";
  $result = mysql_query($sql,$db);
	if(mysql_num_rows($result) > 0) {
		$A["Heading"]= _SUBMITTEDCATS;
		$A["Content"]="<table width=\"100%\" border=0><tr><td valign=top>\n";
		while(list($CatID,$CatName,$CatParent) = mysql_fetch_row($result)) {
			$A["Content"] .= "$CatName <small>(" . F_idwalk($CatParent,1) .")</small><br>\n";
			$A["Content"] .= " <small>[ <a href=\"$SELF&approveid=$CatID\">" . _OK . "</a> | <a href=\"$SELF&delid=$CatID\">" ._UNOK. "</a> ]</small>";
		}
		$A["Content"] .= "</td></tr></table>";
		F_drawMain($A);
	}
	$sql	= "SELECT Rid,CatRid,Url,Name,Description,SubmitName,";
	$sql	.= "SubmitEmail,SubmitDate from T_Links ";
	$sql	.= "WHERE Verified='0' ";
	$sql	.= "ORDER BY Name";
	$result = mysql_query($sql,$db);
	if(mysql_num_rows($result) > 0) { 
		$A["Heading"]= _SUBMITTEDLINKS;
		$A["Content"]="<table width=\"100%\"><tr><td>\n";
		while(list($id,$cat,$url,$name,$desc,$sname,$semail,$sdate) = mysql_fetch_row($result)) {
			$A["Content"] .= "<a target=_blank href=\"$url\">$name</a> <small>(" . F_idwalk($cat,1) .")</small><br>\n";
			$A["Content"] .= "<small>Description: $desc <br>URL: $url</small><br><small>Submitted by <a href=\"mailto:$semail\">$sname</a> on ".F_dateFormat($sdate)."</small><br>";
			$A["Content"] .= " <small>[ <a href=\"$SELF&approvelink=$id\">" ._OK. "</a> | <a href=\"$SELF&dellink=$id\">" ._KILL. "</a> ]</small><p>";
		}
		$A["Content"] .= "</td></tr></table>";
		F_drawMain($A);
	}
}

function F_listcats($cat) {
	global	$db;
	$sql	= "SELECT Rid,Name from T_LinkCats ";
	$sql	.= "WHERE Verified = '1'";
	$sql	.= " ORDER BY Name";
	$result	= mysql_query($sql,$db);
	$sel	= $cat=="null" ? "selected" : "";
	$s	= "<option value=\"null\" $sel>Top</option>";
	while (list($id,$name,) = mysql_fetch_row($result)) {
		$sel	= $cat==$id ? "selected" : "";
		$s	.= "<option value=\"$id\" $sel>$name</option>\n";
	}
	return $s;
}


function editlinkcat($item) {
	global $db,$SELF;
	$sql	= "SELECT * FROM T_LinkCats ";
	$sql	.= "WHERE Rid = '$item'";
	$result	= @mysql_query($sql,$db);
	if ($result<1) {
		F_notice("Unable to select link category.");
	}
	$A	= mysql_fetch_array($result);

	$output = "<form\taction\t= \"$SELF\"\n";
	$output .= "\tmethod\t= post>\n";

	$output .= "<table\n";
	$output .= "\tborder\t= \"0\"\n";
	$output .= "\tcellspacing\t= \"1\"\n";
	$output .= "\tcellpadding\t= \"2\"\n";
	$output .= "\twidth\t= \"100%\">\n";
	$output .= "<tr>\n";
	$output .= "<td>\n";
	$output .= _CATNAME .":</td>\n";
	$output .= "<td>\n";
	$output .= "<input\ttype\t= \"text\"\n";
	$output .= "\tname\t= \"Category\"\n";
	$output .= "\tvalue\t= \"$A[Name]\"\n";
	$output .= "\tsize\t= 40\n";
	$output .= "\tmaxlength\t= 48></td><td>&nbsp;</td>\n";
	$output .= "</tr>\n";

	$output .= "<tr>\n";
	$output .= "<td>\n";
	$output .= _PARENTCAT .":</td>\n";
	$output .= "<td>\n";
	$output .= "<select\tname\t= \"ParentCat\">\n";
	$output .= F_listcats($A["ParentRid"]);
	$output .= "</select>\n";
	$output	.= "</tr>\n";

	$output .= "<tr>\n";
	$output .= "<td\tcolspan\t= 3\n";
	$output .= "\talign\t= center>\n";
	$output .= "<input\ttype\t= hidden\n";
	$output .= "\tname\t= \"mode\"\n";
	$output .= "\tvalue\t= \"edit\">\n";
	$output .= "<input\ttype\t= hidden\n";
	$output .= "\tname\t= \"item\"\n";
	$output .= "\tvalue\t= \"$A[Rid]\">\n";
	$output .= "<input\ttype\t= \"submit\" name=\"update_linkcat\"\n";
	$output .= "\tvalue\t= \"" . F_submit() . "\"></td>\n";
	$output .= "</tr></table></form>\n";
	return $output;
}

?>