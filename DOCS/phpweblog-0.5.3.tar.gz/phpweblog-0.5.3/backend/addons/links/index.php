<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

# Original links code written by Twyst (http://anime-central.net)
# Modified for use with phpWebLog by Jason Hines
# Thanks Twyst!

include_once($PATH . "/functions.php");

?>
<script language="javascript" src="<?=$URL?>/validate.js"></script>
<?



if ($editlink) {
	$edit = editlink($editlink);
	$A["Heading"] = "Editing Link";
	$A["Content"] = $edit;
	F_drawMain($A);

} else if ($editlinkcat) {
	$edit = editlinkcat($editlinkcat);
	$A["Heading"] = "Editing Link Category";
	$A["Content"] = $edit;
	F_drawMain($A);

} else if ($updatelink) {
	$sql	= "UPDATE T_Links set ";
	$sql	.= "Name='$linkname',";
	$sql	.= "Url='$url',";
	$sql	.= "CatRid='$category',";
	$sql	.= "Description='$description',";
	$sql	.= "SubmitName='$subname',";
	$sql	.= "SubmitEmail='$subemail' ";
	$sql	.= "WHERE Rid='$linkid'";
	@mysql_query($sql,$db);
	F_logAccess("Updated link $linkid");
	F_notice("Link successfully changed.");
	do_main();

} else if ($update_linkcat) {
	if ($ParentCat==$item) {
		$ParentCat	= "null";
	}
	$sql	= "UPDATE T_LinkCats set ";
	$sql	.= "Name = '" . $Category . "',";
	$sql	.= "ParentRid = '" . $ParentCat . "'";
	$sql	.= " WHERE Rid = '$item' ";
	@mysql_query($sql,$db);
	F_logAccess("Updated link category $item");
	do_main();

} else if ($unapprove) {
	$sql	= "UPDATE T_Links set Verified='0' ";
	$sql	.= "WHERE Rid='$unapprove'";
	@mysql_query($sql,$db);
	F_logAccess("Unapproved link $unapprove");
	F_notice("Link successfully unapproved.");
	do_main();

} else if ($approveid) { 
	$sql	= "UPDATE T_LinkCats SET Verified='1' ";
	$sql	.= "WHERE Rid='$approveid'";
	$result=mysql_query($sql,$db);
	F_logAccess("Approved link $approvedid");
	F_notice("Link successfully approved.");
	do_main();

} else if ($approvelink) { 
	$sql	= "UPDATE T_Links SET Verified='1' ";
	$sql	.= "WHERE Rid='$approvelink'";
	$result=mysql_query($sql,$db);
	F_notice("Link successfully approved.");
	do_main();

} else if ($delid) {
	$sql	= "DELETE FROM T_LinkCats ";
	$sql	.= "WHERE Verified='0' ";
	$sql	.= "AND Rid='$delid'";
	$result=mysql_query($sql,$db);
	F_notice("Node successfully deleted.");
	do_main();

} else if ($dellink) {
	$sql	= "DELETE FROM T_Links ";
	$sql	.= "WHERE Verified='0' ";
	$sql	.= "AND Rid='$dellink'";
	$result=mysql_query($sql,$db);
	F_logAccess("Deleted link $dellink");
	F_notice("Link successfully deleted.");
	do_main();

} else if ($dellinkcat) {
  F_killChildren("T_LinkCats",$dellinkcat);
  F_logAccess("Deleted link category $dellinkcat"); 
	do_main();

} else if ($sugid) {
	$A["Heading"] = _ADDSUG;
	$A["Content"] = F_suggestid($sugid);
	F_drawMain($A);

} else if ($suglink) { 
	$A["Heading"] = _ADDSUG;
	$A["Content"] = F_suggestlink($suglink);
	F_drawMain($A);

} else if ($addid) { 
	if(F_isLevel(3)) { $appr = 1; } else { $appr = 0; }        
	$sql	= "INSERT into T_LinkCats ";
	$sql	.= "(Rid,Name,ParentRid,Verified) values ";
	$sql	.= "('" . F_getRid() . "','$newid','$parent','$appr')";
	@mysql_query($sql,$db);
	F_notice(_SUGTHANK);
	do_main($parent);

} else if ($addlink) { 
	if(F_isLevel(3)) { $appr = 1; } else { $appr = 0; }
	$sql	= "INSERT into T_Links ";
	$sql	.= "(Rid,CatRid,Url,Name,Description,Verified,Hits,";
	$sql	.= "SubmitName,SubmitEmail,SubmitDate) values ";
	$sql	.= "('" . F_getRid() . "','$parent','$url','$linkname','$description',";
	$sql	.= "'$appr',0,'$subname','$subemail',now())";
	@mysql_query($sql,$db);
	F_notice(_SUGTHANK);
	do_main($parent);

} else if ($search) { 
	do_search($search,$start);

} else {
	do_main($id,$start);
}

?>
