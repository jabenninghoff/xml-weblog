#
# Table structure for table 'T_LinkCats'
#

DROP TABLE IF EXISTS T_LinkCats;
CREATE TABLE T_LinkCats (
  Rid char(16) NOT NULL default '',
  Name varchar(50) NOT NULL default '',
  ParentRid char(16) NOT NULL default '',
  Verified char(1) NOT NULL default 'Y',
  PRIMARY KEY (Rid)
) TYPE=MyISAM;

#
# Table structure for table 'T_Links'
#

DROP TABLE IF EXISTS T_Links;
CREATE TABLE T_Links (
  Rid char(16) NOT NULL default '',
  CatRid char(16) NOT NULL default '',
  Url varchar(255) NOT NULL default '',
  Name varchar(64) NOT NULL default '',
  Description varchar(255) NOT NULL default '',
  Verified char(1) NOT NULL default 'Y',
  SubmitName varchar(64) NOT NULL default '',
  SubmitEmail varchar(96) NOT NULL default '',
  SubmitDate datetime NOT NULL,
  Hits int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (Rid),
  UNIQUE KEY Url(Url)
) TYPE=MyISAM;
