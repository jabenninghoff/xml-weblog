<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("./include/common.inc.php");
include("./include/header.inc.php");


# list all months
$sql	= "SELECT UNIX_TIMESTAMP(Repostamp) AS TS ";
$sql	.= "from T_Stories ";
$sql	.= "WHERE Verified = 'Y' ";
$sql	.= "ORDER BY TS desc ";
$result = @mysql_query($sql,$db);
$nrows  = mysql_num_rows($result);

$VAR["Heading"]	= _STORY . " " . _ARCHIVE;
$VAR["Content"]	= "";
for ($i=0;$i<$nrows;$i++) {
	$A	= mysql_fetch_array($result);

	$vm	= strftime("%B",$A["TS"]);
	$m	= (double) strftime("%m",$A["TS"]);
	$y	= strftime("%Y",$A["TS"]);

	if ($oldMonth!=$vm) {
		$VAR["Content"]	.= "<a href=\"$G_URL/archive.php?";
		$VAR["Content"]	.= "month=$m";
		$VAR["Content"]	.= "&amp;year=$y";
		$VAR["Content"]	.= "\">";
		$VAR["Content"]	.= $vm . " " . $y;
		$VAR["Content"]	.= "</a>\n";
		$oldMonth	= $vm;
	}
}
F_drawMain($VAR);


if (!empty($month) && !empty($year)) {

	print "<br /><br />\n";
	F_drawResults("",0,"stories",0,$month,$year);

}

include("./include/footer.inc.php");

?>
