<!-- begin footer.inc.php -->
</td>

<?php
	if (!$et = cache($G_CACHE, cache_default_object(), "RightBlock")) {
		F_doBlocks("r");
		endcache();
	}
?>

</tr>
</table>

<!-- end inside spread -->

<?php
	F_drawFooter();
?>
<!-- EOF -->
</body>
</html>
