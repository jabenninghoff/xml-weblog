<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/


function F_parseContent($input, $parsetype) {

	global $G_HTML;
	$output	= trim(stripslashes($input));

	switch ($parsetype) {


		case "html":
			return strip_tags($output,$G_HTML);
		break;

		case "extrans":
			return nl2br(htmlspecialchars($output));
		break;

		case "text":
			return nl2br(strip_tags($output));
		break;

		case "auto":
		default:
			return nl2br(strip_tags($output,$G_HTML));
		break;

	}
}

function F_inLine($in) {
#	$out = eregi_replace("([ ]+)([[:alnum:]\.\-]+\@[[:alnum:]\-]+\.[\.[:alnum:]]+)([^\.[:alnum:]])","\\1<a href=\"mailto:\\2\">\\2</A>\\3", $in);
#	$out = eregi_replace("([ ]+)((http|https|ftp)\:\/\/[[:alnum:]\-]+\.[[:alnum:]\-]+[^[:space:]]*.)"," <a target=\"_blank\" href=\"\\2\">\\2</a>", $out);

	$out = ereg_replace("[A-Za-z]+://[^ <>\n]*[A-Za-z0-9/]", '<a href="\\0">\\0</a>', $in);
	$out = ereg_replace('[A-Za-z0-9]([A-Za-z0-9._]*[A-Za-z0-9]|())@[A-Za-z0-9]([A-Za-z0-9.\-]*[A-Za-z0-9]|())\.[A-Za-z]+','<a href="mailto:\\0">\\0</a>', $out);
	return $out;
}

?>
