<!DOCTYPE html 
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
	"DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta name="phpWebLog" content="<?php echo $G_VER; ?>" />
<meta name="Language" content="<?php echo $LANG; ?>" />
<meta name="Layout" content="<?php echo stripslashes($LAYOUT["Description"]); ?>" />
<meta name="LayoutVersion" content="<?php echo $LAYOUT["Version"]; ?>" />
<meta name="LayoutAuthor" content="<?php echo stripslashes($LAYOUT["Author"]); ?>" />
<meta http-equiv="Pragma" content="no-cache" />
<title><? echo stripslashes($CONF["SiteName"]) . " - " . stripslashes($CONF["SiteSlogan"]); ?></title>

<style type = "text/css">
	BODY {margin: -10px 0px 0px -10px; <?=$LAYOUT["GlobalStyle"]?>}
	TABLE, TD {<?=$LAYOUT["GlobalStyle"]?>}
	TH {text-align:left; <?=$LAYOUT["GlobalStyle"]?>}
	A {<?=$LAYOUT["LinkStyle"]?>}
	A:hover {color: <?=$LAYOUT["HoverColor"]?>; }
	A.nav {<?=$LAYOUT["NavStyle"]?>}
	A.title {<?=$LAYOUT["TitleStyle"]?>}
	span.text {<?=$LAYOUT["TextStyle"]?>}
	span.head {<?=$LAYOUT["HeadStyle"]?>}
	span.block {<?=$LAYOUT["BlockStyle"]?>}
	span.headhead {<?=$LAYOUT["BlockHeadStyle"]?>}
	.notice {<?=$LAYOUT["TextStyle"]?>}
	.small {font-size: smaller;}
</style>

<script	language = "javascript"
	type	= "text/javascript"
	src	= "<?=$G_URL?>/formcheck.inc.js">
</script>

</head>
<body bgcolor="<?=$LAYOUT["BgColor"]?>" background="<?=$LAYOUT["BgURL"]?>">

<?
	F_drawHeader();
?>

<!-- inside spread (3) -->
<table	border	= "0"
	cellspacing	= "0"
	cellpadding	= "0"
	align	= "center"
	width	= "<?=$LAYOUT["PageWidth"]?>">
<tr>
<td	colspan	= "3"
	align	= "center"><img 
	src	= "<?=$G_URL?>/images.d/speck.gif"
	width	= "1"
	alt		= ""
	height	= "<?=$LAYOUT["AreaPadding"]?>" /></td>
</tr>
<tr>

<?
	if (!$et = cache($G_CACHE, cache_default_object(), "LeftBlock")) {
		F_doBlocks("l");
		endcache();
	}
?>

<td width="100%" valign="top">

<?
	/*== display any messages ==*/
        if (!empty($msg)) { F_notice($msg); }
?>
<!-- end header.inc.php -->
