<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/


# Allowed HTML tags in stories, comma seperated
$G_HTML		= "<a>,<i>,<b>,<u>,<li>,<p>,<code>,<tt>,<blockquote>";

# Are we developing?
$G_DEBUG	= false;

# Number of seconds to hold cache
$G_CACHE	= 10;

# phpWebLog version
$G_VER		= "0.5.3";

/*== establish database connection ======================================*/

$err = "<h3>Unable to connect to database <u>$G_DB</u>.</h3> Make sure this database exists, then edit include/common.inc.php.";
$db	= @mysql_connect($G_HOST.":".$G_PORT,$G_USER,$G_PASS) or die($err);
@mysql_select_db($G_DB) or die($err);

/*== include libraries/functions =========================================*/

include_once("$G_PATH/include/func.inc.php");
include_once("$G_PATH/include/cache.inc.php");
include_once("$G_PATH/include/blocks.inc.php");
include_once("$G_PATH/include/layout.inc.php");
include_once("$G_PATH/include/parser.inc.php");
include_once("$G_PATH/include/search.inc.php");
include_once("$G_PATH/include/comments.inc.php");

/*== start the session ===================================================*/

session_start();
session_register("SESSION");
#unset($SESSION);
#session_destroy($SESSION);
if (!isset($SESSION)) $SESSION = array();

/*== read in configuration data =========================================*/

if (!$et=cache($G_CACHE,cache_default_object(),"Config")) {
	$sql	= "SELECT * FROM T_Config";
	$result	= @mysql_query($sql,$db);
	$nrows	= @mysql_num_rows($result);

	$CONF	= array();
	for ($i=0;$i<$nrows;$i++) {
		$A	= @mysql_fetch_array($result);
		$CONF[$A["Name"]] = $A["Value"];
	}
	cache_variable("CONF");
	endcache();
}

/*== read in content =====================================================*/

if (!$et=cache($G_CACHE,cache_default_object(),"Content")) {
	$sql	= "SELECT * FROM T_Content";
	$result	= @mysql_query($sql,$db);
	$nrows	= @mysql_num_rows($result);

	for ($i=0;$i<$nrows;$i++) {
		$A	= @mysql_fetch_array($result);
		$CONTENT[$A["Name"]] = $A["Value"];
	}
	cache_variable("CONTENT");
	endcache();
}

/*== include in language translation =====================================*/

$LANG	= !empty($CONF["Language"]) ? $CONF["Language"] : "english";
$lfile = $G_PATH . "/backend/language/" . $LANG . ".lng";
$err = "<h3>Unable to load language file</h3><u>$lfile</u> does not exist.<p>Check your paths in include/common.inc.php.";
if (file_exists($lfile)) {
	include_once($lfile);
} else {
	die($err);
}

/*== read in layout data =================================================*/

$THEME	= !empty($preview_layout) ? $preview_layout : $CONF["Layout"];
if (empty($THEME)) { $THEME = "shanked"; }
$LAYOUT	= import_layout($THEME);

/*== determine userinfo cookie name ======================================*/

$CNAME	= md5($CONF["SiteKey"] . "_userinfo");
$USER	= unserialize(stripslashes(rot13($HTTP_COOKIE_VARS["$CNAME"])));

/*== define supported user levels ========================================*/

$LEVELS = array(
					0	=> "Anonymous",
					1	=> "User",
					2 => "Moderator",
					3 => "Administrator"
				  );

/*== ensure that these are correct ==*/
set_magic_quotes_runtime(0);
ini_set(magic_quotes_gpc,1);


?>
