<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

  /* To use PHP in a section of phpWebLog, find the line that starts
   *     print $tmp;
   * and replace it with the text inside the comment
   *     eval("?>" . $tmp);
   * You will need to do this in each section where you want PHP enabled.
   * This could have security implications, so be sure that you only do
   * this for sections where the admin has complete control.  You are
   * strongly advised to not use this for comments.
   */

function F_drawStory($A,$where="") {
	global	$G_URL,$CONF,$G_PATH,$LAYOUT,$PHP_SELF;

	$author = F_author($A);
	$T		= F_getTopic($A["Topic"]);
	$T["Topic"]	= F_out($T["Topic"]);
	$topic	= sprintf("<a\thref\t=\"$G_URL/stories.php?topic=%s\">%s</a>",$A["Topic"],$T["Topic"]);
	if (!empty($T["ImgURL"])) {
		$icon	= sprintf("<a href=\"$G_URL/stories.php?topic=%s\">",$A["Topic"]);
		$icon	.= "<img\talign\t= \"right\"\n";
		$icon	.= "\tsrc\t= \"" . $T["ImgURL"] . "\"\n";
		$icon	.= "\tborder\t= \"0\"\n";
		$icon	.= "\talt=\"" . $T["AltTag"] . "\" /></a>\n";
	}
	$date		= F_dateFormat($A["Birthstamp"]);
	
	$article_parts = spliti("<([ ]*)page([ ]*)>",$A["Content"]);
	$part_cnt = count($article_parts);
	if ($part_cnt > 1 && $CONF["SplitPages"]>0 && basename($PHP_SELF)!="print.php") {
		if (empty($A["mpage"])) {
			$mpage = 1;
		} else {
			$mpage = $A["mpage"];
		}
		$article 	= $article_parts[($mpage - 1)];
		$part_nav 	= _PAGES . ": ";
		if ($mpage > 1) {
			for ($i = 1; $i < $mpage; $i++) {
				$part_nav .= "<a href=\"$G_URL/stories.php?story=".$A["Rid"]."&amp;mpage=$i\">$i</a> ";
			}
		}
		$part_nav .= "<b>$mpage</b> ";
		if ($mpage < $part_cnt) {
			for ($i = $mpage + 1; $i <= $part_cnt; $i++) {
				$part_nav .= "<a href=\"$G_URL/stories.php?story=".$A["Rid"]."&amp;mpage=$i\">$i</a> ";
			}
		}
	} else {
		$article	= ereg_replace("<([ ]*)page([ ]*)>","",$A["Content"]);
	}
		
	$link		= F_getIndexes($A["Rid"]);
	$links	= $link;
	if ($CONF["ShowHits"]) $views    = _VIEWS . " " . $A["Hits"];  
	$content 	= F_parseContent($article,$A["ParseType"]);
	$content	.= "<br /><span style=\"text-align:center;\">$part_nav</span>";
	if ($A["Repostamp"]>$A["Birthstamp"]) {
		$content	.= "<br /><i>" . _REPOSTED . " " . F_dateFormat($A["Repostamp"]) . "</i>";
	}
	if (basename($PHP_SELF)!="print.php" && basename($PHP_SELF)!="preview.php") {
		$content	.= "<br />\n" . F_admin("T_Stories",$A["Rid"],$where);
	}
	$heading	= "<span style=\"{$LAYOUT["TitleStyle"]}\">" . F_out($A["Heading"]) . "</span>\n";
	$content	= "<span style=\"{$LAYOUT["TextStyle"]}\">" . $content . "</span>\n";

	if ($CONF["ShowIP"]) $address    = "(" . F_fixHost($A["Host"]) . ")";
	$templatefile	= "$G_PATH/backend/template/" . $LAYOUT["TMPL_Story"] . "/story.tmpl";
	$imagedir	= "$G_URL/backend/template/" . $LAYOUT["TMPL_Story"] . "/images";

	$templ_arr	= @file($templatefile);
	$template	= @implode("", $templ_arr);
	$template = addslashes($template);
	$template	= "\$tmp=\"".$template."\";";
	eval($template);
	print "\n<!-- STORY START " . $LAYOUT["TMPL_Story"] . " -->\n";
	print $tmp;	/* eval("?>" . $tmp); */
	print "\n<!-- STORY END -->\n";
	if (basename($PHP_SELF)!="moderate.php"
			&& basename($PHP_SELF)!="print.php"
			&& basename($PHP_SELF)!="preview.php") {
		F_notice(F_NP_Story($A["Repostamp"]));
	}
}

function F_drawSummary($A,$where="") {
	global	$G_URL,$CONF,$G_PATH,$LAYOUT;
	$author		= F_author($A);
	$T			= F_getTopic($A["Topic"]);
	$T["Topic"]	= F_out($T["Topic"]);
	$topic		= sprintf("<a href=\"$G_URL/stories.php?topic=%s\">%s</a>",$A["Topic"],$T["Topic"]);
	if (!empty($T["ImgURL"])) {
		$icon	= sprintf("<a href=\"$G_URL/stories.php?topic=%s\">",$A["Topic"]);
		$icon	.= "<img\talign\t= \"right\"\n";
		$icon	.= "\tsrc\t= \"" . $T["ImgURL"] . "\"\n";
		$icon	.= "\tborder\t= \"0\"\n";
		$icon	.= "\talt=\"" . $T["AltTag"] . "\" /></a>\n";
	}
	$date		= F_dateFormat($A["Birthstamp"]);

	$content 	= F_parseContent($A["Summary"],$A["ParseType"]);
	/*== append [...] if summary != story ==*/
	if ($CONF["SummaryLength"]>0 && $A["Summary"] != $A["Content"]) {
		$content	.= sprintf(" <a href=\"%s/stories.php?story=%s\">[...]</a>",$G_URL,$A["Rid"]);
	}
	if ($A["Repostamp"]>$A["Birthstamp"]) {
		$content	.= "<br /><i>" . _REPOSTED . " " . F_dateFormat($A["Repostamp"]) . "</i>";
	}
	$heading	= sprintf("<a style=\"{$LAYOUT["TitleStyle"]}\" href=\"%s\">%s</a>\n",F_story($A["Rid"]),F_out($A["Heading"]));
	$content	= "<span style=\"{$LAYOUT["TextStyle"]}\">" . $content . "</span>\n";
	$content	.= "<br />\n" . F_admin("T_Stories",$A["Rid"],$where);

	$link		= F_getIndexes($A["Rid"]);
	$links	= $link;
	if ($CONF["ShowIP"]) $address    = "(" . F_fixHost($A["Host"]) . ")";

	$ncmts		= F_count("T_Comments","TopRid",$A["Rid"]);
	$vcmts		= $ncmts > 1 ? _COMMENTS : _COMMENT;
	if ($ncmts>0) {
		$tmp	= "(" . $ncmts . " " . $vcmts . ")";
	} elseif ($A["NoComments"]==0) {
		$tmp	= "-- " . _COMMENT;
	} else {
		$tmp	= "";
	}
	if (($CONF["Comments"]>0) && ($A["NoComments"]!=1)) {
		$comments	= sprintf("<a href=\"%s/stories.php?story=%s\">" . _READMORE . " %s</a>\n",$G_URL,$A["Rid"],$tmp);
	} else {
		$comments	= sprintf("<a href=\"%s/stories.php?story=%s\">" . _READMORE . "</a>\n",$G_URL,$A["Rid"]);
	}
	$modified	= F_lastModified($A["Rid"]);
	if ($CONF["ShowHits"]) $views		= _VIEWS . " " . $A["Hits"];
	$templatefile	= "$G_PATH/backend/template/" . $LAYOUT["TMPL_Summary"] . "/summary.tmpl";
	$imagedir	= "$G_URL/backend/template/" . $LAYOUT["TMPL_Summary"] . "/images";

	$templ_arr	= @file($templatefile);
	$template	= @implode("", $templ_arr);
	$template = addslashes($template);
	$template	= "\$tmp=\"".$template."\";";
	eval($template);
	print "\n<!-- SUMMARY START " . $LAYOUT["TMPL_Summary"] . " -->\n";
	print $tmp;	/* eval("?>" . $tmp); */
	print "\n<!-- SUMMARY END -->\n";
}

function F_drawBlock($A) {
	global	$G_URL,$G_PATH,$LAYOUT,$PHP_SELF;
	if ($A["Display"]=="l") {
		$baz	= $LAYOUT["TMPL_LeftBlock"];
	} elseif ($A["Display"]=="r") {
		$baz	= $LAYOUT["TMPL_RightBlock"];
	} else {
		if ($LAYOUT["BlocksAlign"]=="right") {
			$baz	= $LAYOUT["TMPL_RightBlock"];
		} else {
			$baz	= $LAYOUT["TMPL_LeftBlock"];
		}
	}
	$heading	= "<span style=\"{$LAYOUT["BlockHeadStyle"]}\">" . F_out($A["Heading"]) . "</span>\n";
	$content	= "<span style=\"{$LAYOUT["BlockStyle"]}\">" . F_out(F_getBlock($A)) . "</span>\n";

	$date		= F_dateFormat($A["Birthstamp"]);
	$templatefile	= "$G_PATH/backend/template/" . $baz . "/block.tmpl";
	$imagedir	= "$G_URL/backend/template/" . $baz . "/images";

	$template	= implode("", file($templatefile));
	$template = addslashes($template);
	$template	= "\$tmp=\"".$template."\";";
	eval($template);
	print "\n<!-- BLOCK START " . $baz . " -->\n";
	print $tmp;	/* eval("?>" . $tmp); */
	print "\n<!-- BLOCK END -->\n";
}

function F_drawMain($A) {
	global	$G_PATH,$LAYOUT,$G_URL;
	$heading	= "<span style=\"{$LAYOUT["HeadStyle"]}\">" . F_out($A["Heading"]) . "</span>\n";
	$content	= "<div style=\"{$LAYOUT["TextStyle"]}\">" . F_out($A["Content"]) . "</div>\n";
	$templatefile	= "$G_PATH/backend/template/" . $LAYOUT["TMPL_Main"] . "/main.tmpl";
	$imagedir	= "$G_URL/backend/template/" . $LAYOUT["TMPL_Main"] . "/images";

	$templ_arr	= @file($templatefile);
	$template	= @implode("", $templ_arr);
	$template = addslashes($template);
	$template	= "\$tmp=\"".$template."\";";
	eval($template);
	print "\n<!-- MAIN START " . $LAYOUT["TMPL_Main"] . " -->\n";
	print $tmp;	/* eval("?>" . $tmp); */
	print "\n<!-- MAIN END -->\n";
}

function F_drawHeader() {
	global	$G_PATH,$G_URL,$G_DATE,$CONF,$LAYOUT,$db;
	if (!empty($LAYOUT["LogoURL"])) {
		$logo	= "<a\thref\t= \"" . $G_URL . "/\"><img\n";
		$logo	.= "\talt\t= \"" . $CONF["SiteName"] . " - " . $CONF["SiteSlogan"] . "\"\n";
		$logo	.= "\tsrc\t= \"" . $LAYOUT["LogoURL"] . "\"\n";
		$logo	.= "\tborder\t= \"0\" /></a>\n";
	} else {
		$logo	= "<h1>" . $CONF["SiteName"] . "</h1>\n";
	}
	$siteslogan	= F_out($CONF["SiteSlogan"]);

	$searchbox	= "<form\taction\t= \"" . $G_URL . "/search.php\"\n";
	$searchbox	.= "\tmethod\t= \"get\">\n";
	$searchbox	.= _FIND . "\n";
	$searchbox	.= "<input\ttype\t= \"text\"\n";
	$searchbox	.= "\tsize\t= \"15\"\n";
	$searchbox	.= "\tname\t= \"query\" />\n";
	$searchbox	.= "</form>\n";

	$date		= strftime($G_DATE,time());
	/*== CONSTRUCT NAVIGATION BAR ==*/
	# news index
	$navigation	= "<a class=\"nav\" href = \"" . $G_URL . "/stories.php\">" . _INDEX . "</a>\n";
	# search
	$navigation .= " | ";
	$navigation .= "<a class=\"nav\" href = \"" . $G_URL . "/search.php\">" . _SEARCH . "</a>\n";
	# if archive is enabled
	if ($CONF["Archive"]>0) {
		$navigation .= " | ";
		$navigation .= "<a class=\"nav\" href = \"" . $G_URL . "/archive.php\">" . _ARCHIVE . "</a>\n";
	}
	# contribute news
	if ($CONF["AllowContrib"]>0) {
		$navigation	.= " | ";
		$navigation	.= "<a class=\"nav\" href = \"" . $G_URL . "/contrib.php\">" . _CONTRIB . "</a>\n";
	}
	# list all pages
	$sql	= "SELECT Rid,Title from T_Pages ";
	$sql	.= "WHERE Display = 'p'";
	$result	= @mysql_query($sql,$db);
	if ($result) {
		while (list($rid,$title) = mysql_fetch_row($result)) {
			$navigation	.= "|" . " <a class=\"nav\" href = \"" . $G_URL . "/pages.php?node=" . 
				$rid . "\">" . F_out($title) . "</a>\n";
		}
	}
	# if stats are enabled
	if ($CONF["SiteStats"]>0) {
		$navigation .= " | ";
		$navigation .= "<a class=\"nav\" href = \"" . $G_URL . "/stats.php\">" . _STATS . "</a>\n";
	}
	# contact
	$navigation .= " | ";
	$navigation .= "<a class=\"nav\" href\t= \"" . $G_URL . "/profiles.php?Author=" . urlencode($CONF["SiteOwner"]) . 
		"&amp;uthorEmail=" . rot13($CONF["EmailAddress"]) . 
		"&amp;AuthorURL=" . $G_URL . "\">" . _CONTACT . "</a>\n";

	$templatefile	= "$G_PATH/backend/template/" . $LAYOUT["TMPL_Header"] . "/header.tmpl";
	$imagedir	= "$G_URL/backend/template/" . $LAYOUT["TMPL_Header"] . "/images";

	$templ_arr	= @file($templatefile);
	$template	= @implode("", $templ_arr);
	$template = addslashes($template);
	$template	= "\$tmp=\"".$template."\";";
	eval($template);
	print "\n<!-- HEADER START " . $LAYOUT["TMPL_Header"] . " -->\n";
	print $tmp;	/* eval("?>" . $tmp); */
	print "\n<!-- HEADER END -->\n";
}

function F_drawFooter() {
	global	$G_PATH,$CONF,$LAYOUT,$G_URL,$CONTENT,$G_DEBUG,$SESSION;
	$sitename	= F_out($CONF["SiteName"]);
	$siteslogan	= F_out($CONF["SiteSlogan"]);
	$content	= F_out($CONTENT["Footer"]);
	$templatefile	= "$G_PATH/backend/template/" . $LAYOUT["TMPL_Footer"] . "/footer.tmpl";
	$imagedir	= "$G_URL/backend/template/" . $LAYOUT["TMPL_Footer"] . "/images";

	$templ_arr	= @file($templatefile);
	$template	= @implode("", $templ_arr);
	$template = addslashes($template);
	$template	= "\$tmp=\"".$template."\";";
	eval($template);
	print "\n<!-- FOOTER START " . $LAYOUT["TMPL_Footer"] . " -->\n";
	print $tmp;	/* eval("?>" . $tmp); */
	print "\n<!-- FOOTER END -->\n";
	if ($G_DEBUG) {
		print "<big><pre>\n";
		var_dump($SESSION);
		print "</pre></big>\n";
	}
}

function F_drawComment($A,$where) {
	global	$G_PATH,$G_URL,$CONF,$LAYOUT;
	if ($A["Author"]=="Anonymous" && $CONF["AllowAnon"]>0) {
		$author	= F_out($A["Author"]);
	} else {
		$author	= sprintf("<a href = \"%s/profiles.php?Author=%s&amp;AuthorEmail=%s&amp;AuthorURL=%s\">%s</a>",
			$G_URL,
			urlencode(F_out($A["Author"])),
			rot13(F_out($A["AuthorEmail"])),
			urlencode(F_out($A["AuthorURL"])),
			F_out($A["Author"]));
	}
	$address    = "(" . F_fixHost($A["Host"]) . ")";
	$content		= $A["Content"];
	$date       = F_dateFormat($A["Birthstamp"]);
	if ($CONF["Comments"]==2) {
		$reply		= "[ <a \tonclick\t= \"JS_makeParent('" . $A["Rid"] . "')\" ";
		$reply		.= "\thref=\"#comments\">" . _REPLY . "</a>";
		$reply		.= " | ";
		$reply		.= "<a \tonclick\t= \"JS_makeParent('" . $A["ParentRid"] . "')\" ";
		$reply		.= "\thref=\"#comments\">" . _PARENT . "</a> ]";
	}
	$templatefile	= "$G_PATH/backend/template/" . $LAYOUT["TMPL_Comment"] . "/comment.tmpl";
	$imagedir	= "$G_URL/backend/template/" . $LAYOUT["TMPL_Comment"] . "/images";

	$templ_arr	= @file($templatefile);
	$template	= @implode("", $templ_arr);
	$template = addslashes($template);
	$template	= "\$tmp=\"".$template."\";";
	eval($template);
	print "\n<!-- COMMENT START " . $LAYOUT["TMPL_Comment"] . " -->\n";
	print "<a name=\"". $A["Rid"] ."\" />\n";
	print $tmp;
	print "\n<!-- COMMENT END -->\n";
}

function export_layout($array) {
	global	$db,$G_URL,$G_PATH,$G_VER,$CONF;
	$outputfile	= $G_PATH . "/backend/layouts/" . $array["Layout"] . ".xlay";

	if (!$file=fopen($outputfile,"w")) {
		F_error("Unable to write to $outputfile\n");
	} else {
		fputs ($file, "<?xml version=\"1.0\"?>\n\n");
		fputs ($file, "<layout>\n\n");
		fputs ($file, "<info>\n");
		fputs ($file, "<author>$array[Author]</author>\n");
		fputs ($file, "<description>$array[Description]</description>\n");
		fputs ($file, "<version>$G_VER</version>\n");
		fputs ($file, "</info>\n\n");

		for (reset($array);$k=key($array);next($array)) {
			if (substr($k,0,5)=="XLAY_") {
				$tmp	= substr($k,5);
				fputs ($file, "<item>\n");
				$element = "<element>" . $tmp . "</element>\n";
				$value  = "<value>" . $array[$k] . "</value>\n";
				fputs ($file, $element);
				fputs ($file, $value);
				fputs ($file, "</item>\n\n");
			}
		}
	}
	fputs ( $file, "</layout>\n");
	fclose( $file );
}

function import_layout($layout) {
	global	$G_PATH;
	$filename	= $G_PATH . "/backend/layouts/" . $layout . ".xlay";
	$fpread = fopen($filename,"r");
	if(!$fpread) {
		F_error("Unable to read layout file $filename<br />\n");
	} else {
		#echo "<p>Reading file: $filename<br />";
		$XLAY	= array();
		while(!feof($fpread) ) {
			$buffer 	= ltrim(chop(fgets($fpread, 256)));
			if ($buffer == "<info>") {
				$author	= ltrim(chop(fgets($fpread, 256)));
				$author = ereg_replace( "<author>", "",$author);
				$author = ereg_replace( "</author>", "",$author);
				$XLAY["Author"] = $author;
				$desc	= ltrim(chop(fgets($fpread, 256)));
				$desc = ereg_replace( "<description>", "",$desc);
				$desc = ereg_replace( "</description>", "",$desc);
				$XLAY["Description"] = $desc;
				$version = ltrim(chop(fgets($fpread, 256)));
				$version = ereg_replace( "<version>", "",$version);
				$version = ereg_replace( "</version>", "",$version);
				$XLAY["Version"] = $version;
			} elseif ($buffer == "<item>") {
				$element = ltrim(chop(fgets($fpread, 256)));
				$value	= ltrim(chop(fgets($fpread, 256)));

				$element = ereg_replace( "<element>", "",$element);
				$element = ereg_replace( "</element>", "",$element);
				$value = ereg_replace( "<value>", "",$value);
				$value = ereg_replace( "</value>", "",$value);
				$XLAY[$element] = $value;
			}
		}
		fclose($fpread);
	}
	return $XLAY;
}

?>
