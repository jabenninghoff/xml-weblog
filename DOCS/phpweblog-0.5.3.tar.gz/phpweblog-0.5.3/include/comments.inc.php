<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

function F_doComments($rid,$toprid,$where,$reply=0) {
	global	$CONF,$LAYOUT,$db,$G_URL;
	if ($CONF["Comments"]>0) {
		/*== followed by user comments ==*/
		$sql	= "SELECT * FROM T_Comments ";
		$sql	.= "WHERE ParentRid = '$rid' ";
		$sql	.= sprintf("ORDER By Birthstamp %s",$CONF["CommentSort"]);
		$result	= mysql_query($sql,$db);
		$nrows	= mysql_num_rows($result);

		if ($nrows>0) {
			for ($i=0;$i<$nrows;$i++) {	
				$A	= mysql_fetch_array($result);
				$A["Content"] = F_parseContent($A["Content"],$A["ParseType"]);
				$A["Content"] .= F_admin("T_Comments",$A["Rid"],urlencode($where));
				if ($reply>0) {
					$tmp	= $reply * 25;
					print "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\n";
					print "<tr><td width=\"" . $tmp . "\"><img\n";
					print "\tsrc\t= \"" . $G_URL . "/images.d/speck.gif\" height=\"1\"\n";
					print "\twidth\t= \"" . $tmp . "\" alt=\"\" /></td>\n<td>\n";
				}
				F_drawComment($A,$where);
				if ($reply>0) {
					print "</td></tr></table>\n";
				}
				if ($CONF["Comments"]==2) {
					$sql	= "SELECT * from T_Comments ";
					$sql	.= "WHERE ParentRid = '" . $A["Rid"] . "' ";
					$sql    .= "AND TopRid = '" . $toprid . "' ";
					$sql	.= sprintf("ORDER By Birthstamp %s",$CONF["CommentSort"]);
					$tresult	= mysql_query($sql,$db);
					$tnrows	= mysql_num_rows($tresult);
					if ($tnrows>0) {
						$tmp	= $reply + 1;
						F_doComments($A["Rid"],$toprid,$where,$tmp);
					}
				}
			}
		} else {
			F_notice(_NOCOMMENTS);
		}
	}
}


function F_postComment($parentrid,$toprid,$where) {
	global	$CONF,$HTTP_COOKIE_VARS,$G_URL,$USER,$SESSION;
	if ($CONF["Comments"]>0) {
		$VAR["Heading"] = "<a \tname\t= \"comments\"> </a>";
		$VAR["Heading"] .= _POSTCOMMENT;
		if ($CONF["AuthPostOnly"] == 1 && F_getLevel() < 1) {
			$VAR["Content"] = "You need to be logged in to post comments. Please <a href=\"$G_URL/login.php\">login</a> or <a href=\"$G_URL/signup.php\">signup</a>.";
		} elseif ($CONF["AuthPostOnly"] == 2 && $CONF["AllowAnon"] < 1 && F_getLevel() < 1) {
			$VAR["Content"] = "You need to be logged in to post comments. Please <a href=\"$G_URL/login.php\">login</a> or <a href=\"$G_URL/signup.php\">signup</a>.";
		} else {
			if ($CONF["AuthPostOnly"] == 2 && F_getLevel() < 1) {
				$Username = "Anonymous";
				$Email = "Anonymous";
				$URL = "";
				$InputType = "Lock";
				$Anon = "Force";
			} elseif ($CONF["AuthPostOnly"] == 0 && F_getLevel() < 1) {
				$Username = $USER["AuthorName"];
				$Email = $USER["AuthorEmail"];
				$URL = $USER["AuthorURL"];
				$InputType = "Free";
				$Anon = "Yes";
			} else {
				$UserDetails = F_getUserInfo($SESSION["USER"]["Username"],1);
				if ($CONF["UsersPostAs"] == 1) {
					$Username = $UserDetails["Username"];
					$InputType = "Lock";
				} elseif ($CONF["UsersPostAs"] == 2) {
					$Username = $UserDetails["RealName"];
					$InputType = "Free";
				} elseif ($CONF["UsersPostAs"] == 3) {
					$Username[0] = $UserDetails["Username"];
					$Username[1] = $UserDetails["RealName"];
					$InputType = "Select";
				} else {
					$Username = $UserDetails["Username"];
					$InputType = "Free";
				}
			
				$Email = $UserDetails["EmailAddress"];
				$URL = $UserDetails["URL"];
				$Anon = "Yes";
			}
			if ($InputType == "Lock") {
				$comm_author = "<input\n";
				$comm_author .= "\ttype\t= \"hidden\"\n";
				$comm_author .= "\tname\t= \"Author\"\n";
				$comm_author .= "\tvalue\t= \"$Username\">$Username\n";

				$comm_email = "<input\n";
				$comm_email .= "\ttype\t= \"hidden\"\n";
				$comm_email .= "\tname\t= \"Author\"\n";
				$comm_email .= "\tvalue\t= \"$Email\">$Email\n";

				$comm_url = "<input\n";
				$comm_url .= "\ttype\t= \"hidden\"\n";
				$comm_url .= "\tname\t= \"URL\"\n";
				$comm_url .= "\tvalue\t= \"$URL\">$URL\n";
			} elseif ($InputType == "Select") {
				$comm_author = "<select\n";
				$comm_author .= "\tname\t= \"Author\">\n";
				$comm_author .= "<option name = \"$Username[0]\">$Username[0]</option>\n";
				$comm_author .= "<option name = \"$Username[1]\">$Username[1]</option>\n";
				$comm_author .= "</select>";
				
				$comm_email = "<input\n";
				$comm_email .= "\ttype\t= \"hidden\"\n";
				$comm_email .= "\tname\t= \"Author\"\n";
				$comm_email .= "\tvalue\t= \"$Email\">$Email\n";

				$comm_url = "<input\n";
				$comm_url .= "\ttype\t= \"hidden\"\n";
				$comm_url .= "\tname\t= \"URL\"\n";
				$comm_url .= "\tvalue\t= \"$URL\">$URL\n";

			} else {
				$comm_author .= "<input\n";
				$comm_author .= "\ttype\t= \"text\"\n";
				$comm_author .= "\tname\t= \"Author\"\n";
				$comm_author .= "size\t= \"32\"\n";
				$comm_author .= "\tvalue\t= \"$Username\"\n";
				$comm_author .= "\tmaxlength\t= \"32\" />\n";
				
				$comm_email .= "<input\ttype\t= \"text\"\n";
				$comm_email .= "\tname\t= \"AuthorEmail\"\n";
				$comm_email .= "\tsize\t= \"32\"\n";
				$comm_email .= "\tvalue\t= \"$Email\"\n";
				$comm_email .= "\tmaxlength\t= \"96\" />\n";

				$comm_url .= "<input\ttype\t= \"text\"\n";
				$comm_url .= "\tname\t= \"AuthorURL\"\n";
				$comm_url .= "\tsize\t= \"32\"\n";
				$comm_url .= "\tvalue\t= \"$URL\"\n";
				$comm_url .= "\tmaxlength\t= \"96\" />\n";
			}

		
			$VAR["Content"] = "<form\taction\t= \"$G_URL/submit.php\"\n";
			$VAR["Content"] .= "\tmethod\t= \"post\"\n";
			$VAR["Content"] .= "\tname\t= \"Com\"\n";
			$VAR["Content"] .= "\tonsubmit= \"return validateComment()\">\n";
			$VAR["Content"] .= "<table\n";
			$VAR["Content"] .= "\tcellspacing\t= \"0\"\n";
			$VAR["Content"] .= "\tcellpadding\t= \"1\"\n";
			$VAR["Content"] .= "\tborder\t= \"0\">\n";
			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>" . _NAME . ":</td>\n";
			$VAR["Content"] .= "<td>$comm_author</td>\n</tr>\n";
			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>" . _EMAIL . ":</td>\n";
			$VAR["Content"] .= "<td>$comm_email</td>\n</tr>\n";
			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td>" . _URL . ":</td>\n";
			$VAR["Content"] .= "<td>$comm_url</td>\n</tr>\n";
			

			if ($CONF["SaveInfo"]>0 && F_getLevel() < 1 && $CONF["AuthPostOnly"] != 2) {
				$VAR["Content"] .= "<tr>\n";
				$VAR["Content"] .= "<td>&nbsp;</td>\n";
				$VAR["Content"] .= "<td>\n";
				$VAR["Content"] .= "<input\ttype\t= \"checkbox\"\n";
				$VAR["Content"] .= "\tname\t= \"save\" />\n";
				$VAR["Content"] .= _SAVEINFO . "</td>\n";
				$VAR["Content"] .= "</tr>\n";
			}
			if ($CONF["AllowAnon"]>0 && $Anon == "Yes") {
				$VAR["Content"] .= "<tr>\n";
				$VAR["Content"] .= "<td>&nbsp;</td>\n";
				$VAR["Content"] .= "<td>\n";
				$VAR["Content"] .= "<input\ttype\t= \"checkbox\"\n";
				$VAR["Content"] .= "name\t= \"anon\" />\n";
				$VAR["Content"] .= _ANONYMOUS . "</td>\n";
				$VAR["Content"] .= "</tr>\n";
			} elseif ($Anon == "Force") {
				$VAR["Content"] .= "<input\ttype\t= \"hidden\"\n";
				$VAR["Content"] .= "name\t=\"anon\"\n";
				$VAR["Content"] .= "value\t=\"On\" />\n";
			}
			$VAR["Content"] .= "<tr>\n";
			$VAR["Content"] .= "<td colspan=\"2\">" . ucfirst(_COMMENT) . ":<br />\n";
			$VAR["Content"] .= "<textarea\n";
			$VAR["Content"] .= "\tname\t= \"Content\"\n";
			$VAR["Content"] .= "\trows\t= \"10\"\n";
			$VAR["Content"] .= "\tcols\t= \"50\"></textarea></td></tr>\n";
	
			$VAR["Content"] .= "<tr><td colspan=\"2\"><small>";
			$VAR["Content"]	.= _NOPUBLIC;
			$VAR["Content"]	.= "</small></td>\n";
			$VAR["Content"] .= "</tr>\n";

			$VAR["Content"]	.= "<tr><td colspan=\"2\">" . _SAVEAS;
			$VAR["Content"] .= "<select name=\"ParseType\">\n";
			$VAR["Content"] .= "<option value=\"auto\">" . _AUTOMATIC . "</option>\n";
			$VAR["Content"] .= "<option value=\"html\">" . _HTML . "</option>\n";
			$VAR["Content"] .= "<option value=\"extrans\">" . _EXTRANS . "</option>\n";
			$VAR["Content"] .= "<option value=\"text\">" . _TEXT . "</option>\n";
			$VAR["Content"] .= "</select>\n";

			$VAR["Content"] .= "<input\ttype\t= \"hidden\"\n";
			$VAR["Content"] .= "\tname\t= \"what\"\n";
			$VAR["Content"] .= "\tvalue\t= \"comment\" />\n";
			$VAR["Content"] .= "<input\ttype\t= \"hidden\"\n";
			$VAR["Content"] .= "\tname\t= \"ParentRid\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$parentrid\" />\n";
			$VAR["Content"] .= "<input\ttype\t= \"hidden\"\n";
			$VAR["Content"] .= "\tname\t= \"TopRid\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$toprid\" />\n";
			$VAR["Content"] .= "<input\ttype\t= \"hidden\"\n";
			$VAR["Content"] .= "\tname\t= \"where\"\n";
			$VAR["Content"] .= "\tvalue\t= \"$where\" />\n";
			$VAR["Content"] .= "<input\ttype\t= \"submit\"\n";
			$VAR["Content"] .= "\tvalue\t= \"" . F_submit() . "\" />\n";
			$VAR["Content"] .= "</td>\n</tr>\n";
			$VAR["Content"] .= "</table>\n";
			$VAR["Content"] .= "</form>\n";
		}
		F_drawMain($VAR);
	}
}

?>
