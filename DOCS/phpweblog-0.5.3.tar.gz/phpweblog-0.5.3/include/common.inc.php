<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

/*== DATABASE CONFIGURATION ==*/
$G_DB   = "PHPWEBLOG";      # database name
$G_HOST = "localhost";      # hostname
$G_PORT = "3306";           # port
$G_USER = "root";           # username
$G_PASS = "";               # password


/*== SETUP / INSTALLATION PASSWORD ==*/
/*== YOU WANT TO CHANGE THIS TO SOMETHING UNIQUELY PRIVATE! ==*/

$SETUP_PW	= "phpweblog";			# setup password


/*== DIRECTORY PATHS (no trailing slashes) ==*/
$G_PATH = "/path/to/phpweblog";		// full directory path

$G_URL	= "http://www.yourdomain.com";


/*== END CONFIGURATION ==*/

include_once("$G_PATH/include/init.inc.php");
?>
