<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

function F_doBlocks($align) {
	global	$G_URL,$LAYOUT,$CONF,$db,$HTTP_COOKIE_VARS,$story;
	global	$PHP_SELF,$topic,$REQUEST_URI,$G_PATH,$LANG;

	$cnt	= 0;

	# fetch all user-defined blocks
	$sql	= "SELECT *,UNIX_TIMESTAMP(Timestamp) AS Timestamp,";
	$sql	.= "UNIX_TIMESTAMP(Birthstamp) As Birthstamp ";
	$sql	.= "FROM T_Blocks ";
	$sql	.= "WHERE Display = '$align' ";
	$sql	.= "ORDER BY OrderID";
	$blocks_result	= @mysql_query($sql,$db);
	$blocks_nrows	= @mysql_num_rows($blocks_result);
	#echo "<!-- SQL: $sql -- Rows: $blocks_nrows -->";

	# if there are no blocks in this column or if it's an admin block, and
	# user is not admin, return nothing so that column will not print.
	$row	= @mysql_fetch_assoc($blocks_result);
	if ($row) mysql_data_seek($blocks_result,0);
	if ($blocks_nrows==0) {
		return;
	} elseif (is_long(strpos($row["URL"],"admin")) && !F_isLevel(3) && $blocks_nrows==1) {
		return;
	}

	# determine column width from layout
	$width	= $align=="r" ? $LAYOUT["RightBlocksWidth"] : $LAYOUT["LeftBlocksWidth"];

	print "<!-- begin blocks column ($align) //-->\n";
	if ($align=="r") {
		print "<td><img\n";
		print "\tsrc\t= \"" . $G_URL . "/images.d/speck.gif\"\n";
		print "\theight\t= \"1\" alt=\"\"\n";
		print "\twidth\t= \"" . $LAYOUT["AreaPadding"] . "\" /></td>\n";
	}
	print "<td\tvalign\t= \"top\"\n";
	print "\twidth\t= \"" . $width . "\">\n";


	# load in the blocks
	while ($A = mysql_fetch_array($blocks_result)) {
		if ($A["Type"] == 3) {
			# system/addon block
			$VAR["Rid"] = $A["Rid"];
			$VAR["OrderID"] = $A["OrderID"];
			$VAR["Display"] = $A["Display"];
			$VAR["Heading"]	= $A["Heading"];

			# prepare addon paths
			$URL  = $G_URL ."/" . strstr($A["URL"],"backend/addons/");
			define("URL",$URL);

			$PATH = $G_PATH ."/" . strstr($A["URL"],"backend/addons/");
			$suf = strstr($PATH,"blocks/");
			$PATH = substr($PATH, 0, strpos($PATH, $suf));
			define("PATH",$PATH);

			if (!empty($PATH)) {
				$sql	= "SELECT Rid FROM T_Pages ";
				$sql	.= "WHERE URL = '$PATH'";
				$res	= @mysql_query($sql,$db);
				$tmp	= mysql_fetch_array($res);
				$SELF = $G_URL . "/pages.php?node=" . $tmp["Rid"];
				define("SELF",$SELF);
			}

			$tmp  = $PATH . "/language/" . $LANG . ".lng";
			if (file_exists($tmp)) {
				include_once($tmp);
			}
			if (file_exists($A["URL"])) {
				include_once($A["URL"]);
			}
		} else {
			# non-system block, simply draw it
			$A["Content"] .= "<br />\n" . F_admin("T_Blocks",$A["Rid"],"stories.php") . F_shiftBlocks($A["Rid"],$A["OrderID"],$align);
			F_drawBlock($A);
		}
	}


	print "<img\tsrc\t= \"" . $G_URL . "/images.d/speck.gif\"\n";
	print "\twidth\t= \"" . $width . "\"\talt=\"\"\n";
	print "\theight\t= \"1\" /></td>\n";
	if ($align=="l") {
		print "<td><img\n";
		print "\tsrc\t= \"" . $G_URL . "/images.d/speck.gif\"\n";
		print "\theight\t= \"1\"\talt=\"\"\n";
		print "\twidth\t= \"" . $LAYOUT["AreaPadding"] . "\" /></td>\n";
	}
	print "<!-- end blocks column ($align) //-->\n";

}

?>
