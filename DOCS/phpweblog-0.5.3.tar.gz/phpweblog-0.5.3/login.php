<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/
include("include/common.inc.php");

/* check for passwd */
if (F_loginUser($Username,$Password) && F_matchOK()) {

	$SESSION["USER"] = F_getUserInfo($Username);
	F_logAccess("\"" . $SESSION["USER"]["Username"] . "\" logged in. Level ". F_getLevel());

	header("Location: stories.php");
} elseif (F_getLevel() > 0) {
	include($G_PATH . "/include/header.inc.php");
	$VAR["Heading"] = "User Login";
	$VAR["Content"] = "You are currently logged in as <b>";
	$VAR["Content"] .= $SESSION["USER"]["Username"];
	$VAR["Content"] .= "</b>. You must <a href=\"$G_URL/admin/logout.php\">logout</a> before you can login again.<br />";
	F_drawMain($VAR);
	include($G_PATH . "/include/footer.inc.php");
	exit();

} else {

	include($G_PATH . "/include/header.inc.php");
	if (!empty($warn)) {
		F_notice("Invalid login.");
		F_logAccess("Failed login - user:\"$Username\" pass:\"$Password\"");
	}
	$VAR["Heading"] = "User Login";
	$VAR["Content"] = "<form \taction\t=\t\"$PHP_SELF\"\n";
	$VAR["Content"] .= "\tname\t= AUTH\n";
	$VAR["Content"] .= "\tmethod\t= POST>\n";
	$VAR["Content"] .= "Username:\n";
	$VAR["Content"] .= "<input\ttype\t= text\n";
	$VAR["Content"] .= "\tname\t= Username\n";
	$VAR["Content"] .= "\tsize\t= 16\n";
	$VAR["Content"] .= "\tmaxlength\t= 16><br />\n";
	$VAR["Content"] .= "Password:\n";
	$VAR["Content"] .= "<input\ttype\t= password\n";
	$VAR["Content"] .= "\tname\t= Password\n";
	$VAR["Content"] .= "\tsize\t= 16\n";
	$VAR["Content"] .= "\tmaxlength\t= 16><br />\n";
	$VAR["Content"] .= "<input\ttype\t= hidden\n";
	$VAR["Content"] .= "\tname\t=\"warn\"\n";
	$VAR["Content"] .= "\tvalue\t= \"1\">\n";
	$VAR["Content"] .= "<input\ttype\t= submit\n";
	$VAR["Content"] .= "\tname\t=\"mode\"\n";
	$VAR["Content"] .= "\tvalue\t= \"login\">\n";
	$VAR["Content"] .= "</form>\n";
	F_drawMain($VAR);
?>
<script language="javascript">
	document.AUTH.passwd.focus();
</script>
<?
	include($G_PATH . "/include/footer.inc.php");
	exit();
}

?>
