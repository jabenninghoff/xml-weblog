<?
/*=========================================================================
:: phpWebLog -- web news management with tits.
:: Copyright (C) 2000-2001 Jason Hines
:: see http://phpweblog.org for more

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

=*=======================================================================*/

include("./include/common.inc.php");


	$sql	= "SELECT * from T_Pages";
	$sql	.= " WHERE Rid = '" . $node . "' LIMIT 1";
	$result	= mysql_query($sql,$db);
	$nrows	= mysql_num_rows($result);
	$A	= mysql_fetch_array($result);
	if ($nrows==0) {
		include("./include/header.inc.php");
		$VAR["Heading"] = "Page not found.";
		$VAR["Content"] = "<br />The page you have requested is not found. ";
		$VAR["Content"] .= "If this error persists, please notify the ";
		$VAR["Content"] .= "administrator of this site.<br /><br />";
		F_drawMain($VAR);
		include("./include/footer.inc.php");
	} else {
		if ($A["Type"]==1) { # addon

			F_uphits("T_Pages",$A["Rid"]);

			# predefined variables and constants for addons to use
			$SELF = $PHP_SELF . "?node=" . $A["Rid"];
			define("SELF",$SELF);
			$URL	= $G_URL ."/" . strstr($A["URL"],"backend/addons/");
			define("URL",$URL);
			$PATH = $G_PATH ."/" . strstr($A["URL"],"backend/addons/");
			define("PATH",$PATH);

			# load translation file
			$tmp	= $A["URL"] . "/language/" . $LANG . ".lng";
			if (file_exists($tmp)) {
				include_once($tmp);
			}

			ob_start();
			include_once("./include/header.inc.php");
			$file = (!empty($file) ? $file : "index.php");
			include_once($A["URL"] . $file);
			if ($A["PageComments"]>0) {
				F_doComments($A["Rid"],$A["Rid"],"pages.php?node=".urlencode($page));
				print "<br />";
				F_PostComment($A["Rid"],$A["Rid"],"pages.php?node=".urlencode($page));
			}
			include_once("./include/footer.inc.php");
			ob_end_flush();

		} else {

			F_uphits("T_Pages",$A["Rid"]);

			ob_start();
			include("./include/header.inc.php");
			$VAR["Heading"] = $A["Heading"];

			if ($A["Type"]==2) { # url/include fetch
				$VAR["Content"] = F_geturl($A["URL"]);
			} else { # static html
				$VAR["Content"] = urldecode($A["Content"]);
			}
			$VAR["Content"]	.= "<br />\n" . F_admin("T_Pages",$A["Rid"],"pages.php?node=" . $node);
			F_drawMain($VAR);

			if ($A["PageComments"]>0) {
				F_doComments($A["Rid"],$A["Rid"],"pages.php?node=".urlencode($page));
				print "<br />";
				F_PostComment($A["Rid"],$A["Rid"],"pages.php?node=".urlencode($page));
			}

			include("./include/footer.inc.php");
			ob_end_flush();

		}

	}

?>
